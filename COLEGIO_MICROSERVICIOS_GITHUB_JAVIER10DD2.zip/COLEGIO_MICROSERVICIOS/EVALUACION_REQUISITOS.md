# Matriz de requisitos y estado de verificación

Fuente: `INFORME_SEMANA16.docx`, catálogo RF-01 a RF-25. Esta revisión combina inspección del código con una prueba de integración temporal (SQLite) y 9 pruebas unitarias/de gateway. **No equivale a aceptación institucional**.

Leyenda: **I** = implementación identificada por lectura de código; **P** = verificada en prueba de integración temporal; **V** = requiere pruebas funcionales de aceptación con datos ficticios; **C** = requiere confirmación de reglas con el colegio.

| Requisito | Función | Evidencia en código | Estado |
|---|---|---|---|
| RF-01 | Autenticación | `identity/auth/login`, sesión en gateway | I, P |
| RF-02 | Roles y permisos | `require_user`, `verified_user`, autorización de endpoints | I, V |
| RF-03 | Catálogo administrable | API `/types`, pantalla Catálogo | I, V |
| RF-04 | Formularios según trámite | `validate_fields`, `fieldMarkup` | I, V |
| RF-05 | Registro de solicitudes | POST `/requests` | I, P |
| RF-06 | Código único | índice único de BD, `short_code` | I, P |
| RF-07 | Adjuntos | POST `/attachments`, solo PDF hasta 5 MB | I, V |
| RF-08 | Bandeja única RR. HH. | `staff_receiver` y creación automática | I, P |
| RF-09 | Consulta de estado | GET `/requests/{rid}` | I, P |
| RF-10 | Observaciones | Transiciones a `OBSERVADA` | I, V |
| RF-11 | Subsanación | POST `/subsanar`, PATCH de solicitud | I, V |
| RF-12 | Estados por tipo | `TRANSITIONS`, `RESULTS`, `allowed_transitions` | I, V, C |
| RF-13 | Historial | Modelo `Event`, `/requests/{rid}` | I, P |
| RF-14 | Usuario, fecha y acción | Columnas `actor_id`, `recorded_at`, `kind` | I, P |
| RF-15 | Avisos | Tabla `Notification`, pantalla Avisos | I, V |
| RF-16 | Pendientes RR. HH. | Bandeja y filtrado por estado | I, V |
| RF-17 | Aprobar/denegar con permiso | `can_authorize`, validación de transición | I, V, C |
| RF-18 | Cierre | Estados `ATENDIDA`/`ACEPTADA` → `CERRADA` | I, V |
| RF-19 | Dashboard | `/reports/summary`, panel con evidencia y gráficos | I, P para API; V para UI |
| RF-20 | Filtros tipo/estado/fecha | Filtrado en solicitudes y frontend | I, V |
| RF-21 | Reportes | CSV de evidencia y exportación de bandeja | I, V |
| RF-22 | Administración de usuarios | `/users`, interfaz de usuarios | I, V |
| RF-23 | Permisos | Cambio de rol; campo `can_authorize` | I, V, C |
| RF-24 | Documentos privados | `ensure_access`, descarga autenticada | I, V (incluye prueba negativa pendiente) |
| RF-25 | Diez trámites | `common/catalog.py` y `migrate()` | I, P (catálogo), V (cada flujo) |

## Pruebas realizadas

- **9 pruebas automatizadas:** control de acceso, JWT, contraseñas, protección cross-site, rate-limit, indicadores y validaciones de fecha.
- **Integración temporal:** inicio de 4 procesos, login trabajador/RR. HH., diez tipos de trámite, registro de vacaciones, bandeja, apertura con historial, panel de agregados y readiness. **Aprobada**.
- **Sintaxis:** `python -m compileall` y `node --check` sin errores.
- **Visual:** el navegador automatizado no pudo acceder a localhost por una restricción del entorno. La visualización definitiva debe verificarse en Windows antes de la sustentación.
- **Docker/MySQL:** `compose.yaml` está formado y validado como YAML, pero **no se ejecutó** porque Docker no está disponible en este entorno.

## Riesgos metodológicos

1. Las cifras de pretest y postest de la tesis no se regeneran a partir de estos tests. Conservar y reconciliar la matriz original de mediciones.
2. El instante de registro automático del cambio **no prueba** cuándo ocurrió o fue comunicado el evento antes de registrarlo. La actualización oportuna no se calcula hasta validar la fuente temporal.
3. La seguridad y los requisitos de cada trámite deben ser confirmados por usuarios autorizados del colegio antes de operación con documentos reales.
4. Se recomienda un recorrido de aceptación por cada una de las diez modalidades, especialmente adjuntos médicos y autorización formal.
5. No desplegar en Internet sin proxy HTTPS, backup/restauración, políticas de privacidad y un usuario con atribuciones confirmadas.
