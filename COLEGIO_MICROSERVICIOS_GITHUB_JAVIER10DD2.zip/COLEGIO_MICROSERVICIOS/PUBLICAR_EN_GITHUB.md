# Publicar el repositorio en GitHub (público)

El código ha sido revisado para evitar incluir claves privadas y datos reales. GitHub almacena el código, **no** la base MySQL ni las credenciales de Vercel.

## Opción A: creación por el asistente

1. Visita https://github.com/new.
2. Owner `javier10dd2`; nombre `colegio-microservicios`; marca **Public**. **No** marques README, .gitignore ni License (ya hay README y .gitignore).
3. Crea el repositorio vacío y comparte el URL `https://github.com/javier10dd2/colegio-microservicios` en la conversación. El asistente podrá subir los archivos al repositorio existente si GitHub sigue conectado y tiene permisos de escritura.

## Opción B: publicación desde Windows

Instala Git y GitHub CLI (`winget install --id Git.Git -e` y `winget install --id GitHub.cli -e`). En PowerShell, dentro de la carpeta descomprimida, ejecuta el archivo `PUBLICAR_EN_GITHUB.ps1`. El script inicia sesión en GitHub si es necesario, crea el repositorio público si no existe y sube `main`.

**Antes de publicar** revisa `git status`, `.gitignore`, especialmente si añades otros archivos más adelante. Nunca incluyas `backend/.env`, copias de base de datos, contraseñas ni PDF institucionales.

## Vercel

La publicación en GitHub no cambia automáticamente el despliegue actual de Vercel. Para despliegues por cada push, conecta este repositorio al proyecto desde *Project Settings > Git* en el panel de Vercel, o crea un proyecto nuevo vinculado al repo y configura allí las variables privadas existentes. Evita crear un segundo sitio público por accidente.
