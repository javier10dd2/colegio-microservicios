# Ejecutar en PowerShell desde la carpeta del proyecto, con Git y GitHub CLI instalados.
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw "Instala Git: winget install --id Git.Git -e" }
if (-not (Get-Command gh -ErrorAction SilentlyContinue)) { throw "Instala GitHub CLI: winget install --id GitHub.cli -e" }
& gh auth status 2>$null
if ($LASTEXITCODE -ne 0) { & gh auth login --web; if ($LASTEXITCODE -ne 0) { throw "No se inició sesión en GitHub" } }
if (-not (Test-Path ".git")) { & git init; if ($LASTEXITCODE -ne 0) { throw "Git init falló" } }
& git branch -M main
& git add .
$files = & git diff --cached --name-only
foreach ($f in $files) {
  $name = $f -replace '\\','/'
  if ($name -match '(^|/)(\.env($|\.)|ACCESO_INICIAL|credenciales|credentials|backups|adjuntos|datos_personales)' -or $name -match '\.(db|sqlite|bak|pem|key|p12|pfx|xlsx|xls|csv|pdf|zip|rar|gz)$') {
    throw "Archivo sensible bloqueado: $name. Revisa .gitignore antes de publicar."
  }
}
Write-Host "Archivos que se van a publicar: $($files.Count)"
& git status --short
if (-not $files) { throw "No hay archivos para publicar" }
& git -c user.name="Proyecto Colegio" -c user.email="noreply@users.noreply.github.com" commit -m "Publicar código de Colegio Microservicios"
if ($LASTEXITCODE -ne 0) { throw "Falló git commit" }
& gh repo view "javier10dd2/colegio-microservicios" --json name >$null 2>&1
if ($LASTEXITCODE -ne 0) {
  & gh repo create "javier10dd2/colegio-microservicios" --public --source . --remote origin --push
  if ($LASTEXITCODE -ne 0) { throw "No se pudo crear/publicar el repositorio" }
} else {
  & git remote add origin "https://github.com/javier10dd2/colegio-microservicios.git" 2>$null
  & git push -u origin main
  if ($LASTEXITCODE -ne 0) { throw "No se pudo subir la rama main" }
}
Write-Host "REPOSITORIO: https://github.com/javier10dd2/colegio-microservicios"
