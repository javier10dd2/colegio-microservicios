"""Prueba local integrada; usa SQLite temporal y usuarios enteramente ficticios."""
from __future__ import annotations
import os
import tempfile
from pathlib import Path

with tempfile.TemporaryDirectory() as directory:
    os.environ.update({
        'DB_MODE': 'sqlite', 'DATA_DIR': directory,
        'CLOUD_PDF_STORAGE': 'database', 'ENVIRONMENT': 'development',
        'COOKIE_SECURE': '0',
    })
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from app import app
    from services.identity import main as identity
    from services.requests import main as requests
    from fastapi.testclient import TestClient

    identity.migrate_schema()
    requests.migrate()
    with identity.SessionLocal() as db:
        for name, email, role in (
            ('Recursos Humanos', 'rrhh@test.example.com', 'RRHH'),
            ('Docente Prueba', 'docente@test.example.com', 'TRABAJADOR'),
        ):
            db.add(identity.User(name=name, email=email, role=role,
                    active=True, can_authorize=False,
                    password_hash=identity.password_hash('PasswordPrueba123')))
        db.commit()
    with TestClient(app) as docente, TestClient(app) as rrhh:
        assert docente.get('/').status_code == 200
        assert docente.get('/static/app.js').status_code == 200
        assert docente.get('/health/ready').json()['ok'] is True
        assert docente.get('/api/identity/internal/users/1').status_code == 404
        for client, email in ((docente, 'docente@test.example.com'),
                              (rrhh, 'rrhh@test.example.com')):
            assert client.post('/api/identity/auth/login', json={
                'email': email, 'password': 'PasswordPrueba123',
            }).status_code == 200
        opts = docente.get('/api/requests/types').json()
        assert len(opts) >= 1
        chosen = next(t for t in opts if t['key'] == 'BOLETA_PAGO')
        r = docente.post('/api/requests/requests', json={
            'type': chosen['key'], 'subject': 'Prueba de tesis',
            'description': 'Solo contenido ficticio',
            'details': {'periodo': '2026-10'},
        })
        assert r.status_code == 201, r.text
        rid = r.json()['id']
        pdf = b'%PDF-1.4\nArchivo de prueba, no contiene datos reales\n%%EOF\n'
        r = docente.post(f'/api/requests/requests/{rid}/attachments',
                         files={'file': ('prueba.pdf', pdf, 'application/pdf')})
        assert r.status_code == 201, r.text
        r = docente.get(f'/api/requests/requests/{rid}')
        assert r.status_code == 200
        aid = r.json()['attachments'][0]['id']
        r = docente.get(f'/api/requests/attachments/{aid}')
        assert r.status_code == 200 and r.content == pdf
        assert rrhh.get('/api/reports/summary').json()['total'] == 1
        print('PRUEBA NUBE OK: frontend, gateway, usuarios, solicitudes, PDF y reportes')
