"""Las métricas no deben fabricar mediciones o actualizaciones oportunas."""
from datetime import datetime,timezone
import httpx
from services.reports import main as reports
from services.requests.main import validate_fields
from fastapi import HTTPException

class StubResponse:
    def __init__(self, data): self.data=data
    def raise_for_status(self): return None
    def json(self):return self.data


def test_summary_reports_real_denominators(monkeypatch):
    timestamp='2026-11-10T15:30:00+00:00'
    dataset={
      'requests':[
        {'id':1,'code':'12345','type':'VACACIONES','status':'REGISTRADA','created_at':timestamp,
         'history':[{'kind':'CREACION','actor_id':1,'recorded_at':timestamp,'to_status':'REGISTRADA'}]},
        {'id':2,'code':'54321','type':'PERMISO_PERSONAL','status':'EN_REVISION','created_at':timestamp,
         'history':[{'kind':'CREACION','actor_id':2,'recorded_at':timestamp,'to_status':'REGISTRADA'},
                    {'kind':'CAMBIO_ESTADO','actor_id':2,'recorded_at':timestamp,'effective_at':timestamp,
                     'to_status':'EN_REVISION'}]},
      ],
      'measurements':[{'request_id':1,'measurement_id':1,'correct':True,'seconds':60},
                      {'request_id':1,'measurement_id':2,'correct':True,'seconds':45},
                      {'request_id':2,'measurement_id':3,'correct':False,'seconds':200}],
      'demo_count':2,'consultation_reads':4,'state_updates':1}
    monkeypatch.setattr(reports.http_client,'get',lambda *a,**kw:StubResponse(dataset))
    monkeypatch.setenv('UPDATE_DEADLINE_HOURS','0.5')
    monkeypatch.delenv('UPDATE_EVIDENCE_VALIDATED',raising=False)
    result=reports.summary(user={'role':'RRHH'})
    assert result['total']==2 and result['demo_count']==2
    assert result['consultation']['valid']==1
    assert result['consultation']['mean_seconds']==45
    assert result['trace']['complete']==2
    assert result['trace']['evaluable']==2
    assert result['timely']['percent'] is None
    assert result['timely']['evaluable']==0
    assert result['timely']['missing_evidence']==1


def test_csv_keeps_unverified_updates_explicit(monkeypatch):
    stamp='2026-11-10T15:30:00+00:00'
    dataset={'requests':[{'id':1,'code':'12345','type':'VACACIONES','status':'EN_REVISION','created_at':stamp,
        'history':[{'kind':'CREACION','actor_id':1,'recorded_at':stamp,'to_status':'REGISTRADA'},
                   {'kind':'CAMBIO_ESTADO','actor_id':1,'recorded_at':stamp,'effective_at':stamp,'to_status':'EN_REVISION'}]}],
        'measurements':[]}
    monkeypatch.setattr(reports.http_client,'get',lambda *a,**kw:StubResponse(dataset))
    monkeypatch.setenv('UPDATE_DEADLINE_HOURS','0.5')
    monkeypatch.delenv('UPDATE_EVIDENCE_VALIDATED',raising=False)
    res=reports.export_posttest(user={'role':'RRHH'})
    assert 'PENDIENTE_VALIDACION' in res.body.decode('utf-8')


def test_form_rejects_inverted_date_range():
    fields=[{'key':'fecha_inicio','label':'Desde','type':'date','required':True},
            {'key':'fecha_fin','label':'Hasta','type':'date','required':True}]
    try:
        validate_fields(fields,{'fecha_inicio':'2026-11-20','fecha_fin':'2026-11-10'})
    except HTTPException as e:
        assert e.status_code==422
    else:assert False
    assert validate_fields(fields,{'fecha_inicio':'2026-11-10','fecha_fin':'2026-11-20'})['fecha_inicio']=='2026-11-10'


def test_simultaneous_timestamps_are_not_independent_evidence(monkeypatch):
    stamp='2026-11-10T15:30:00+00:00'
    data={'requests':[{'id':1,'code':'12345','type':'VACACIONES','status':'EN_REVISION','created_at':stamp,
          'history':[{'kind':'CREACION','actor_id':1,'recorded_at':stamp,'to_status':'REGISTRADA'},
                     {'kind':'CAMBIO_ESTADO','actor_id':1,'recorded_at':stamp,'effective_at':stamp,'to_status':'EN_REVISION'}]}],
          'measurements':[]}
    monkeypatch.setattr(reports.http_client,'get',lambda *a,**kw:StubResponse(data))
    monkeypatch.setenv('UPDATE_DEADLINE_HOURS','0.5')
    monkeypatch.setenv('UPDATE_EVIDENCE_VALIDATED','1')
    result=reports.summary(user={'role':'RRHH'})
    assert result['timely']['percent'] is None
    assert result['timely']['missing_evidence']==1
