from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_panels_removed_from_report_page():
    js=(ROOT/'frontend/static/app.js').read_text(encoding='utf-8')
    assert '¿Cómo se calculan los indicadores?' not in js
    assert 'Medir búsqueda de expediente' not in js
    assert 'measurement-container' not in js
    assert 'setupMeasurementPanel' not in js

def test_report_buttons_do_not_assign_onclick_to_disconnected_nodes():
    js=(ROOT/'frontend/static/app.js').read_text(encoding='utf-8')
    assert "if(refreshButton)refreshButton.addEventListener('click'" in js
    assert "if(downloadButton)downloadButton.addEventListener('click'" in js
    assert "$('refresh').onclick=" not in js
    assert "$('download-posttest').onclick=" not in js

def test_assets_refreshed():
    html=(ROOT/'frontend/index.html').read_text(encoding='utf-8')
    assert 'app.js?v=20261115fixonclick3' in html

def test_fastapi_entrypoint_exported():
    code=(ROOT/'app.py').read_text(encoding='utf-8')
    assert 'app = FastAPI()' in code
    assert 'app = gateway.app' in code
