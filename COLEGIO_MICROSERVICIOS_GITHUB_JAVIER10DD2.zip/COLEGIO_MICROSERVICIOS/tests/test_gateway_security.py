"""Pruebas de regresión rápidas: no requieren MySQL ni datos institucionales."""
from fastapi.testclient import TestClient
from gateway.main import app, login_rate_limited, _login_hits
from common.security import password_hash, password_verify, make_token, require_user
from fastapi import HTTPException

client = TestClient(app)


def test_gateway_responds_with_security_headers():
    res=client.get('/health')
    assert res.status_code==200
    assert res.json()['ok'] is True
    assert 'Content-Security-Policy' in res.headers
    assert res.headers['X-Frame-Options']=='DENY'
    assert res.headers['X-Content-Type-Options']=='nosniff'


def test_private_route_requires_session():
    res=client.get('/api/requests/requests')
    assert res.status_code==401


def test_gateway_does_not_proxy_internal_route():
    res=client.get('/api/requests/internal/export')
    assert res.status_code==404


def test_cross_site_mutations_are_rejected():
    res=client.post('/api/logout',headers={'Sec-Fetch-Site':'cross-site'})
    assert res.status_code==403
    res=client.post('/api/logout',headers={'Sec-Fetch-Site':'same-origin'})
    assert res.status_code==200


def test_login_attempts_limited():
    _login_hits.clear()
    for i in range(25):assert login_rate_limited('127.10.0.13') is False
    assert login_rate_limited('127.10.0.13') is True
    assert login_rate_limited('127.10.0.14') is False
    _login_hits.clear()


def test_password_hash_and_signed_session():
    hashed=password_hash('una-contraseña-muy-segura-2026')
    assert 'una-contraseña-muy-segura-2026' not in hashed
    assert password_verify('una-contraseña-muy-segura-2026',hashed)
    assert not password_verify('incorrecta',hashed)
    user={'id':9,'name':'Persona Prueba','email':'demo@example.invalid','role':'TRABAJADOR'}
    decoded=require_user('Bearer '+make_token(user))
    assert decoded['id']==9 and decoded['role']=='TRABAJADOR'
    try:
        require_user('Bearer token-invalido')
    except HTTPException as e:
        assert e.status_code==401
    else:
        assert False, 'Un JWT inválido debe rechazarse'
