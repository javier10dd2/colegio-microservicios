"""Entrada FastAPI reconocida de forma nativa por Vercel.

No inicia Uvicorn, subprocesos, MySQL local ni sockets. El gateway público
mantiene la misma API y los otros 3 servicios se comunican internamente.
"""
from __future__ import annotations
from fastapi import FastAPI
app = FastAPI()  # Punto de entrada reconocido por Vercel. Se sustituye por gateway.app al finalizar este archivo.
import os
import sys
from pathlib import Path
import httpx

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'backend'))

# Vercel solo permite escrituras temporales en /tmp. Los PDF en cloud se guardan
# permanentemente en MySQL (adjuntos_contenido), no en /tmp.
if os.getenv('VERCEL'):
    os.environ.setdefault('DATA_DIR', '/tmp/colegio')
    os.environ.setdefault('UPLOAD_DIR', '/tmp/colegio/adjuntos')
    os.environ.setdefault('CLOUD_PDF_STORAGE', 'database')

# Los nombres .internal son exclusivamente locales al transporte ASGI.
os.environ['IDENTITY_URL'] = 'http://identity.internal'
os.environ['REQUESTS_URL'] = 'http://requests.internal'
os.environ['REPORTS_URL'] = 'http://reports.internal'

from services.identity import main as identity_service
if os.getenv('MIGRATE_ON_BOOT') == '1':
    identity_service.migrate_schema()
from services.requests import main as requests_service
if os.getenv('MIGRATE_ON_BOOT') == '1':
    requests_service.migrate()
from services.reports import main as reports_service
from gateway import main as gateway
from vercel_bridge import ServiceTransport, InternalHTTPClient

apps = {
    'identity.internal': identity_service.app,
    'requests.internal': requests_service.app,
    'reports.internal': reports_service.app,
}
# El gateway conserva los controles de cookie, JWT y rutas internas.
gateway.shared_client = httpx.AsyncClient(
    transport=ServiceTransport(apps), timeout=httpx.Timeout(12, connect=3)
)
# Reportes y Solicitudes también tienen enlaces privados entre servicios.
requests_service.http_client = InternalHTTPClient(apps)
reports_service.http_client = InternalHTTPClient(apps)

app = gateway.app
