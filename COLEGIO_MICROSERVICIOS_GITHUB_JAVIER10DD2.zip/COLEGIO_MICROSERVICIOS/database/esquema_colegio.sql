-- SISTEMA DE GESTION ADMINISTRATIVA DEL COLEGIO
-- ESQUEMA MYSQL/MARIADB COMPATIBLE CON EL PROYECTO ACTUAL
-- Primera etapa: crear/reparar tablas y establecer SOLO dos cuentas de acceso.
-- NO contiene ninguna solicitud administrativa, ni carga 40 casos.
-- Incluye los 10 tipos de tramite que usa la interfaz (catalogo, no solicitudes).
-- Conserva las filas que YA existan; no ejecuta DROP, DELETE ni TRUNCATE.
-- IMPORTANTE: si las bases ya contienen solicitudes, estas permanecen
-- por seguridad. Para obtener bases completamente vacias, crear una copia
-- de seguridad y preparar una instalacion limpia por separado.
-- Antes de importar: cerrar el sistema y respaldar las bases anteriores.

SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS `colegio_identidad` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS `colegio_solicitudes` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;



USE `colegio_identidad`;


CREATE TABLE IF NOT EXISTS usuarios (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	name VARCHAR(120) NOT NULL, 
	email VARCHAR(190) NOT NULL, 
	password_hash VARCHAR(256) NOT NULL, 
	`role` VARCHAR(15) NOT NULL, 
	active BOOL NOT NULL, 
	can_authorize BOOL NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




-- Columna usuarios.can_authorize: conserva los valores cuando ya existe.
SET @columna_existe := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='usuarios' AND COLUMN_NAME='can_authorize');
SET @sql := IF(@columna_existe > 0, 'SELECT 1', 'ALTER TABLE `usuarios` ADD COLUMN `can_authorize` BOOLEAN NOT NULL DEFAULT 0');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Indice ix_usuarios_email (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'usuarios' AND INDEX_NAME = 'ix_usuarios_email');
SET @sql := IF(@indice_existe > 0 OR EXISTS(SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='usuarios' AND COLUMN_NAME='email' AND NON_UNIQUE=0), 'SELECT 1', 'CREATE UNIQUE INDEX `ix_usuarios_email` ON `usuarios` (`email`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


CREATE TABLE IF NOT EXISTS auditoria_usuarios (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	actor_id INTEGER NOT NULL, 
	target_id INTEGER NOT NULL, 
	action VARCHAR(70) NOT NULL, 
	detail VARCHAR(250) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




-- Indice idx_auditoria_usuarios_actor (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'auditoria_usuarios' AND INDEX_NAME = 'idx_auditoria_usuarios_actor');
SET @sql := IF(@indice_existe > 0, 'SELECT 1', 'CREATE INDEX `idx_auditoria_usuarios_actor` ON `auditoria_usuarios` (`actor_id`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Indice idx_auditoria_usuarios_target_fecha (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'auditoria_usuarios' AND INDEX_NAME = 'idx_auditoria_usuarios_target_fecha');
SET @sql := IF(@indice_existe > 0, 'SELECT 1', 'CREATE INDEX `idx_auditoria_usuarios_target_fecha` ON `auditoria_usuarios` (`target_id`, `created_at`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


USE `colegio_solicitudes`;


CREATE TABLE IF NOT EXISTS solicitudes (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	code VARCHAR(32) NOT NULL, 
	legacy_code VARCHAR(32), 
	type VARCHAR(40) NOT NULL, 
	subject VARCHAR(180) NOT NULL, 
	description TEXT NOT NULL, 
	requester_id INTEGER NOT NULL, 
	requester_name VARCHAR(120) NOT NULL, 
	requester_email VARCHAR(190) NOT NULL, 
	assignee_id INTEGER, 
	assignee_name VARCHAR(120), 
	status VARCHAR(25) NOT NULL, 
	is_demo BOOL NOT NULL, 
	details_json TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	closed_at DATETIME, 
	PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Columna solicitudes.legacy_code: conserva los valores cuando ya existe.
SET @columna_existe := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='solicitudes' AND COLUMN_NAME='legacy_code');
SET @sql := IF(@columna_existe > 0, 'SELECT 1', 'ALTER TABLE `solicitudes` ADD COLUMN `legacy_code` VARCHAR(32) NULL');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Columna solicitudes.details_json: conserva los valores cuando ya existe.
SET @columna_existe := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='solicitudes' AND COLUMN_NAME='details_json');
SET @sql := IF(@columna_existe > 0, 'SELECT 1', 'ALTER TABLE `solicitudes` ADD COLUMN `details_json` TEXT NULL');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Columna solicitudes.is_demo: conserva los valores cuando ya existe.
SET @columna_existe := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='solicitudes' AND COLUMN_NAME='is_demo');
SET @sql := IF(@columna_existe > 0, 'SELECT 1', 'ALTER TABLE `solicitudes` ADD COLUMN `is_demo` BOOLEAN NOT NULL DEFAULT 0');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Indice ix_solicitudes_code (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'solicitudes' AND INDEX_NAME = 'ix_solicitudes_code');
SET @sql := IF(@indice_existe > 0 OR EXISTS(SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='solicitudes' AND COLUMN_NAME='code' AND NON_UNIQUE=0), 'SELECT 1', 'CREATE UNIQUE INDEX `ix_solicitudes_code` ON `solicitudes` (`code`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Indice ix_solicitudes_requester_id (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'solicitudes' AND INDEX_NAME = 'ix_solicitudes_requester_id');
SET @sql := IF(@indice_existe > 0, 'SELECT 1', 'CREATE INDEX `ix_solicitudes_requester_id` ON `solicitudes` (`requester_id`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Indice ix_solicitudes_assignee_id (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'solicitudes' AND INDEX_NAME = 'ix_solicitudes_assignee_id');
SET @sql := IF(@indice_existe > 0, 'SELECT 1', 'CREATE INDEX `ix_solicitudes_assignee_id` ON `solicitudes` (`assignee_id`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Indice ix_solicitudes_type (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'solicitudes' AND INDEX_NAME = 'ix_solicitudes_type');
SET @sql := IF(@indice_existe > 0, 'SELECT 1', 'CREATE INDEX `ix_solicitudes_type` ON `solicitudes` (`type`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Indice ix_solicitudes_status (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'solicitudes' AND INDEX_NAME = 'ix_solicitudes_status');
SET @sql := IF(@indice_existe > 0, 'SELECT 1', 'CREATE INDEX `ix_solicitudes_status` ON `solicitudes` (`status`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Indice ix_solicitudes_is_demo (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'solicitudes' AND INDEX_NAME = 'ix_solicitudes_is_demo');
SET @sql := IF(@indice_existe > 0, 'SELECT 1', 'CREATE INDEX `ix_solicitudes_is_demo` ON `solicitudes` (`is_demo`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Indice idx_solicitudes_solicitante_fecha (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'solicitudes' AND INDEX_NAME = 'idx_solicitudes_solicitante_fecha');
SET @sql := IF(@indice_existe > 0, 'SELECT 1', 'CREATE INDEX `idx_solicitudes_solicitante_fecha` ON `solicitudes` (`requester_id`, `created_at`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


CREATE TABLE IF NOT EXISTS historial (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	request_id INTEGER NOT NULL, 
	actor_id INTEGER NOT NULL, 
	actor_name VARCHAR(120) NOT NULL, 
	kind VARCHAR(30) NOT NULL, 
	from_status VARCHAR(25), 
	to_status VARCHAR(25) NOT NULL, 
	detail TEXT NOT NULL, 
	effective_at DATETIME, 
	recorded_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(request_id) REFERENCES solicitudes (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS adjuntos (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	request_id INTEGER NOT NULL, 
	original_name VARCHAR(200) NOT NULL, 
	stored_name VARCHAR(50) NOT NULL, 
	sha256 VARCHAR(64) NOT NULL, 
	size INTEGER NOT NULL, 
	author_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(request_id) REFERENCES solicitudes (id), 
	UNIQUE (stored_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS notificaciones (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	user_id INTEGER NOT NULL, 
	request_id INTEGER NOT NULL, 
	detail VARCHAR(250) NOT NULL, 
	created_at DATETIME NOT NULL, 
	read_at DATETIME, 
	PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS mediciones_consulta (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	request_id INTEGER NOT NULL, 
	observer_id INTEGER NOT NULL, 
	started_at DATETIME NOT NULL, 
	ended_at DATETIME, 
	seconds FLOAT, 
	correct BOOL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(request_id) REFERENCES solicitudes (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS tipos_tramite (
	code VARCHAR(40) NOT NULL, 
	label VARCHAR(120) NOT NULL, 
	fields_json TEXT NOT NULL, 
	active BOOL NOT NULL, 
	PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Indice ix_historial_request_id (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'historial' AND INDEX_NAME = 'ix_historial_request_id');
SET @sql := IF(@indice_existe > 0, 'SELECT 1', 'CREATE INDEX `ix_historial_request_id` ON `historial` (`request_id`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Indice idx_historial_expediente_fecha (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'historial' AND INDEX_NAME = 'idx_historial_expediente_fecha');
SET @sql := IF(@indice_existe > 0, 'SELECT 1', 'CREATE INDEX `idx_historial_expediente_fecha` ON `historial` (`request_id`, `recorded_at`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Indice ix_adjuntos_request_id (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'adjuntos' AND INDEX_NAME = 'ix_adjuntos_request_id');
SET @sql := IF(@indice_existe > 0, 'SELECT 1', 'CREATE INDEX `ix_adjuntos_request_id` ON `adjuntos` (`request_id`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Indice ix_mediciones_consulta_request_id (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'mediciones_consulta' AND INDEX_NAME = 'ix_mediciones_consulta_request_id');
SET @sql := IF(@indice_existe > 0, 'SELECT 1', 'CREATE INDEX `ix_mediciones_consulta_request_id` ON `mediciones_consulta` (`request_id`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Indice ix_notificaciones_user_id (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'notificaciones' AND INDEX_NAME = 'ix_notificaciones_user_id');
SET @sql := IF(@indice_existe > 0, 'SELECT 1', 'CREATE INDEX `ix_notificaciones_user_id` ON `notificaciones` (`user_id`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Indice ix_notificaciones_request_id (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'notificaciones' AND INDEX_NAME = 'ix_notificaciones_request_id');
SET @sql := IF(@indice_existe > 0, 'SELECT 1', 'CREATE INDEX `ix_notificaciones_request_id` ON `notificaciones` (`request_id`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Indice idx_notificaciones_lectura (omite si ya existe).
SET @indice_existe := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'notificaciones' AND INDEX_NAME = 'idx_notificaciones_lectura');
SET @sql := IF(@indice_existe > 0, 'SELECT 1', 'CREATE INDEX `idx_notificaciones_lectura` ON `notificaciones` (`user_id`, `read_at`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Crear relacion historial.request_id -> solicitudes.id solo si no existe y los registros son validos.
SET @tiene_fk := (SELECT COUNT(*) FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='historial' AND COLUMN_NAME='request_id' AND REFERENCED_TABLE_NAME='solicitudes');
SET @huerfanos := (SELECT COUNT(*) FROM `historial` t LEFT JOIN `solicitudes` s ON s.id=t.request_id WHERE s.id IS NULL);
SET @sql := IF(@tiene_fk>0 OR @huerfanos>0, 'SELECT 1', 'ALTER TABLE `historial` ADD CONSTRAINT `fk_reparacion_historial_solicitudes` FOREIGN KEY (`request_id`) REFERENCES `solicitudes` (`id`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Crear relacion adjuntos.request_id -> solicitudes.id solo si no existe y los registros son validos.
SET @tiene_fk := (SELECT COUNT(*) FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='adjuntos' AND COLUMN_NAME='request_id' AND REFERENCED_TABLE_NAME='solicitudes');
SET @huerfanos := (SELECT COUNT(*) FROM `adjuntos` t LEFT JOIN `solicitudes` s ON s.id=t.request_id WHERE s.id IS NULL);
SET @sql := IF(@tiene_fk>0 OR @huerfanos>0, 'SELECT 1', 'ALTER TABLE `adjuntos` ADD CONSTRAINT `fk_reparacion_adjuntos_solicitudes` FOREIGN KEY (`request_id`) REFERENCES `solicitudes` (`id`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Crear relacion mediciones_consulta.request_id -> solicitudes.id solo si no existe y los registros son validos.
SET @tiene_fk := (SELECT COUNT(*) FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='mediciones_consulta' AND COLUMN_NAME='request_id' AND REFERENCED_TABLE_NAME='solicitudes');
SET @huerfanos := (SELECT COUNT(*) FROM `mediciones_consulta` t LEFT JOIN `solicitudes` s ON s.id=t.request_id WHERE s.id IS NULL);
SET @sql := IF(@tiene_fk>0 OR @huerfanos>0, 'SELECT 1', 'ALTER TABLE `mediciones_consulta` ADD CONSTRAINT `fk_reparacion_mediciones_consulta_solicitudes` FOREIGN KEY (`request_id`) REFERENCES `solicitudes` (`id`)');
PREPARE reparacion FROM @sql;
EXECUTE reparacion;
DEALLOCATE PREPARE reparacion;


-- Completar unicamente tramites que falten; NO modifica nombres o disponibilidad existente.
INSERT IGNORE INTO `tipos_tramite` (`code`,`label`,`fields_json`,`active`) VALUES
('VACACIONES','Solicitud de vacaciones','[{"key": "fecha_inicio", "label": "Inicio de vacaciones", "type": "date", "required": true}, {"key": "fecha_fin", "label": "Fin de vacaciones", "type": "date", "required": true}]',1),
('LICENCIA_CON_GOCE','Licencia con goce de haber','[{"key": "motivo", "label": "Motivo", "type": "text", "required": true}, {"key": "fecha_inicio", "label": "Desde", "type": "date", "required": true}, {"key": "fecha_fin", "label": "Hasta", "type": "date", "required": true}]',1),
('LICENCIA_SIN_GOCE','Licencia sin goce de haber','[{"key": "motivo", "label": "Motivo", "type": "text", "required": true}, {"key": "fecha_inicio", "label": "Desde", "type": "date", "required": true}, {"key": "fecha_fin", "label": "Hasta", "type": "date", "required": true}]',1),
('DESCANSO_MEDICO','Descanso médico','[{"key": "fecha_inicio", "label": "Inicio de descanso", "type": "date", "required": true}, {"key": "fecha_fin", "label": "Fin de descanso", "type": "date", "required": true}]',1),
('PERMISO_FALLECIMIENTO','Permiso por fallecimiento de familiar','[{"key": "parentesco", "label": "Parentesco", "type": "text", "required": true}, {"key": "fecha_inicio", "label": "Desde", "type": "date", "required": true}, {"key": "fecha_fin", "label": "Hasta", "type": "date", "required": true}]',1),
('PERMISO_PERSONAL','Permiso personal','[{"key": "motivo", "label": "Motivo", "type": "text", "required": true}, {"key": "fecha", "label": "Fecha", "type": "date", "required": true}, {"key": "hora_inicio", "label": "Desde", "type": "time", "required": true}, {"key": "hora_fin", "label": "Hasta", "type": "time", "required": true}]',1),
('CONSTANCIA_TRABAJO','Constancia de trabajo','[{"key": "finalidad", "label": "Finalidad de la constancia", "type": "text", "required": true}]',1),
('CERTIFICADO_LABORAL','Certificado de trabajo','[{"key": "finalidad", "label": "Finalidad del certificado", "type": "text", "required": true}]',1),
('CERTIFICADO_PRACTICAS','Certificado de prácticas','[{"key": "fecha_inicio", "label": "Inicio de prácticas", "type": "date", "required": true}, {"key": "fecha_fin", "label": "Fin de prácticas", "type": "date", "required": true}]',1),
('BOLETA_PAGO','Boleta de pago','[{"key": "periodo", "label": "Periodo de pago (AAAA-MM)", "type": "month", "required": true}]',1);




-- Cuentas institucionales: NO se publican ni se insertan contraseñas en SQL.
-- En la primera instalación, crear RR. HH. mediante backend/tools/usuarios_iniciales.py.
-- No sobrescribir cuentas ni credenciales al importar este esquema.

-- Registro operativo de vistas (no equivale a medición del tiempo de búsqueda).
USE `colegio_solicitudes`;
CREATE TABLE IF NOT EXISTS `consultas_expediente` (
 `id` INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
 `request_id` INTEGER NOT NULL,
 `viewer_id` INTEGER NOT NULL,
 `viewed_at` DATETIME NOT NULL,
 KEY `ix_consultas_expediente_request_id` (`request_id`),
 KEY `ix_consultas_expediente_viewer_id` (`viewer_id`),
 CONSTRAINT `fk_consultas_expediente_solicitudes` FOREIGN KEY (`request_id`) REFERENCES `solicitudes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
