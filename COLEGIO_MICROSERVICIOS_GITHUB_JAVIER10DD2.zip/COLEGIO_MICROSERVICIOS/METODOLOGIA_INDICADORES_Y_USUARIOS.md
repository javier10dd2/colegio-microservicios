# Indicadores y administración de usuarios (2026-11-15)

## Accesos
- RR.HH. agrega trabajadores y otros usuarios RR.HH. desde **Usuarios > + Nuevo usuario**.
- Cada cuenta tiene correo único, contraseña inicial de mínimo 10 caracteres y rol. Las contraseñas se almacenan con PBKDF2 + sal, no en texto claro.
- Los trabajadores también pueden solicitar autorregistro; RR.HH. debe activarlos.
- RR.HH. puede restablecer una contraseña, sin consultar la original.
- Todos los usuarios inician sesión desde el mismo enlace de Vercel, sin cuenta de Vercel.

## Medición: tiempo medio de consulta
1. RR.HH. abre Indicadores > Medir búsqueda de expediente, elige expediente y empieza la medición.
2. Durante el ensayo se busca el expediente y se verifica el resultado.
3. RR.HH. finaliza la medición e indica si la búsqueda fue correcta. La hora de inicio y fin se toma del servidor; se almacenan en `colegio_solicitudes.mediciones_consulta`.
4. Solo cuentan resultados correctos entre 1 y 7200 segundos; por expediente se usa la última medición válida. Promedio: suma de segundos / número de expedientes con medición válida. No es un tiempo de respuesta HTTP ni la simple apertura del expediente.

## Medición: trazabilidad completa
Porcentaje de expedientes reales con evento inicial de creación, eventos con actor/fecha/estado y último estado coherente. Denominador: todos los expedientes reales. No mide por sí mismo calidad ni significancia estadística.

## Medición: actualización oportuna
Porcentaje de expedientes con cambios cuyas fechas efectivas y de registro independientes están validadas y están dentro del plazo institucional. Requiere definir `UPDATE_DEADLINE_HOURS` y validar evidencia (`UPDATE_EVIDENCE_VALIDATED=1`) solo después de contrastar los registros. **Actualmente las marcas automáticas efectivas y de registro son iguales, así que no constituyen evidencia independiente; debe mostrarse “Sin medición” y no 0 %.**

## Exportación CSV
Se mantienen las 12 columnas originales y se añaden inicio/fin/observador/corrección de la medición y detalle de la evidencia de historial. Cuando no hay expedientes, solo aparecen encabezados; no se generan filas ficticias.

## Persistencia
- Datos de identidad: Railway MySQL, base `colegio_identidad`.
- Solicitudes, historial, mediciones y PDF binarios: Railway MySQL, base `colegio_solicitudes`.
- Vercel aloja frontend/API, no es base de datos. Los datos no se guardan en el navegador ni en un disco temporal de Vercel.
