# Colegio Microservicios — publicación en Vercel

## Antes de empezar

Esta adaptación permite ejecutar **un gateway FastAPI y los servicios de identidad,
solicitudes y reportes en un único Vercel Function**. Conserva sus APIs y autorización;
las llamadas entre servicios son ASGI internas, no procesos HTTP residentes.

**Vercel NO incluye un MySQL local ni un disco persistente.** Necesitas contratar
un MySQL remoto compatible y accesible por TLS; por ejemplo, un servicio MySQL
administrado de tu proveedor preferido. El backend usa MySQL, no PostgreSQL.
Los PDF se guardan privados en MySQL (`adjuntos_contenido`, LONGBLOB).
Por el límite HTTP de Vercel de 4,5 MB se reduce la carga PDF a **4 MB**.
Para PDF mayores implementa después subida directa a Vercel Blob *privado*.

Este paquete **no modifica el proyecto Docker original**: `backend/start.py`,
`compose.yaml` y `Dockerfile` continúan disponibles.

## Paso 1. Consigue MySQL gestionado

- Crea DOS bases en una misma instancia: `colegio_identidad` y `colegio_solicitudes`.
- Crea un usuario con permisos suficientes para crear y cambiar tablas en ambas bases
  durante la inicialización, y que Vercel pueda conectar por TCP/TLS.
- Anota servidor, puerto, usuario y contraseña de forma privada. No basta con
  `localhost` ni con XAMPP en tu computadora.
- Si el proveedor restringe IP de origen, configura una opción admitida por Vercel
  para permitir conexiones de forma segura. No abras tu equipo personal a Internet.
- Para SQL en producción usa conexión cifrada (`DB_SSL=1`) y un servidor confiable.

## Paso 2. Prepara la base desde tu computadora (solo una vez)

En la raíz de la carpeta (donde está `app.py`):

1. Instala Python 3.12+.
2. `pip install -r requirements.txt`.
3. Copia `backend/.env.vercel.example` como `backend/.env` (archivo privado).
4. Completa `DB_HOST`, `DB_PORT`, `DB_USER`, `MYSQL_PASSWORD`, las tres claves
   aleatorias y `ENVIRONMENT=production`, `COOKIE_SECURE=1`, `DB_SSL=1`.
5. Genera cada clave con `python -c "import secrets; print(secrets.token_urlsafe(48))"`.
6. Ejecuta `python -m backend.tools.bootstrap_vercel` e ingresa de forma interactiva
   los datos de la primera cuenta de RR. HH. El programa no borra datos existentes.

Si el proveedor utiliza un certificado de autoridad privada, consulta su guía para
TLS y configura `DB_SSL_CA` con la ruta local al certificado confiable; Vercel
requiere gestionar ese certificado en el entorno de ejecución de forma segura.

## Ruta rápida: publicar con Vercel CLI (sin GitHub)

Si no quieres crear GitHub, después de completar **Paso 1 y Paso 2**:

1. Instala Node.js desde https://nodejs.org y abre **PowerShell**.
2. Entra a la carpeta descomprimida que contiene `app.py`.
3. Ejecuta `npx vercel login` e inicia sesión con tu cuenta de Vercel.
4. Ejecuta `npx vercel link`, crea o enlaza el proyecto con la configuración por defecto.
5. Abre https://vercel.com/dashboard y ve a tu proyecto > Settings > Environment Variables.
6. Agrega las variables del **Paso 5** para Production. No pegues `.env` en el repositorio.
7. Regresa a PowerShell y ejecuta `npx vercel --prod`.
8. El comando mostrará una URL HTTPS; realiza las pruebas del **Paso 6**.

Puedes omitir por completo los pasos GitHub si eliges este método.

## Paso 3. Crea repositorio GitHub privado

Desde esta misma carpeta:

```bash
git init
git add .
git status --short
git commit -m "Adaptar Colegio Microservicios a Vercel FastAPI"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/COLEGIO_MICROSERVICIOS.git
git push -u origin main
```

**Verifica `git status` antes de confirmar**: no deben aparecer `backend/.env`,
credenciales, PDF privados, bases locales ni copias de seguridad. Crea primero
un repositorio **privado** vacío en GitHub. No subas el RAR original.

## Paso 4. Importa el repositorio en Vercel

1. Entra a https://vercel.com/new.
2. Import Git Repository > elige `COLEGIO_MICROSERVICIOS`.
3. Root Directory: raíz que contiene `app.py` y `requirements.txt`.
4. Framework Preset: **FastAPI** (también se define en `vercel.json`).
5. No configures `npm build`, ni `Dockerfile`, ni Output Directory.
6. **Antes del Deploy**, configura variables del siguiente paso.

## Paso 5. Variables de entorno (Production)

En Settings > Environment Variables, configura las siguientes claves. Copia
los VALORES privados desde tu `backend/.env`, **nunca del ejemplo literalmente**:

```
DB_MODE=mysql
DB_HOST=...
DB_PORT=3306
DB_USER=...
MYSQL_PASSWORD=...
DB_SSL=1
IDENTITY_DB_NAME=colegio_identidad
REQUESTS_DB_NAME=colegio_solicitudes
CLOUD_PDF_STORAGE=database
ENVIRONMENT=production
COOKIE_SECURE=1
JWT_SECRET=<secreto_1_48+>
INTERNAL_SERVICE_KEY=<secreto_2_48+>
SSO_SESSION_SECRET=<secreto_3_48+>
UPDATE_EVIDENCE_VALIDATED=0
```

`VERCEL` lo crea la plataforma automáticamente. No añadir `.env` al repositorio.
La autenticación SSO con Google/Microsoft es opcional; si la activas, deberás
registrar las URLs de callback de tu dominio HTTPS y el correspondiente
`OAUTH_BASE_URL`.

## Paso 6. Despliega y comprueba

1. Pulsa **Deploy** y copia el dominio `https://<tu-proyecto>.vercel.app`.
2. Comprueba `/health` y `/health/ready`; el segundo debe indicar `ok:true`.
3. Entra con la cuenta de RR. HH. creada en el Paso 2.
4. Prueba registro pendiente de autorización, inicio de sesión, un trámite,
   subida y descarga de un PDF pequeño y reportes CSV.
5. Verifica en el dashboard MySQL que persisten los datos tras un nuevo despliegue.

Si una función responde 500: revisa Vercel > Deployments > Functions > Logs
(la causa habitual es conexión de MySQL, secreto omitido o tablas sin inicializar).
Si devuelve 413: el PDF excede el límite HTTP; aquí se admite hasta 4 MB.

## Precauciones

- La limitación de intentos del gateway está en memoria y **no es distribuida**:
  antes de admitir usuarios reales, sustituye esta defensa por rate limiting
  compartido y revisa seguridad, permisos, privacidad y respaldo de MySQL.
- Las solicitudes médicas pueden incluir información sensible; usa solamente
  registros ficticios durante la evaluación de la nube.
- Nunca publiques credenciales ni contraseñas de colaboradores en Git.
- El alojamiento puede generar cargos tanto en Vercel como en MySQL.
- Esta versión fue adaptada y probada localmente, pero el despliegue en tu
  cuenta Vercel y la conexión real a tu MySQL dependen de sus credenciales.
