# MySQL 8 persistente en Railway

El proyecto utiliza **dos bases de datos**: `colegio_identidad` (usuarios y sesiones lógicas) y `colegio_solicitudes` (expedientes, historial, adjuntos y mediciones). El servidor MySQL se encuentra en una cuenta de Railway independiente de Vercel. **No se incluyen usuarios de MySQL ni contraseñas en este repositorio.**

## Configuración de producción

En Vercel, en *Settings > Environment Variables*, configurar con valores privados y verificables:

```env
DB_MODE=mysql
DB_HOST=<host publico de tu MySQL>
DB_PORT=<puerto TCP externo, no asumir 3306>
DB_USER=<usuario limitado a estas dos bases>
MYSQL_PASSWORD=<secreto privado, no subir a GitHub>
DB_SSL=1
IDENTITY_DB_NAME=colegio_identidad
REQUESTS_DB_NAME=colegio_solicitudes
CLOUD_PDF_STORAGE=database
ENVIRONMENT=production
COOKIE_SECURE=1
JWT_SECRET=<secreto independiente>
INTERNAL_SERVICE_KEY=<segundo secreto independiente>
SSO_SESSION_SECRET=<tercer secreto independiente>
```

La aplicación requiere conexión MySQL TLS con certificado válido para uso con datos sensibles. Si el endpoint TCP no presenta TLS verificable, configura CA/conexión segura **antes** de activar `DB_SSL=1`; no introduzcas datos personales hasta validarlo.

## Inicialización y conservación de datos

- El SQL `database/esquema_colegio.sql` define la estructura, **no** exporta registros de producción.
- Una instalación limpia debe crear las bases y tablas antes de iniciar la aplicación.
- En una instalación existente, haz respaldo antes de aplicar cambios de esquema; nunca elimines el volumen con datos.
- Para crear la cuenta administrativa inicial desde un entorno autorizado, utiliza `backend/tools/bootstrap_vercel.py` siguiendo sus requisitos, sin comprometer secretos.

## Comprobaciones

`/health/ready` debe responder HTTP 200 con `ok: true`; después valida en la aplicación inicio de sesión, creación de usuarios, solicitudes y que los datos permanezcan tras un redeploy.

Los respaldos **reales** deben realizarse desde Railway o con `mysqldump` mediante conexión privada, nunca guardarse aquí. Railway requiere plan activo para conservar recursos y volúmenes.
