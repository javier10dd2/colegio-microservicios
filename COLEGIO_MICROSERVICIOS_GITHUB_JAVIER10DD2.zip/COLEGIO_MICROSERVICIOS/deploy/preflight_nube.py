#!/usr/bin/env python3
"""Valida solo presencia/formato de variables, sin imprimir secretos."""
from pathlib import Path
import re
import sys

path=Path(__file__).resolve().parents[1]/'.env'
if not path.is_file():
    sys.exit('Falta .env: copia .env.example a .env y configura valores propios.')
values={}
for line in path.read_text(encoding='utf-8-sig').splitlines():
    if '=' not in line or line.lstrip().startswith('#'):
        continue
    k,v=line.split('=',1)
    values[k.strip()]=v.strip().strip('"').strip("'")
errors=[]
for key in ('JWT_SECRET','INTERNAL_SERVICE_KEY','SSO_SESSION_SECRET'):
    val=values.get(key,'')
    if len(val)<32 or 'CAMBIAR' in val.upper():
        errors.append(key+' requiere un secreto nuevo de al menos 32 caracteres')
for key in ('MYSQL_ROOT_PASSWORD','MYSQL_PASSWORD'):
    val=values.get(key,'')
    if len(val)<16 or 'CAMBIAR' in val.upper():
        errors.append(key+' requiere un secreto nuevo de al menos 16 caracteres')
secrets=[values.get(k,'') for k in ('JWT_SECRET','INTERNAL_SERVICE_KEY','SSO_SESSION_SECRET','MYSQL_ROOT_PASSWORD','MYSQL_PASSWORD')]
if len(set(secrets))!=len(secrets):
    errors.append('Los cinco secretos deben ser diferentes entre sí')
domain=values.get('SITE_DOMAIN','')
if not re.fullmatch(r'(?=.{4,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}',domain.lower()) or 'tudominio.com' in domain.lower():
    errors.append('SITE_DOMAIN requiere un dominio/subdominio real con DNS A hacia la VPS')
if errors:
    print('CONFIGURACIÓN INCOMPLETA:')
    for err in errors:
        print(' -',err)
    sys.exit(1)
print('Validación básica correcta. No reemplaza las pruebas de despliegue y seguridad.')
