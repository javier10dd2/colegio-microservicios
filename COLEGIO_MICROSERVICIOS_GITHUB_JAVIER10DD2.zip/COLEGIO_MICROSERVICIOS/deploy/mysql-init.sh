#!/bin/sh
set -eu
# La imagen oficial inicializa usuario "colegio_app" para la primera base.
# El servicio de solicitudes necesita su base separada.
mysql -uroot -p"$MYSQL_ROOT_PASSWORD" <<'SQL'
CREATE DATABASE IF NOT EXISTS `colegio_solicitudes` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
GRANT ALL PRIVILEGES ON `colegio_solicitudes`.* TO 'colegio_app'@'%';
FLUSH PRIVILEGES;
SQL
