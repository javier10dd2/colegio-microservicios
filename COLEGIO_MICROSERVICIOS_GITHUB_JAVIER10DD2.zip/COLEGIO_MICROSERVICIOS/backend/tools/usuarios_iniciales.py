"""Alta interactiva y segura de la primera cuenta autorizada de Recursos Humanos.

No contiene credenciales ni correos personales. Ejecutar después de preparar MySQL.
"""
from pathlib import Path
import os
import sys
from getpass import getpass
from sqlalchemy import select

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'backend'))
from backend.config import load_config
load_config()
if os.getenv('DB_MODE', 'mysql') != 'mysql':
    raise SystemExit('Esta herramienta usa MySQL. Comprueba backend/.env.')
from services.identity.main import SessionLocal, User, migrate_schema
from common.security import password_hash


def run():
    print('Creación segura de la cuenta responsable de Recursos Humanos.')
    print('No se eliminarán ni modificarán cuentas existentes.')
    nombre = ' '.join(input('Nombre completo de la persona autorizada: ').strip().split())
    correo = input('Correo electrónico institucional: ').strip().lower()
    if len(nombre) < 3 or '@' not in correo or len(correo) > 190:
        raise SystemExit('Nombre o correo inválido.')
    password = getpass('Contraseña inicial (12 caracteres o más): ')
    if len(password) < 12 or password != getpass('Repite la contraseña: '):
        raise SystemExit('Contraseña demasiado corta o no coincide.')
    migrate_schema()
    with SessionLocal() as db:
        if db.scalar(select(User.id).where(User.email == correo)):
            raise SystemExit('La cuenta ya existe; adminístrala desde Recursos Humanos.')
        # Primer administrador, nunca reemplazar ni elevar automáticamente otra cuenta.
        if db.scalar(select(User.id).where(User.role == 'RRHH', User.active == True)):
            raise SystemExit('Ya existe RR. HH. activo; no crear otra cuenta privilegiada por consola.')
        db.add(User(name=nombre, email=correo, role='RRHH', active=True,
                    can_authorize=False, password_hash=password_hash(password)))
        db.commit()
    print('Cuenta creada. Los permisos para autorizar trámites deben validarse con el colegio.')


if __name__ == '__main__':
    run()
