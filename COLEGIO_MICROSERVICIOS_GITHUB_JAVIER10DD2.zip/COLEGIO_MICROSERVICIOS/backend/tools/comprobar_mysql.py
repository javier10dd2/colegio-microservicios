"""Comprueba las dos bases MySQL sin mezclar metadatos de distintos microservicios."""
from __future__ import annotations
import os
import subprocess
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from backend.config import load_config
load_config()

def main():
    if os.getenv('DB_MODE', 'mysql') != 'mysql':
        raise SystemExit('ERROR: DB_MODE debe ser mysql en backend/.env.')
    env = os.environ.copy()
    env['DB_MODE'] = 'mysql'
    env['PYTHONPATH'] = str(ROOT / 'backend') + os.pathsep + env.get('PYTHONPATH','')
    # Each service runs independently; their SQLAlchemy models must not share a metadata registry.
    checks = [
        ('Identidad', '''from services.identity.main import engine, migrate_schema, User
from sqlalchemy import select, func
import time
migrate_schema()
with engine.connect() as c:
    t=time.perf_counter()
    count=c.execute(select(func.count()).select_from(User)).scalar_one()
    active=c.execute(select(func.count()).select_from(User).where(User.active.is_(True))).scalar_one()
    print(c.exec_driver_sql('SELECT DATABASE()').scalar_one(), '— usuarios:',count,'(activos:',active,') - consulta:',round((time.perf_counter()-t)*1000,1),'ms')'''),
        ('Solicitudes', '''from services.requests.main import engine, migrate, Request, Notification, Event
from sqlalchemy import select, func
import time
migrate()
with engine.connect() as c:
    t=time.perf_counter()
    reales=c.execute(select(func.count()).select_from(Request).where(Request.is_demo.is_(False))).scalar_one()
    ejemplos=c.execute(select(func.count()).select_from(Request).where(Request.is_demo.is_(True))).scalar_one()
    avisos=c.execute(select(func.count()).select_from(Notification)).scalar_one()
    historial=c.execute(select(func.count()).select_from(Event)).scalar_one()
    print(c.exec_driver_sql('SELECT DATABASE()').scalar_one(), '— reales:',reales,'; de prueba:',ejemplos,'; avisos:',avisos,'; historial:',historial,'- consulta:',round((time.perf_counter()-t)*1000,1),'ms')'''),
    ]
    print('Verificando bases y creando únicamente las tablas faltantes...')
    for label, code in checks:
        print(label + ':', flush=True)
        result = subprocess.run([sys.executable, '-c', code], cwd=ROOT, env=env)
        if result.returncode != 0:
            print('ERROR MYSQL en el servicio:', label)
            print('Comprueba MySQL en XAMPP y vuelve a ejecutar la tarea 03.')
            raise SystemExit(1)
    print('CONEXIÓN Y TABLAS MYSQL CORRECTAS. No se borraron registros.')

if __name__=='__main__': main()
