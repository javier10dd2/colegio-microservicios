"""Diagnostica la velocidad local sin modificar las bases ni mostrar contraseñas."""
from __future__ import annotations
from getpass import getpass
import http.cookiejar
import json
import statistics
import sys
import time
import urllib.error
import urllib.request

BASE = 'http://127.0.0.1:8080'
client = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))


def test(path: str, repeat: int=3, method: str='GET', payload: dict | None=None) -> int | None:
    samples = []
    status = None
    for _ in range(repeat):
        data = json.dumps(payload).encode('utf-8') if payload else None
        headers = {'Content-Type': 'application/json'} if data else {}
        request = urllib.request.Request(BASE+path, headers=headers, data=data, method=method)
        started = time.perf_counter()
        try:
            with client.open(request, timeout=12) as response:
                response.read()
                status = response.status
        except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError) as error:
            print(f'{path:30} ERROR: {error}')
            return None
        samples.append((time.perf_counter()-started)*1000)
    mediana = statistics.median(samples)
    print(f'{path:30} HTTP {status} | mediana {mediana:6.0f} ms | máx {max(samples):6.0f} ms')
    return status


print('DIAGNÓSTICO LOCAL: http://127.0.0.1:8080')
print('No modifica expedientes, usuarios ni datos. No guarda contraseñas.\n')
for path in ('/', '/static/style.css', '/static/app.js', '/health/ready', '/auth/providers'):
    test(path)

if sys.stdin.isatty():
    print('\nOpcional: medir también las consultas autenticadas.')
    correo = input('Correo del usuario (Enter para omitir): ').strip()
    if correo:
        clave = getpass('Contraseña: ')
        if test('/api/identity/auth/login', 1, 'POST', {'email': correo, 'password': clave}) == 200:
            for path in ('/api/identity/auth/me', '/api/requests/bootstrap',
                         '/api/requests/requests', '/api/requests/notifications'):
                test(path)
            if input('¿La cuenta es RR. HH.? [s/N] ').strip().lower() == 's':
                test('/api/identity/users')
                test('/api/reports/summary')

print('\nInterpretación: si localhost responde rápido pero Ports tarda mucho,')
print('el retraso probablemente está en el túnel o la conexión de internet.')
print('En Chrome, abre F12 > Network y compara los tiempos de localhost y el enlace externo.')
