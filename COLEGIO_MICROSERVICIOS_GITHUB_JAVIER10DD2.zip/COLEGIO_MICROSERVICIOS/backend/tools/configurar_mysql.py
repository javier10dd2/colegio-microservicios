"""Configura las credenciales del MySQL de XAMPP sin modificar los datos existentes."""
from __future__ import annotations
import getpass
import os
import secrets
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from backend.config import load_config
load_config()


def pedir(etiqueta: str, valor: str) -> str:
    r = input(f'{etiqueta} [{valor}]: ').strip()
    return r or valor


def main():
    print('CONFIGURACIÓN DE MYSQL (XAMPP)')
    print('Inicia MySQL en el panel de XAMPP antes de continuar.')
    print('El sistema web usará 8080; Apache puede permanecer en 80. MySQL normalmente usa 3306.')
    host = pedir('Servidor', os.getenv('DB_HOST', '127.0.0.1'))
    port_string = pedir('Puerto MySQL', os.getenv('DB_PORT', '3306'))
    usuario = pedir('Usuario MySQL', os.getenv('DB_USER', 'root'))
    try:
        puerto = int(port_string)
        if not 1 <= puerto <= 65535: raise ValueError()
    except ValueError:
        raise SystemExit('ERROR: Puerto MySQL inválido. Prueba 3306.')
    stored_password = os.getenv('MYSQL_PASSWORD', '')
    if stored_password:
        password = getpass.getpass('Contraseña MySQL (Enter = conservar configuración anterior): ') or stored_password
    else:
        password = getpass.getpass('Contraseña MySQL (Enter = sin contraseña, predeterminado de XAMPP): ')
    # Not printed to console or written to source code.
    if '\n' in password or '\r' in password:
        raise SystemExit('ERROR: No se aceptan saltos de línea en la contraseña.')
    try:
        import pymysql
        conn = pymysql.connect(host=host, port=puerto, user=usuario, password=password,
                               connect_timeout=4, read_timeout=5, write_timeout=5)
        with conn.cursor() as cursor:
            cursor.execute('SELECT VERSION()')
            version = cursor.fetchone()[0]
            for db in ('colegio_identidad', 'colegio_solicitudes'):
                cursor.execute('CREATE DATABASE IF NOT EXISTS `'+db+'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci')
        conn.close()
    except ImportError:
        raise SystemExit('ERROR: Instala primero dependencias (tarea 02). Falta PyMySQL.')
    except Exception as error:
        print('ERROR: No se pudo conectar o preparar las dos bases MySQL.')
        print('Detalle:', str(error).splitlines()[0])
        print('Comprueba que MySQL esté iniciado en XAMPP, el puerto 3306 y la contraseña.')
        print('Si no tienes permisos de CREATE DATABASE, importa database/esquema_colegio.sql en phpMyAdmin.')
        raise SystemExit(1)
    path = ROOT / 'backend' / '.env'
    existing = {}
    if path.is_file():
        for line in path.read_text(encoding='utf-8-sig').splitlines():
            if line.strip() and not line.lstrip().startswith('#') and '=' in line:
                k, v = line.split('=', 1)
                existing[k.strip()] = v.strip()
    existing.update({
        'DB_MODE': 'mysql', 'DB_HOST': host, 'DB_PORT': str(puerto),
        'DB_USER': usuario, 'MYSQL_PASSWORD': password,
        'IDENTITY_DB_NAME':'colegio_identidad', 'REQUESTS_DB_NAME':'colegio_solicitudes',
        'GATEWAY_PORT': '8080',
        'GATEWAY_HOST': '127.0.0.1',
        'PRIMARY_RRHH_EMAIL': existing.get('PRIMARY_RRHH_EMAIL', ''),
    })
    existing.setdefault('JWT_SECRET', secrets.token_urlsafe(48))
    existing.setdefault('INTERNAL_SERVICE_KEY', secrets.token_urlsafe(48))
    if not existing.get('JWT_SECRET'): existing['JWT_SECRET'] = secrets.token_urlsafe(48)
    if not existing.get('INTERNAL_SERVICE_KEY'): existing['INTERNAL_SERVICE_KEY'] = secrets.token_urlsafe(48)
    path.write_text('\n'.join(f'{k}={v}' for k, v in existing.items()) + '\n', encoding='utf-8')
    print('CONEXIÓN OK: MySQL/MariaDB', version)
    print('Bases preparadas: colegio_identidad y colegio_solicitudes')
    print('Configuración guardada en backend/.env (no se distribuye).')
    print('Continúa con la tarea 04 para crear tablas y verificar MySQL.')


if __name__ == '__main__':
    try: main()
    except (KeyboardInterrupt, EOFError): raise SystemExit('Configuración cancelada.')
