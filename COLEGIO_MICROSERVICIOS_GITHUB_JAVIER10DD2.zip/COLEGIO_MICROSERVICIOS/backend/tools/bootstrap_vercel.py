"""Crear tablas y primera cuenta RR.HH. desde tu PC contra MySQL remoto.

Requiere backend/.env (privado) con DB_MODE=mysql. No elimina información.
Nunca se ejecuta automáticamente al recibir peticiones públicas en Vercel.
"""
from __future__ import annotations
import os
import sys
from pathlib import Path
from getpass import getpass
from sqlalchemy import select

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'backend'))
from backend.config import load_config
load_config()

if os.getenv('DB_MODE') != 'mysql':
    raise SystemExit('Por seguridad, solo se permite DB_MODE=mysql para la nube.')
if os.getenv('DB_HOST','') in ('', '127.0.0.1', 'localhost'):
    raise SystemExit('Configura DB_HOST del servidor MySQL remoto.')
if os.getenv('ENVIRONMENT') != 'production':
    raise SystemExit('Configura ENVIRONMENT=production y secretos privados antes de continuar.')

# Importar/migrar en orden: las tablas de identidad NO se instalan en la DB de solicitudes.
from services.identity import main as identity
identity.migrate_schema()
print('OK: tablas de identidad listas.')
from services.requests import main as requests
requests.migrate()
print('OK: tablas de solicitudes, catálogos y documentos listas.')

with identity.SessionLocal() as db:
    if db.scalar(select(identity.User.id).where(identity.User.role == 'RRHH', identity.User.active == True)):
        print('Existe una cuenta activa de RR. HH. No se crea otra. Listo.')
        raise SystemExit(0)

name = ' '.join(input('Nombre completo del primer responsable de RR. HH.: ').strip().split())
email = input('Correo institucional: ').strip().lower()
if len(name) < 3 or '@' not in email or len(email) > 190:
    raise SystemExit('Nombre o correo inválidos.')
password = getpass('Contraseña inicial (12 o más caracteres): ')
if len(password) < 12 or password != getpass('Repite la contraseña: '):
    raise SystemExit('Las contraseñas no coinciden o tienen menos de 12 caracteres.')
with identity.SessionLocal() as db:
    if db.scalar(select(identity.User.id).where(identity.User.email == email)):
        raise SystemExit('Ese correo ya existe. Habilita la cuenta desde Recursos Humanos.')
    if db.scalar(select(identity.User.id).where(identity.User.role == 'RRHH', identity.User.active == True)):
        raise SystemExit('Otra sesión creó RR. HH. primero. No duplicar permisos.')
    db.add(identity.User(name=name,email=email,password_hash=identity.password_hash(password),
                         role='RRHH',active=True,can_authorize=False))
    db.commit()
print('OK: cuenta responsable creada (sin permiso para autorizar hasta validación institucional).')
