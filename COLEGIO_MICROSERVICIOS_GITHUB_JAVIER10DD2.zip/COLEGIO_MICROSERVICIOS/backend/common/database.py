import os
from pathlib import Path
from sqlalchemy import create_engine
from sqlalchemy.engine import URL
from sqlalchemy.orm import sessionmaker, DeclarativeBase

class Base(DeclarativeBase):
    pass

def get_database(name:str, env_key:str):
    default_dir=Path(os.getenv('DATA_DIR','./data')).resolve()
    if os.getenv('DB_MODE') != 'mysql':
        default_dir.mkdir(parents=True, exist_ok=True)
    if os.getenv('DB_MODE') == 'postgres':
        url=URL.create('postgresql+psycopg',username=os.getenv('DB_USER','colegio'),
            password=os.environ['POSTGRES_PASSWORD'],host=os.getenv('DB_HOST','postgres'),port=5432,
            database=os.getenv('DB_NAME',name))
    elif os.getenv('DB_MODE') == 'mysql':
        url=URL.create('mysql+pymysql',username=os.getenv('DB_USER','root'),
            password=os.getenv('MYSQL_PASSWORD',''),host=os.getenv('DB_HOST','127.0.0.1'),
            port=int(os.getenv('DB_PORT','3306')),database=os.getenv(('IDENTITY_DB_NAME' if name=='identidad' else 'REQUESTS_DB_NAME'),'colegio_'+name))
    else:
        url=os.getenv(env_key) or 'sqlite:///'+str(default_dir/(name+'.db'))
    if str(url).startswith('sqlite:'):
        kw={'connect_args':{'check_same_thread':False}}
    else:
        kw={'pool_pre_ping':True,'pool_size':2 if os.getenv('VERCEL') else 8,
            'max_overflow':1 if os.getenv('VERCEL') else 8,
            'pool_recycle':1200,'pool_timeout':5}
        if os.getenv('DB_MODE')=='mysql':
            kw['connect_args']={'connect_timeout':4,'read_timeout':10,'write_timeout':10,'charset':'utf8mb4'}
            if os.getenv('DB_SSL', '0') == '1':
                kw['connect_args']['ssl_verify_cert'] = True
                kw['connect_args']['ssl_verify_identity'] = True
                # Para autoridades privadas, indicar CA confiable en DB_SSL_CA.
                if os.getenv('DB_SSL_CA'):
                    kw['connect_args']['ssl_ca'] = os.getenv('DB_SSL_CA')
    engine=create_engine(url,**kw)
    return engine, sessionmaker(autocommit=False,autoflush=False,bind=engine,expire_on_commit=False)
