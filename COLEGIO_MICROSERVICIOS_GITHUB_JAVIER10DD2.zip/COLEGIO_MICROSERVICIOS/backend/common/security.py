"""Autenticación compartida por firma JWT; cada servicio valida sin compartir tablas."""
import os
import hmac
import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from fastapi import HTTPException, Header
import jwt

_DEV_SECRET = 'cambiar-esta-clave-local-antes-de-publicar-2026-minimo-32-caracteres'
SECRET = os.getenv('JWT_SECRET', _DEV_SECRET)
if os.getenv('ENVIRONMENT') == 'production' and (SECRET == _DEV_SECRET or len(SECRET)<32):
    raise RuntimeError('En producción JWT_SECRET debe ser una clave única y robusta (32+ caracteres).')
INTERNAL_KEY = os.getenv('INTERNAL_SERVICE_KEY', 'solo-desarrollo-cambiar-clave-de-servicios')
if os.getenv('ENVIRONMENT') == 'production':
    if len(INTERNAL_KEY) < 32 or INTERNAL_KEY == SECRET or INTERNAL_KEY == 'solo-desarrollo-cambiar-clave-de-servicios':
        raise RuntimeError('Producción exige INTERNAL_SERVICE_KEY aleatoria, exclusiva y de 32+ caracteres.')


def password_hash(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 350_000)
    return 'pbkdf2_sha256$350000$%s$%s' % (salt.hex(), dk.hex())


def password_verify(password: str, encoded: str) -> bool:
    try:
        alg, iterations, salt, digest = encoded.split('$')
        if alg != 'pbkdf2_sha256' or not 100000 <= int(iterations) <= 1000000:
            return False
        test = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(salt), int(iterations))
        return hmac.compare_digest(test, bytes.fromhex(digest))
    except (ValueError, AttributeError):
        return False


def make_token(user: dict) -> str:
    now = datetime.now(timezone.utc)
    payload={'sub':str(user['id']),'name':user['name'],'email':user['email'],'role':user['role'],
             'iat':now,'exp':now+timedelta(hours=8),'iss':'colegio-identidad'}
    return jwt.encode(payload,SECRET,algorithm='HS256')


def require_user(authorization: str|None=Header(default=None)) -> dict:
    if not authorization or not authorization.startswith('Bearer '):
        raise HTTPException(401,'Inicia sesión.')
    try:
        body=jwt.decode(authorization[7:],SECRET,algorithms=['HS256'],issuer='colegio-identidad')
        return {'id':int(body['sub']),'name':body['name'],'email':body['email'],'role':body['role']}
    except (jwt.PyJWTError,KeyError,ValueError):
        raise HTTPException(401,'Sesión expirada o inválida.')


def require_staff(user:dict):
    if user['role'] != 'RRHH':
        raise HTTPException(403,'Esta acción corresponde a Recursos Humanos.')


def check_internal(key: str|None):
    if not key or not hmac.compare_digest(key,INTERNAL_KEY):
        raise HTTPException(403,'Acceso reservado a servicios internos.')
