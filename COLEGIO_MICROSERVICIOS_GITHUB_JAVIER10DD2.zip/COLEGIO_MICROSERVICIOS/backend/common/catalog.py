"""Catálogo institucional de 10 trámites (Informe Semana 8, Colegio Pestalozzi).
Campos y criterios específicos pendientes de validación oficial con RR.HH.
"""
TYPES = {
 'VACACIONES':'Solicitud de vacaciones',
 'LICENCIA_CON_GOCE':'Licencia con goce de haber',
 'LICENCIA_SIN_GOCE':'Licencia sin goce de haber',
 'DESCANSO_MEDICO':'Descanso médico',
 'PERMISO_FALLECIMIENTO':'Permiso por fallecimiento de familiar',
 'PERMISO_PERSONAL':'Permiso personal',
 'CONSTANCIA_TRABAJO':'Constancia de trabajo',
 'CERTIFICADO_LABORAL':'Certificado de trabajo',
 'CERTIFICADO_PRACTICAS':'Certificado de prácticas',
 'BOLETA_PAGO':'Boleta de pago',
}
# Una definición compartida por frontend y backend: RF-04, RF-25.
FIELDS = {
 'VACACIONES':[('fecha_inicio','Inicio de vacaciones','date'),('fecha_fin','Fin de vacaciones','date')],
 'LICENCIA_CON_GOCE':[('motivo','Motivo','text'),('fecha_inicio','Desde','date'),('fecha_fin','Hasta','date')],
 'LICENCIA_SIN_GOCE':[('motivo','Motivo','text'),('fecha_inicio','Desde','date'),('fecha_fin','Hasta','date')],
 'DESCANSO_MEDICO':[('fecha_inicio','Inicio de descanso','date'),('fecha_fin','Fin de descanso','date')],
 'PERMISO_FALLECIMIENTO':[('parentesco','Parentesco','text'),('fecha_inicio','Desde','date'),('fecha_fin','Hasta','date')],
 'PERMISO_PERSONAL':[('motivo','Motivo','text'),('fecha','Fecha','date'),('hora_inicio','Desde','time'),('hora_fin','Hasta','time')],
 'CONSTANCIA_TRABAJO':[('finalidad','Finalidad de la constancia','text')],
 'CERTIFICADO_LABORAL':[('finalidad','Finalidad del certificado','text')],
 'CERTIFICADO_PRACTICAS':[('fecha_inicio','Inicio de prácticas','date'),('fecha_fin','Fin de prácticas','date')],
 'BOLETA_PAGO':[('periodo','Periodo de pago (AAAA-MM)','month')],
}
# Estados del proceso descrito en el informe de Semana 8.
# EN_PROCESO se conserva para expedientes antiguos, sin ofrecerlo como paso manual.
STATUS = {
 'REGISTRADA':'Registrada',
 'EN_REVISION':'En revisión',
 'OBSERVADA':'Observada',
 'ATENDIDA':'Atendida',
 'ACEPTADA':'Aceptada',
 'RECHAZADA':'Rechazada',
 'CERRADA':'Cerrada',
 'EN_PROCESO':'En proceso',
}
# EN_REVISION se registra automáticamente en la primera apertura por RR. HH.
# ACEPTADA es una decisión autorizada, no sinónimo de recepción o revisión.
TRANSITIONS = {
 'REGISTRADA':(),
 'EN_REVISION':('OBSERVADA','ATENDIDA','ACEPTADA','RECHAZADA'),
 'OBSERVADA':('RECHAZADA',),
 'EN_PROCESO':('OBSERVADA','ATENDIDA','ACEPTADA','RECHAZADA'),
 'ATENDIDA':('CERRADA',),
 'ACEPTADA':('CERRADA',),
 'RECHAZADA':(),
 'CERRADA':(),
}
# Solo estos trámites pueden registrar una decisión formal de aceptación/denegación.
FORMAL_DECISION_TYPES = frozenset((
 'VACACIONES','LICENCIA_CON_GOCE','LICENCIA_SIN_GOCE',
 'PERMISO_FALLECIMIENTO','PERMISO_PERSONAL',
))

RESULTS = {
 'VACACIONES':('AUTORIZADA','DENEGADA'),
 'LICENCIA_CON_GOCE':('AUTORIZADA','DENEGADA'),
 'LICENCIA_SIN_GOCE':('AUTORIZADA','DENEGADA'),
 'PERMISO_FALLECIMIENTO':('AUTORIZADA','DENEGADA'),
 'PERMISO_PERSONAL':('AUTORIZADA','DENEGADA'),
 'DESCANSO_MEDICO':('DESCANSO_REGISTRADO',),
 'CONSTANCIA_TRABAJO':('CONSTANCIA_EMITIDA',),
 'CERTIFICADO_LABORAL':('CERTIFICADO_EMITIDO',),
 'CERTIFICADO_PRACTICAS':('CERTIFICADO_EMITIDO',),
 'BOLETA_PAGO':('BOLETA_DISPONIBLE',),
}
