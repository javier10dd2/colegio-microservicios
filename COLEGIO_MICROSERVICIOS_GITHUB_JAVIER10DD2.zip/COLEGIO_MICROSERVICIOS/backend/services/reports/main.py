"""Agregados calculados a partir del API de solicitudes, sin acceso directo a su BD."""
import os,statistics,csv,io
from datetime import datetime,timezone
import httpx
http_client=httpx.Client(timeout=5,limits=httpx.Limits(max_keepalive_connections=10,max_connections=20))
from fastapi import FastAPI,HTTPException,Depends
from fastapi.responses import Response
from common.catalog import STATUS,TYPES
from common.security import require_user,require_staff,INTERNAL_KEY
IDENTITY_URL=os.getenv('IDENTITY_URL','http://127.0.0.1:8001')
app=FastAPI(title='Colegio · Reportes')
REQUESTS_URL=os.getenv('REQUESTS_URL','http://127.0.0.1:8002')

def parsed(dt):
    if not dt:return None
    x=datetime.fromisoformat(dt.replace('Z','+00:00'))
    return x.replace(tzinfo=timezone.utc) if not x.tzinfo else x

def verified_user(token:dict=Depends(require_user)):
    try:
        res=http_client.get(f"{IDENTITY_URL}/internal/users/{token['id']}",headers={'X-Internal-Key':INTERNAL_KEY},timeout=5)
    except httpx.RequestError:raise HTTPException(503,'Identidad no disponible.')
    if res.status_code!=200:raise HTTPException(401,'Cuenta no habilitada.')
    return res.json()

@app.get('/health')
def health():return {'service':'reportes','ok':True}
@app.get('/summary')
def summary(user:dict=Depends(verified_user)):
    require_staff(user)
    try:
        r=http_client.get(REQUESTS_URL+'/internal/export',headers={'X-Internal-Key':INTERNAL_KEY},timeout=12)
        r.raise_for_status();dataset=r.json()
    except (httpx.RequestError,httpx.HTTPStatusError,ValueError):raise HTTPException(503,'No fue posible consultar el servicio de solicitudes.')
    requests=dataset['requests'];measurements=dataset['measurements']
    count={s:sum(x['status']==s for x in requests) for s in STATUS}
    # Una medición válida por expediente (la más reciente), coherente con el CSV.
    by_request_valid = {}
    for m in measurements:
        if m.get('correct') is True and m.get('seconds') is not None and 0 <= m['seconds'] <= 7200:
            rid = m['request_id']
            if rid not in by_request_valid or m.get('measurement_id', 0) > by_request_valid[rid].get('measurement_id', 0):
                by_request_valid[rid] = m
    times = [float(m['seconds']) for m in by_request_valid.values()]
    trace_ok=0
    timely_total=0;timely_ok=0;timely_unknown=0
    deadline=None
    raw=os.getenv('UPDATE_DEADLINE_HOURS','').strip()
    try:
        if raw and 0<float(raw)<=720:deadline=float(raw)
    except ValueError:pass
    validated_timestamps=os.getenv('UPDATE_EVIDENCE_VALIDATED','0')=='1'
    for req in requests:
        history=req.get('history',[])
        fields_ok=all(e.get('actor_id') and e.get('recorded_at') and e.get('to_status') for e in history)
        good=bool(history) and history[0]['kind']=='CREACION' and fields_ok and history[-1]['to_status']==req['status']
        if req['status'] in ('ATENDIDA','ACEPTADA','CERRADA','RECHAZADA'):
            good=good and any(e['kind']=='CAMBIO_ESTADO' and e['to_status']==req['status'] for e in history)
        if good:trace_ok+=1
        changes=[e for e in history if e['kind']=='CAMBIO_ESTADO']
        if changes:
            if deadline is None or not validated_timestamps:
                timely_unknown+=1
                continue
            deltas=[]
            for e in changes:
                a=parsed(e.get('effective_at'));b=parsed(e.get('recorded_at'))
                # Dos marcas idénticas generadas por el mismo guardado no prueban
                # la demora entre el cambio real y su comunicación.
                if not a or not b or a==b:deltas=[];break
                deltas.append((b-a).total_seconds()/3600)
            if len(deltas)!=len(changes):timely_unknown+=1;continue
            timely_total+=1
            if all(0<=x<=deadline for x in deltas):timely_ok+=1
    return {
      'total':len(requests),'demo_count':dataset.get('demo_count',0),
      'consultation_reads':dataset.get('consultation_reads',0),'state_updates':dataset.get('state_updates',0),
      'by_status':count,
      'by_type':{k:sum(x['type']==k for x in requests) for k in set(TYPES)|{x['type'] for x in requests}},
      'consultation':{'valid':len(times),'mean_seconds':round(statistics.mean(times),2) if times else None,
                      'median_seconds':round(statistics.median(times),2) if times else None},
      'trace':{'complete':trace_ok,'evaluable':len(requests),'percent':round(100*trace_ok/len(requests),1) if requests else None},
      'timely':{'deadline_hours':deadline,'evidence_validated':validated_timestamps,'complete':timely_ok,'evaluable':timely_total,
                'missing_evidence':timely_unknown,'percent':round(100*timely_ok/timely_total,1) if timely_total else None},
      'note':'Indicadores operativos; no representan un contraste pretest–postest. La actualización oportuna exige marcas de tiempo independientes y criterios validados.'
    }

@app.get('/mediciones.csv')
@app.get('/posttest.csv',include_in_schema=False)
def export_posttest(user:dict=Depends(verified_user)):
    """Per-case evidence export. The CSV contains observed data, not imputed values."""
    require_staff(user)
    try:
        res=http_client.get(REQUESTS_URL+'/internal/export',headers={'X-Internal-Key':INTERNAL_KEY},timeout=20)
        res.raise_for_status()
        data=res.json()
    except (httpx.RequestError,httpx.HTTPStatusError,ValueError):
        raise HTTPException(503,'No fue posible obtener los datos de las mediciones.')
    raw=os.getenv('UPDATE_DEADLINE_HOURS','').strip()
    try:deadline=float(raw) if raw and 0<float(raw)<=720 else None
    except ValueError:deadline=None
    validated_timestamps=os.getenv('UPDATE_EVIDENCE_VALIDATED','0')=='1'
    by_request={}
    for m in data.get('measurements',[]):
        by_request.setdefault(m['request_id'],[]).append(m)
    rows=[]
    for req in data.get('requests',[]):
        history=req.get('history',[])
        fields_ok=all(e.get('actor_id') and e.get('recorded_at') and e.get('to_status') for e in history)
        trace_ok=bool(history) and history[0]['kind']=='CREACION' and fields_ok and history[-1]['to_status']==req['status']
        if req['status'] in ('ATENDIDA','ACEPTADA','CERRADA','RECHAZADA'):
            trace_ok=trace_ok and any(e['kind']=='CAMBIO_ESTADO' and e['to_status']==req['status'] for e in history)
        changes=[e for e in history if e['kind']=='CAMBIO_ESTADO']
        timely=''
        evidence='NO_APLICA' if not changes else ('SIN_PLAZO_APROBADO' if deadline is None else 'PENDIENTE_VALIDACION' if not validated_timestamps else 'COMPLETA')
        if changes and deadline is not None and validated_timestamps:
            diffs=[]
            for e in changes:
                a=parsed(e.get('effective_at'));b=parsed(e.get('recorded_at'))
                if not a or not b or a==b:
                    evidence='SIN_EVIDENCIA';break
                diffs.append((b-a).total_seconds()/3600)
            if evidence=='COMPLETA':timely='SI' if all(0<=x<=deadline for x in diffs) else 'NO'
        for_m=by_request.get(req['id'],[])
        valid=[m for m in for_m if m.get('correct') is True and m.get('seconds') is not None and 0<=float(m['seconds'])<=7200]
        # One row per request: last valid consultation. Others remain in the raw database.
        current=max(valid,key=lambda m:m['measurement_id']) if valid else None
        rows.append([req['code'],req['id'],req['type'],req['created_at'],req['status'],
                     current['measurement_id'] if current else '',
                     current['seconds'] if current else '',
                     'SI' if trace_ok else 'NO',
                     'SI' if changes else 'NO', evidence,timely,deadline if deadline is not None else '',
                     current['started_at'] if current else '',
                     current['ended_at'] if current else '',
                     'SI' if current and current.get('correct') else ('NO' if current else ''),
                     current['observer_id'] if current else '',
                     len(history),len(changes),history[-1]['recorded_at'] if history else '',
                     changes[-1].get('effective_at','') if changes else '',
                     changes[-1].get('recorded_at','') if changes else '',
                     (round((parsed(changes[-1]['recorded_at'])-parsed(changes[-1]['effective_at'])).total_seconds()/3600,3)
                      if changes and changes[-1].get('effective_at') and changes[-1].get('recorded_at')
                      else '')])
    columns=['codigo','id_solicitud','tipo_tramite','fecha_registro','estado',
             'id_medicion_valida','tiempo_consulta_segundos','trazabilidad_completa',
             'requiere_actualizacion','evidencia_actualizacion','actualizacion_oportuna','plazo_horas','inicio_medicion','fin_medicion','consulta_correcta','observador_id',
             'cantidad_eventos','cantidad_cambios_estado','ultimo_evento_registrado','cambio_efectivo',
             'cambio_registrado','desfase_ultimo_cambio_horas']
    stream=io.StringIO(newline='')
    writer=csv.writer(stream,delimiter=';',quoting=csv.QUOTE_MINIMAL)
    writer.writerow(columns)
    for row in rows:
        # Spreadsheet cell formula injection prevention when opened in Excel.
        writer.writerow([("'"+v if isinstance(v,str) and v.startswith(('=','+','-','@')) else v) for v in row])
    return Response('﻿'+stream.getvalue(),media_type='text/csv; charset=utf-8',
                    headers={'Content-Disposition':'attachment; filename="matriz_mediciones.csv"',
                             'Cache-Control':'no-store'})
