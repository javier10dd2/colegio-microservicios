"""Servicio independiente de expedientes, documentos y bitácora."""
from contextlib import asynccontextmanager
from datetime import datetime,timezone,date,timedelta
from pathlib import Path
from uuid import uuid4
import os,hashlib,statistics,json,re,secrets
import httpx
http_client=httpx.Client(timeout=5,limits=httpx.Limits(max_keepalive_connections=10,max_connections=20))
from fastapi import FastAPI,Depends,HTTPException,UploadFile,File,Header
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel,Field
from sqlalchemy import Integer,String,ForeignKey,DateTime,Text,Float,Boolean,LargeBinary,select,func,text,inspect,update
from sqlalchemy.orm import Mapped,mapped_column,relationship,Session,selectinload,load_only
from sqlalchemy.dialects.mysql import LONGBLOB
from urllib.parse import quote
from common.database import Base,get_database
from common.security import require_user,require_staff,check_internal,INTERNAL_KEY
from common.catalog import TYPES,FIELDS,STATUS,TRANSITIONS,RESULTS,FORMAL_DECISION_TYPES

engine,SessionLocal=get_database('solicitudes','REQUESTS_DATABASE_URL')
UPLOAD_DIR=Path(os.getenv('UPLOAD_DIR','./data/adjuntos')).resolve()
DB_PDF_STORAGE = os.getenv('CLOUD_PDF_STORAGE') == 'database'
if not DB_PDF_STORAGE:
    UPLOAD_DIR.mkdir(parents=True,exist_ok=True)
CLOUD_PDF_MAX_BYTES = 4 * 1024 * 1024
IDENTITY_URL=os.getenv('IDENTITY_URL','http://127.0.0.1:8001')

def utcnow():return datetime.now(timezone.utc)
def short_code(db, request_id:int, used:set[str]|None=None)->str:
    """Asigna un código aleatorio, único, de cinco dígitos (10000 a 99999).

    La clave primaria numérica del expediente es independiente de su código visible.
    """
    for _ in range(256):
        code=str(10000+secrets.randbelow(90000))
        if used is not None and code in used:
            continue
        if db.scalar(select(Request.id).where(Request.code==code)) is None:
            return code
    raise RuntimeError('No se pudo reservar un código de cinco dígitos. Reintenta el registro.')

def tz(v):return v.replace(tzinfo=timezone.utc) if v and not v.tzinfo else v
class Request(Base):
    __tablename__='solicitudes'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    code:Mapped[str]=mapped_column(String(32),unique=True,index=True)
    legacy_code:Mapped[str|None]=mapped_column(String(32),nullable=True)
    type:Mapped[str]=mapped_column(String(40),index=True)
    subject:Mapped[str]=mapped_column(String(180))
    description:Mapped[str]=mapped_column(Text)
    requester_id:Mapped[int]=mapped_column(Integer,index=True)
    requester_name:Mapped[str]=mapped_column(String(120))
    requester_email:Mapped[str]=mapped_column(String(190))
    assignee_id:Mapped[int|None]=mapped_column(Integer,nullable=True,index=True)
    assignee_name:Mapped[str|None]=mapped_column(String(120),nullable=True)
    status:Mapped[str]=mapped_column(String(25),default='REGISTRADA',index=True)
    is_demo:Mapped[bool]=mapped_column(Boolean,default=False,index=True)
    details_json:Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)
    updated_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)
    closed_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True)
    events:Mapped[list['Event']]=relationship(back_populates='request',cascade='all,delete-orphan',order_by='Event.id')
class Event(Base):
    __tablename__='historial'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    request_id:Mapped[int]=mapped_column(ForeignKey('solicitudes.id'),index=True)
    actor_id:Mapped[int]=mapped_column(Integer)
    actor_name:Mapped[str]=mapped_column(String(120))
    kind:Mapped[str]=mapped_column(String(30))
    from_status:Mapped[str|None]=mapped_column(String(25),nullable=True)
    to_status:Mapped[str]=mapped_column(String(25))
    detail:Mapped[str]=mapped_column(Text,default='')
    effective_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True)
    recorded_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)
    request:Mapped[Request]=relationship(back_populates='events')
class Attachment(Base):
    __tablename__='adjuntos'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    request_id:Mapped[int]=mapped_column(ForeignKey('solicitudes.id'),index=True)
    original_name:Mapped[str]=mapped_column(String(200))
    stored_name:Mapped[str]=mapped_column(String(50),unique=True)
    sha256:Mapped[str]=mapped_column(String(64))
    size:Mapped[int]=mapped_column(Integer)
    author_id:Mapped[int]=mapped_column(Integer)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)
class AttachmentContent(Base):
    """Contenido privado y persistente, accesible solo a través de adjuntos autorizados.

    Los archivos anteriores almacenados en disco se conservan para el modo Docker.
    """
    __tablename__ = 'adjuntos_contenido'
    stored_name: Mapped[str] = mapped_column(String(50), primary_key=True)
    content: Mapped[bytes] = mapped_column(LargeBinary().with_variant(LONGBLOB(), 'mysql'))

class ConsultationAccess(Base):
    """Apertura real del detalle por un usuario autenticado (no equivale al tiempo de búsqueda)."""
    __tablename__='consultas_expediente'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    request_id:Mapped[int]=mapped_column(ForeignKey('solicitudes.id'),index=True)
    viewer_id:Mapped[int]=mapped_column(Integer,index=True)
    viewed_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)

class Measurement(Base):
    __tablename__='mediciones_consulta'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    request_id:Mapped[int]=mapped_column(ForeignKey('solicitudes.id'),index=True)
    observer_id:Mapped[int]=mapped_column(Integer)
    started_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)
    ended_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True)
    seconds:Mapped[float|None]=mapped_column(Float,nullable=True)
    correct:Mapped[bool|None]=mapped_column(Boolean,nullable=True)

class StartConsultationMeasurement(BaseModel):
    request_id:int=Field(gt=0)

class FinishConsultationMeasurement(BaseModel):
    correct:bool

class Notification(Base):
    __tablename__='notificaciones'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    user_id:Mapped[int]=mapped_column(Integer,index=True)
    request_id:Mapped[int]=mapped_column(Integer,index=True)
    detail:Mapped[str]=mapped_column(String(250))
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)
    read_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True)

class Tramite(Base):
    __tablename__='tipos_tramite'
    code:Mapped[str]=mapped_column(String(40),primary_key=True)
    label:Mapped[str]=mapped_column(String(120))
    fields_json:Mapped[str]=mapped_column(Text)
    active:Mapped[bool]=mapped_column(Boolean,default=True)

def type_info(t):
    return {'key':t.code,'label':t.label,'fields':json.loads(t.fields_json),'active':bool(t.active)}

def add_notice(db,uid,rid,message):
    if not uid:return
    # Evita avisos duplicados en el mismo expediente si se repite una petición.
    cutoff=utcnow()-timedelta(seconds=2)
    exists=db.scalar(select(Notification.id).where(
        Notification.user_id==uid,Notification.request_id==rid,
        Notification.detail==message[:250],Notification.created_at>=cutoff).limit(1))
    if not exists:
        db.add(Notification(user_id=uid,request_id=rid,detail=message[:250]))

def migrate():
    Base.metadata.create_all(engine, tables=[Request.__table__, Event.__table__, Attachment.__table__, AttachmentContent.__table__, ConsultationAccess.__table__, Measurement.__table__, Notification.__table__, Tramite.__table__])
    cols={c['name'] for c in inspect(engine).get_columns('solicitudes')}
    with engine.begin() as conn:
        if 'details_json' not in cols:
            conn.execute(text('ALTER TABLE solicitudes ADD COLUMN details_json TEXT'))
        if 'is_demo' not in cols:
            conn.execute(text('ALTER TABLE solicitudes ADD COLUMN is_demo BOOLEAN NOT NULL DEFAULT 0'))
        if 'legacy_code' not in cols:
            conn.execute(text('ALTER TABLE solicitudes ADD COLUMN legacy_code VARCHAR(32) NULL'))
    with SessionLocal() as db:
        # Una sola conversión no destructiva: ID, adjuntos y eventos quedan intactos.
        # El código anterior se conserva para auditoría y compatibilidad de la carga inicial.
        rows=db.scalars(select(Request).order_by(Request.id)).all()
        used={r.code for r in rows if re.fullmatch(r'[0-9]{5}',r.code)}
        for r in rows:
            if re.fullmatch(r'[0-9]{5}',r.code):
                continue
            old_code=r.code
            new_code=short_code(db,r.id,used)
            r.legacy_code=r.legacy_code or old_code
            r.code=new_code
            used.add(new_code)
        db.commit()
    with SessionLocal() as db:
        # Los ejemplos antiguos pertenecían por error al usuario real de Trabajador.
        # Solo se corrigen ejemplos marcados y con el prefijo exclusivo de pruebas.
        db.query(Request).filter(Request.is_demo.is_(True), Request.legacy_code.like('SOL-PRUEBA-%'), Request.requester_id != 0).update(
            {Request.requester_id: 0,
             Request.requester_name: 'Registro de prueba',
             Request.requester_email: 'registro-prueba@invalid.local'},
            synchronize_session=False)
        for key,label in TYPES.items():
            if not db.get(Tramite,key):
                fields=[{'key':k,'label':v,'type':t,'required':True} for k,v,t in FIELDS[key]]
                db.add(Tramite(code=key,label=label,fields_json=json.dumps(fields,ensure_ascii=False)))
        db.commit()

@asynccontextmanager
async def lifespan(app):
    migrate()
    yield
app=FastAPI(title='Colegio · Expedientes / bandeja RRHH',lifespan=lifespan)
def db_dep():
    with SessionLocal() as db:yield db

def validate_fields(fields,raw):
    if not isinstance(raw,dict):raise HTTPException(422,'Completa los campos del trámite.')
    clean={}
    for f in fields:
        val=str(raw.get(f['key'],'')).strip()
        if f.get('required') and not val:raise HTTPException(422,'Campo obligatorio: '+f['label'])
        if len(val)>300:raise HTTPException(422,'Campo demasiado largo: '+f['label'])
        kind=f.get('type','text')
        try:
            if val and kind=='date':
                if not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])', val):raise ValueError()
                parsed=date.fromisoformat(val)
                if parsed.year < 1900 or parsed.year > 2100:raise ValueError()
            if val and kind=='month':
                if not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',val) or not 1900 <= int(val[:4]) <= 2100:raise ValueError()
            if val and kind=='time' and not re.fullmatch(r'([01]\d|2[0-3]):[0-5]\d',val):raise ValueError()
        except ValueError:raise HTTPException(422,'Formato inválido: '+f['label'])
        clean[f['key']]=val
    if clean.get('fecha_inicio') and clean.get('fecha_fin') and clean['fecha_fin']<clean['fecha_inicio']:
        raise HTTPException(422,'La fecha final no puede ser anterior a la inicial.')
    if clean.get('hora_inicio') and clean.get('hora_fin') and clean['hora_fin']<=clean['hora_inicio']:
        raise HTTPException(422,'La hora final debe ser posterior al inicio.')
    return clean

def staff_receiver():
    try:
        resp=http_client.get(IDENTITY_URL+'/internal/receiver',headers={'X-Internal-Key':INTERNAL_KEY},timeout=5)
    except httpx.RequestError:raise HTTPException(503,'No se puede consultar Recursos Humanos.')
    if resp.status_code!=200:raise HTTPException(503,'Configura primero una cuenta activa de Recursos Humanos.')
    return resp.json()

def verified_user(token:dict=Depends(require_user)):
    # Actualiza permisos con la BD de identidad en cada petición. Desactivación inmediata.
    try:
        res=http_client.get(f"{IDENTITY_URL}/internal/users/{token['id']}",headers={'X-Internal-Key':INTERNAL_KEY},timeout=5)
    except httpx.RequestError:
        raise HTTPException(503,'Autenticación temporalmente no disponible.')
    if res.status_code!=200:
        raise HTTPException(401,'La cuenta fue desactivada o cambió su autorización.')
    current=res.json()
    if current['role'] not in ('RRHH','TRABAJADOR'):
        raise HTTPException(403,'Rol institucional no válido.')
    return current

def request_preview(r,label=None):
    # Lightweight representation for the inbox. Full description and details
    # are loaded only when the user opens an individual expediente.
    return {'id':r.id,'code':r.code,'type':r.type,'type_name':label or TYPES.get(r.type,r.type),
            'subject':r.subject,'requester_name':r.requester_name,'assignee_name':r.assignee_name,
            'status':r.status,'status_name':STATUS.get(r.status,r.status), 'is_demo':bool(r.is_demo),
            'created_at':r.created_at.isoformat(),'updated_at':r.updated_at.isoformat()}

def req_to_dict(r,label=None):
    return {'id':r.id,'code':r.code,'type':r.type,'type_name':label or TYPES.get(r.type,r.type),
            'subject':r.subject,'description':r.description,'details':json.loads(r.details_json or '{}'),
            'requester_id':r.requester_id,'requester_name':r.requester_name,'requester_email':r.requester_email,
            'assignee_id':r.assignee_id,'assignee_name':r.assignee_name,'status':r.status,
            'status_name':STATUS.get(r.status,r.status),'is_demo':bool(r.is_demo),'created_at':r.created_at.isoformat(),
            'updated_at':r.updated_at.isoformat(),'closed_at':r.closed_at.isoformat() if r.closed_at else None}
def event_to_dict(e):
    return {'id':e.id,'request_id':e.request_id,'actor_id':e.actor_id,'actor_name':e.actor_name,
            'kind':e.kind,'from_status':e.from_status,'to_status':e.to_status,'detail':e.detail,
            'effective_at':e.effective_at.isoformat() if e.effective_at else None,
            'recorded_at':e.recorded_at.isoformat()}
def ensure_access(db,rid,user):
    r=db.get(Request,rid)
    if not r:raise HTTPException(404,'Solicitud no encontrada.')
    if user['role']=='TRABAJADOR' and (r.is_demo or r.requester_id!=user['id']):
        raise HTTPException(403,'No puedes acceder a este expediente.')
    return r

class NewRequest(BaseModel):
    type:str
    subject:str=Field(min_length=5,max_length=180)
    description:str=Field(min_length=10,max_length=4000)
    details:dict[str,str]=Field(default_factory=dict)
class NewTramite(BaseModel):
    key:str=Field(pattern=r'^[A-Z][A-Z0-9_]{2,39}$')
    label:str=Field(min_length=3,max_length=120)
    fields:list[dict]=Field(default_factory=list,max_length=12)
class TramiteUpdate(BaseModel):
    label:str|None=Field(default=None,min_length=3,max_length=120)
    active:bool|None=None
class ChangeStatus(BaseModel):
    status:str
    detail:str=Field(default='',max_length=2000)
    result_kind:str|None=None
class Subsanacion(BaseModel):
    detail:str=Field(default='',max_length=2000)
class Correccion(BaseModel):
    subject:str=Field(min_length=5,max_length=180)
    description:str=Field(min_length=10,max_length=4000)
    details:dict[str,str]=Field(default_factory=dict)
    reason:str=Field(default='',max_length=500)  # Compatibilidad con clientes anteriores; no se exige al trabajador.
class Comment(BaseModel):
    detail:str=Field(min_length=2,max_length=2000)

@app.get('/health')
def health():
    try:
        with engine.connect() as conn:conn.execute(text('SELECT 1'))
    except Exception:raise HTTPException(503,'Base de solicitudes no disponible.')
    return {'service':'solicitudes','ok':True,'database':os.getenv('DB_MODE','sqlite')}
@app.get('/types')
def types(user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    q=select(Tramite).order_by(Tramite.code)
    if user['role']=='TRABAJADOR':q=q.where(Tramite.active==True)
    return [type_info(t) for t in db.scalars(q)]
@app.post('/types',status_code=201)
def add_type(d:NewTramite,user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    require_staff(user)
    if db.get(Tramite,d.key):raise HTTPException(409,'Código de trámite existente.')
    validated=[]
    seen=set()
    for f in d.fields:
        key=str(f.get('key','')).strip().lower()
        label=str(f.get('label','')).strip()
        field_type=f.get('type')
        if not re.fullmatch(r'[a-z][a-z0-9_]{1,39}',key) or key in seen or not 2<=len(label)<=100 or field_type not in ('date','time','month','text'):
            raise HTTPException(422,'Los campos deben tener nombre y tipo válidos, sin duplicados.')
        seen.add(key)
        validated.append({'key':key,'label':label,'type':field_type,'required':bool(f.get('required',False))})
    db.add(Tramite(code=d.key,label=d.label.strip(),fields_json=json.dumps(validated,ensure_ascii=False)))
    db.commit();return {'ok':True}
@app.patch('/types/{key}')
def update_type(key:str,d:TramiteUpdate,user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    require_staff(user)
    t=db.get(Tramite,key)
    if not t:raise HTTPException(404,'Trámite no encontrado.')
    if d.label is not None:t.label=d.label.strip()
    if d.active is not None:t.active=d.active
    db.commit();return type_info(t)
@app.get('/statuses')
def statuses(user:dict=Depends(verified_user)):return STATUS
@app.post('/requests',status_code=201)
def create(d:NewRequest,user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    if user['role']!='TRABAJADOR':raise HTTPException(403,'Solo el trabajador registra una solicitud.')
    t=db.get(Tramite,d.type)
    if not t or not t.active:raise HTTPException(400,'Tipo de trámite no disponible.')
    details=validate_fields(json.loads(t.fields_json),d.details)
    assigned=staff_receiver() # única bandeja de RRHH, sin derivaciones manuales.
    r=Request(code='TEMP-'+uuid4().hex[:20],type=d.type,subject=d.subject.strip(),description=d.description.strip(),
       details_json=json.dumps(details,ensure_ascii=False),requester_id=user['id'],requester_name=user['name'],
       requester_email=user['email'],assignee_id=assigned['id'],assignee_name=assigned['name'],status='REGISTRADA')
    db.add(r);db.flush();r.code=short_code(db,r.id)
    db.add(Event(request_id=r.id,actor_id=user['id'],actor_name=user['name'],kind='CREACION',to_status='REGISTRADA',detail='Solicitud registrada; recibida automáticamente por RR.HH.',effective_at=utcnow()))
    add_notice(db,assigned['id'],r.id,f'Nueva solicitud: {r.code}')
    db.commit();db.refresh(r);return req_to_dict(r,t.label)
@app.get('/bootstrap')
def bootstrap(user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    """Una petición para datos de inicio: bandeja, trámites y estados."""
    q=select(Request).options(load_only(Request.id,Request.code,Request.type,Request.subject,
        Request.requester_name,Request.assignee_name,Request.status,Request.created_at,Request.updated_at,Request.is_demo))
    if user['role']=='TRABAJADOR':q=q.where(Request.requester_id==user['id'],Request.is_demo.is_(False))
    requests=db.scalars(q.order_by(Request.created_at.desc()).limit(500)).all()
    all_types=db.scalars(select(Tramite).order_by(Tramite.code)).all()
    return {'requests':[request_preview(r,next((t.label for t in all_types if t.code==r.type),None)) for r in requests],
            'types':[type_info(t) for t in all_types if user['role']=='RRHH' or t.active],
            'statuses':STATUS,'database':os.getenv('DB_MODE','sqlite')}

@app.get('/status/resumen')
def status_resumen(user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    # Conteos en la misma conexión real que usa la bandeja de este microservicio.
    q=select(func.count()).select_from(Request)
    if user['role']=='TRABAJADOR':
        q=q.where(Request.requester_id==user['id'],Request.is_demo.is_(False))
    visible=db.scalar(q) or 0
    total_pruebas=db.scalar(select(func.count()).select_from(Request).where(Request.is_demo.is_(True))) if user['role']=='RRHH' else None
    return {'database':str(db.get_bind().url.database),'visible':visible,'pruebas':total_pruebas}

@app.get('/requests')
def list_requests(status:str|None=None,type:str|None=None,query:str|None=None,date_from:date|None=None,date_to:date|None=None,user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    q=select(Request).options(load_only(Request.id,Request.code,Request.type,Request.subject,Request.requester_name,Request.assignee_name,Request.status,Request.created_at,Request.updated_at,Request.is_demo))
    if user['role']=='TRABAJADOR':q=q.where(Request.requester_id==user['id'],Request.is_demo.is_(False))
    if status and status in STATUS:q=q.where(Request.status==status)
    if type and type in TYPES:q=q.where(Request.type==type)
    if date_from:q=q.where(Request.created_at>=datetime.combine(date_from,datetime.min.time()))
    if date_to:q=q.where(Request.created_at<datetime.combine(date_to,datetime.max.time()))
    if query:
        value='%'+query[:80].strip()+'%'
        q=q.where((Request.code.ilike(value))|(Request.subject.ilike(value))|(Request.requester_name.ilike(value)))
    q=q.order_by(Request.created_at.desc()).limit(500)
    records=db.scalars(q).all()
    labels={t.code:t.label for t in db.scalars(select(Tramite))}
    return [request_preview(record,labels.get(record.type)) for record in records]
@app.get('/sync')
def sync(user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    """Versión ligera de la bandeja para refresco periódico sin descargar expedientes completos."""
    q=select(Request.id,Request.status,Request.updated_at)
    if user['role']=='TRABAJADOR':
        q=q.where(Request.requester_id==user['id'],Request.is_demo.is_(False))
    rows=db.execute(q.order_by(Request.id.desc()).limit(500)).all()
    return {'requests':[{'id':rid,'status':status,'updated_at':stamp.isoformat()} for rid,status,stamp in rows]}

@app.get('/requests/{rid}')
def detail(rid:int,track:bool=True,user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    r=ensure_access(db,rid,user)
    if track:
        # Solo abrir el detalle siendo RR. HH. inicia la revisión; consultar una
        # bandeja, notificación o el detalle del trabajador no cambia estados.
        # UPDATE condicional protege contra dobles aperturas y carreras.
        if user['role']=='RRHH' and r.status=='REGISTRADA':
            moment=utcnow()
            changed=db.execute(update(Request).where(
                Request.id==r.id,Request.status=='REGISTRADA').values(
                status='EN_REVISION',updated_at=moment))
            if changed.rowcount:
                db.add(Event(request_id=r.id,actor_id=user['id'],actor_name=user['name'],
                    kind='CAMBIO_ESTADO',from_status='REGISTRADA',to_status='EN_REVISION',
                    detail='Recursos Humanos abrió la solicitud e inició la revisión.',
                    effective_at=moment,recorded_at=moment))
                add_notice(db,r.requester_id,r.id,
                    f'Estado actualizado: solicitud {r.code} · En revisión')
            db.commit()
            db.refresh(r)
        if not r.is_demo:
            db.add(ConsultationAccess(request_id=r.id,viewer_id=user['id'],viewed_at=utcnow()))
            db.commit()
    att=db.scalars(select(Attachment).where(Attachment.request_id==rid).order_by(Attachment.id)).all()
    t=db.get(Tramite,r.type)
    return {**req_to_dict(r,t.label if t else None),'history':[event_to_dict(x) for x in r.events],
            'attachments':[{'id':x.id,'name':x.original_name,'size':x.size,'created_at':x.created_at.isoformat()} for x in att],
            'transitions':allowed_transitions(r,user) if user['role']=='RRHH' else [],
            'outcomes':list(RESULTS.get(r.type,('RESPUESTA_REGISTRADA',))),
            'authorized_to_decide':can_authorize(user)}
def can_authorize(user):
    # La facultad de aprobación debe estar acreditada para la cuenta.
    return user.get('role') == 'RRHH' and user.get('can_authorize') is True

def allowed_transitions(r,user):
    choices=list(TRANSITIONS.get(r.status,()))
    # La aceptación administrativa solo corresponde a ausencias y permisos,
    # y exclusivamente cuando RR. HH. posee la atribución confirmada.
    if r.type in FORMAL_DECISION_TYPES:
        # Para vacaciones/licencias/permisos solo cabe una decisión formal,
        # no «Atendida» con un resultado distinto de la autorización.
        choices=[x for x in choices if x!='ATENDIDA']
        if not can_authorize(user):
            choices=[x for x in choices if x not in ('ACEPTADA','RECHAZADA')]
    else:
        choices=[x for x in choices if x!='ACEPTADA']
    return choices

@app.post('/requests/{rid}/status')
def change(rid:int,d:ChangeStatus,user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    require_staff(user);r=ensure_access(db,rid,user)
    if d.status not in allowed_transitions(r,user):
        raise HTTPException(400,'Este estado no corresponde al trámite o a tus permisos.')
    if d.status in ('OBSERVADA','RECHAZADA','ATENDIDA','ACEPTADA','CERRADA') and len(d.detail.strip())<5:
        raise HTTPException(422,'Escribe una explicación para que el trabajador conozca el resultado.')
    if d.status=='ACEPTADA' and (r.type not in FORMAL_DECISION_TYPES or not can_authorize(user)):
        raise HTTPException(403,'La aceptación requiere la facultad institucional de autorización.')
    if d.status=='RECHAZADA' and r.type in FORMAL_DECISION_TYPES and not can_authorize(user):
        # Rechazo formal de vacaciones/permisos equivale a una denegación.
        raise HTTPException(403,'La denegación requiere la facultad institucional de autorización.')
    if d.status in ('ATENDIDA','ACEPTADA'):
        expected=('AUTORIZADA' if d.status=='ACEPTADA' else None)
        if expected:
            if d.result_kind not in (None,'AUTORIZADA'):
                raise HTTPException(422,'Para una solicitud aceptada el resultado debe ser Autorizada.')
        elif not d.result_kind or d.result_kind not in RESULTS.get(r.type,('RESPUESTA_REGISTRADA',)):
            raise HTTPException(422,'Selecciona un resultado válido para este trámite.')
        # El documento médico es del trabajador; nunca se obliga a RR. HH.
        # a subir el sustento. Si falta, debe marcar Observada.
        if r.type=='DESCANSO_MEDICO' and not db.scalar(select(Attachment.id).where(
            Attachment.request_id==rid,Attachment.author_id==r.requester_id)):
            raise HTTPException(422,'Falta el sustento médico del trabajador. Marca Observada y solicita el archivo.')
    if d.status=='CERRADA' and r.status not in ('ATENDIDA','ACEPTADA'):
        raise HTTPException(409,'Primero registra el resultado antes de cerrar.')
    # Fecha y hora determinadas exclusivamente por el servidor al confirmar el cambio.
    moment=utcnow()
    old=r.status;r.status=d.status;r.updated_at=moment
    if d.status in ('CERRADA','RECHAZADA'):r.closed_at=moment
    result_kind='AUTORIZADA' if d.status=='ACEPTADA' else d.result_kind
    detail=d.detail.strip()+((' | Resultado: '+result_kind) if result_kind else '')
    db.add(Event(request_id=r.id,actor_id=user['id'],actor_name=user['name'],kind='CAMBIO_ESTADO',from_status=old,to_status=d.status,detail=detail,effective_at=moment,recorded_at=moment))
    add_notice(db,r.requester_id,r.id,f'Estado actualizado: solicitud {r.code} · {STATUS.get(d.status,d.status)}')
    db.commit();return {'ok':True,'status':d.status,'recorded_at':moment.isoformat()}

@app.patch('/requests/{rid}')
def correct_request(rid:int,d:Correccion,user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    # Conserva el mismo expediente, código y auditoría: no crea otra solicitud.
    r=ensure_access(db,rid,user)
    if user['role']!='TRABAJADOR' or r.requester_id!=user['id']:
        raise HTTPException(403,'Solo el trabajador titular puede corregir sus datos.')
    if r.status not in ('REGISTRADA','OBSERVADA'):
        raise HTTPException(409,'Puedes editar los datos antes de revisión o cuando RR. HH. observe la solicitud.')
    t=db.get(Tramite,r.type)
    if not t:raise HTTPException(400,'No existe la configuración del trámite.')
    values=validate_fields(json.loads(t.fields_json),d.details)
    new_subject=d.subject.strip()
    new_description=d.description.strip()
    old_values=json.loads(r.details_json or '{}')
    changed=[]
    if r.subject!=new_subject:changed.append('asunto')
    if r.description!=new_description:changed.append('detalle')
    if old_values!=values:changed.append('datos del trámite')
    if not changed:
        # Sin cambios en los datos no se genera un evento de corrección.
        # Si solo adjuntó un documento, debe pulsar «Enviar subsanación».
        return {'ok':True,'unchanged':True,'code':r.code,'status':r.status}
    old=r.status
    r.subject=new_subject
    r.description=new_description
    r.details_json=json.dumps(values,ensure_ascii=False)
    if old=='OBSERVADA':r.status='EN_REVISION'
    moment=utcnow()
    r.updated_at=moment
    description=('Subsanó la observación' if old=='OBSERVADA' else 'Corrigió: '+', '.join(changed))
    if old=='OBSERVADA' and changed:
        description+='; actualizó '+', '.join(changed)
    db.add(Event(request_id=rid,actor_id=user['id'],actor_name=user['name'],
                 kind='SUBSANACION' if old=='OBSERVADA' else 'CORRECCION',
                 from_status=old,to_status=r.status,detail=description,
                 effective_at=moment,recorded_at=moment))
    add_notice(db,r.assignee_id,r.id,f'Solicitud corregida: {r.code} · {", ".join(changed) or "observación subsanada"}')
    db.commit()
    return {'ok':True,'code':r.code,'status':r.status,'unchanged':False}

@app.post('/requests/{rid}/subsanar')
def subsanar(rid:int,d:Subsanacion,user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    r=ensure_access(db,rid,user)
    if user['role']!='TRABAJADOR' or r.status!='OBSERVADA':
        raise HTTPException(403,'Solo el titular puede subsanar una solicitud observada.')
    # Los IDs del historial permiten ordenar eventos aunque MySQL guarde
    # varias acciones en el mismo segundo (DATETIME sin microsegundos).
    last_observation=db.scalar(select(Event.id).where(
        Event.request_id==rid,Event.kind=='CAMBIO_ESTADO',Event.to_status=='OBSERVADA')
        .order_by(Event.id.desc()).limit(1))
    newly_attached=last_observation and db.scalar(select(Event.id).where(
        Event.request_id==rid,Event.actor_id==user['id'],Event.kind=='ADJUNTO',
        Event.id>last_observation).limit(1))
    if not newly_attached:
        raise HTTPException(409,'Adjunta el documento solicitado antes de enviar la subsanación.')
    moment=utcnow()
    r.status='EN_REVISION';r.updated_at=moment
    db.add(Event(request_id=rid,actor_id=user['id'],actor_name=user['name'],kind='SUBSANACION',
        from_status='OBSERVADA',to_status='EN_REVISION',detail='Se adjuntó el documento solicitado para revisión.',effective_at=moment,recorded_at=moment))
    add_notice(db,r.assignee_id,r.id,f'Solicitud corregida: {r.code} · observación subsanada')
    db.commit();return {'ok':True,'status':r.status}
@app.post('/requests/{rid}/attachments',status_code=201)
async def upload(rid:int,file:UploadFile=File(...),user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    r=ensure_access(db,rid,user)
    if r.status in ('ATENDIDA','CERRADA','RECHAZADA'):raise HTTPException(400,'Expediente cerrado.')
    name=Path(file.filename or 'documento.pdf').name[:200]
    if not name.lower().endswith('.pdf'):raise HTTPException(400,'Solo se permiten documentos PDF.')
    max_bytes = CLOUD_PDF_MAX_BYTES if DB_PDF_STORAGE else 5*1024*1024
    content=await file.read(max_bytes+1)
    if not content.startswith(b'%PDF-') or len(content)>max_bytes:
        raise HTTPException(400,'PDF inválido o superior al límite permitido (' + ('4 MB' if DB_PDF_STORAGE else '5 MB') + ').')
    stored=uuid4().hex+'.pdf'
    target=UPLOAD_DIR/stored
    if not DB_PDF_STORAGE:
        target.write_bytes(content)
    try:
        moment=utcnow()
        r.updated_at=moment
        db.add(Attachment(request_id=rid,original_name=name,stored_name=stored,sha256=hashlib.sha256(content).hexdigest(),size=len(content),author_id=user['id']))
        if DB_PDF_STORAGE:
            db.add(AttachmentContent(stored_name=stored,content=content))
        db.add(Event(request_id=rid,actor_id=user['id'],actor_name=user['name'],kind='ADJUNTO',from_status=r.status,to_status=r.status,detail=f'Archivo adjuntado: {name}',effective_at=utcnow()))
        db.commit()
    except Exception:
        db.rollback()
        if not DB_PDF_STORAGE:
            target.unlink(missing_ok=True)
        raise
    return {'ok':True,'name':name}
@app.get('/attachments/{aid}')
def download(aid:int,user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    a=db.get(Attachment,aid)
    if not a:raise HTTPException(404,'Archivo no encontrado.')
    ensure_access(db,a.request_id,user)
    if DB_PDF_STORAGE:
        pdf=db.get(AttachmentContent,a.stored_name)
        if not pdf:
            raise HTTPException(404,'Documento no encontrado en almacenamiento.')
        # Tras autenticar la sesión y los permisos del expediente, devolver bytes.
        # Los nombres se codifican para evitar inyección de cabeceras.
        safe=quote(a.original_name, safe='')
        return Response(content=pdf.content,media_type='application/pdf',headers={
            'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff',
            'Content-Disposition':"attachment; filename*=UTF-8''"+safe,
        })
    target=UPLOAD_DIR/a.stored_name
    if not target.is_file():raise HTTPException(404,'Archivo no encontrado en almacenamiento.')
    return FileResponse(target,media_type='application/pdf',filename=a.original_name,headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'})
@app.get('/measurements/active')
def active_measurement(user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    require_staff(user)
    m=db.scalar(select(Measurement).where(Measurement.observer_id==user['id'],
                Measurement.ended_at.is_(None)).order_by(Measurement.id.desc()).limit(1))
    if not m:return {'active':False}
    req=db.get(Request,m.request_id)
    return {'active':True,'id':m.id,'request_id':m.request_id,
            'code':req.code if req else '', 'started_at':m.started_at.isoformat()}

@app.post('/measurements/start',status_code=201)
def start_measurement(d:StartConsultationMeasurement,user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    """Tiempo de búsqueda observado; no se infiere de clics en la pantalla."""
    require_staff(user)
    r=db.get(Request,d.request_id)
    if not r or r.is_demo:raise HTTPException(404,'Expediente real no encontrado.')
    pending=db.scalar(select(Measurement.id).where(
        Measurement.observer_id==user['id'],Measurement.ended_at.is_(None)))
    if pending:raise HTTPException(409,'Finaliza primero la medición que está en curso.')
    m=Measurement(request_id=r.id,observer_id=user['id'],started_at=utcnow())
    db.add(m);db.commit();db.refresh(m)
    return {'id':m.id,'request_id':r.id,'code':r.code,'started_at':m.started_at.isoformat()}

@app.post('/measurements/{mid}/finish')
def finish_measurement(mid:int,d:FinishConsultationMeasurement,user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    require_staff(user)
    m=db.get(Measurement,mid)
    if not m:raise HTTPException(404,'Medición inexistente.')
    if m.observer_id!=user['id']:raise HTTPException(403,'No puedes finalizar mediciones ajenas.')
    if m.ended_at is not None:raise HTTPException(409,'Esta medición ya terminó.')
    moment=utcnow()
    elapsed=(tz(moment)-tz(m.started_at)).total_seconds()
    if elapsed<1:raise HTTPException(422,'La medición requiere al menos un segundo.')
    if elapsed>7200:raise HTTPException(422,'El ensayo superó dos horas; inicia otra medición.')
    m.ended_at=moment;m.seconds=round(elapsed,2);m.correct=d.correct
    db.commit()
    return {'id':m.id,'seconds':m.seconds,'correct':m.correct,'request_id':m.request_id}

@app.get('/internal/export')
def internal_export(x_internal_key:str|None=Header(default=None),db:Session=Depends(db_dep)):
    check_internal(x_internal_key)
    # selectinload retrieves all histories in batches; without it a report
    # executed an additional SQL query for every expediente (N+1 queries).
    # Los expedientes demostrativos nunca forman parte de los indicadores de investigación.
    rows=db.scalars(select(Request).where(Request.is_demo.is_(False)).options(
        load_only(Request.id,Request.code,Request.type,Request.status,Request.created_at),
        selectinload(Request.events)).order_by(Request.id)).all()
    demo_count=db.scalar(select(func.count()).select_from(Request).where(Request.is_demo.is_(True))) or 0
    consultation_reads=db.scalar(select(func.count()).select_from(ConsultationAccess)
        .join(Request,ConsultationAccess.request_id==Request.id)
        .where(Request.is_demo.is_(False))) or 0
    state_updates=db.scalar(select(func.count()).select_from(Event)
        .join(Request,Event.request_id==Request.id)
        .where(Event.kind=='CAMBIO_ESTADO',Request.is_demo.is_(False))) or 0
    measurements=db.scalars(select(Measurement).join(Request,Measurement.request_id==Request.id).where(
        Measurement.ended_at.is_not(None),Request.is_demo.is_(False))).all()
    # Keep the internal reports payload small: subjects, personal details and
    # attachments are not needed for aggregated metrics or the CSV matrix.
    return {'demo_count':demo_count,'consultation_reads':consultation_reads,'state_updates':state_updates,'requests':[{'id':r.id,'code':r.code,'type':r.type,'status':r.status,
             'created_at':r.created_at.isoformat(),
             'history':[event_to_dict(e) for e in r.events]} for r in rows],
            'measurements':[{'measurement_id':m.id,'request_id':m.request_id,'observer_id':m.observer_id,
             'started_at':m.started_at.isoformat(),'ended_at':m.ended_at.isoformat() if m.ended_at else None,
             'seconds':m.seconds,'correct':m.correct} for m in measurements]}

def public_notification(n:Notification, role:str):
    """Presentaciones claras conservando el texto original de la bitácora."""
    detail=n.detail.strip()
    lower=detail.lower()
    match=re.match(r'^(\d{5}):\s*(.*)$',detail)
    code=match.group(1) if match else ''
    if role=='RRHH':
        if lower.startswith('nueva solicitud:'):
            title=detail
            kind='nueva'
        elif lower.startswith('solicitud corregida:'):
            title=detail
            kind='corregida'
        elif match and any(v in lower for v in ('corregid','corrección','subsanó','subsanaci')):
            title=f'Solicitud corregida: {code}'
            kind='corregida'
        else:return None
    else:
        if lower.startswith('estado actualizado:'):
            title=detail;kind='estado'
        elif match:
            title=f'Estado actualizado: solicitud {code} · {match.group(2)}';kind='estado'
        else:return None
    return {'id':n.id,'request_id':n.request_id,'detail':title,'type':kind,
            'created_at':n.created_at.isoformat(),'read':n.read_at is not None}

@app.get('/notifications')
def notifications(user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    notes=db.scalars(select(Notification).where(Notification.user_id==user['id'])
        .order_by(Notification.id.desc()).limit(150)).all()
    response=[]
    seen={}
    for n in notes:
        item=public_notification(n,user['role'])
        if not item:continue
        # Solo entradas antiguas materialmente idénticas, próximas en el tiempo.
        # Nunca se borra una fila de notificaciones ni del historial.
        legacy=n.detail.startswith(tuple('0123456789')) and item['type']=='corregida'
        key=(n.request_id,n.detail.strip().lower(),item['type'])
        previous=seen.get(key)
        at=tz(n.created_at)
        if legacy and previous and abs((previous-at).total_seconds())<=120:
            continue
        if not legacy and previous and abs((previous-at).total_seconds())<=2:
            continue
        seen[key]=at
        response.append(item)
        if len(response)>=30:break
    return response
@app.post('/notifications/{nid}/read')
def notice_read(nid:int,user:dict=Depends(verified_user),db:Session=Depends(db_dep)):
    n=db.get(Notification,nid)
    if not n or n.user_id!=user['id']:raise HTTPException(404,'Aviso no encontrado.')
    n.read_at=utcnow();db.commit();return {'ok':True}
