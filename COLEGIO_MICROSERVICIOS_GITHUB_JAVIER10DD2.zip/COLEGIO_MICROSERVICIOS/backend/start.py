"""Inicia FastAPI en 8080 y mantiene los microservicios fuera de la red pública.

Apache (XAMPP) puede continuar escuchando en 80/443; MySQL, en 3306.
"""
from __future__ import annotations

import os
import secrets
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from backend.config import load_config

WEB_PORT = 8080
SERVICES = [
    ("services.identity.main:app", 8001),
    ("services.requests.main:app", 8002),
    ("services.reports.main:app", 8003),
    ("gateway.main:app", WEB_PORT),
]


def port_used(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.35)
        return sock.connect_ex(("127.0.0.1", port)) == 0


def port_owner(port: int) -> str:
    """Diagnóstico para Windows sin detener ni modificar otros servicios."""
    if os.name != "nt":
        return ""
    try:
        output = subprocess.check_output(
            ["netstat", "-ano", "-p", "TCP"],
            text=True, errors="replace", timeout=3,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        pids = set()
        for line in output.splitlines():
            cols = line.split()
            if len(cols) >= 5 and cols[0].upper() == "TCP" and cols[3].upper() == "LISTENING":
                address = cols[1].rsplit(":", 1)
                if len(address) == 2 and address[-1] == str(port):
                    pids.add(cols[4])
        return ", ".join(sorted(pids))
    except (OSError, subprocess.TimeoutExpired):
        return ""


def check_mysql(env: dict[str, str]) -> None:
    try:
        import pymysql
    except ImportError:
        raise SystemExit("Falta PyMySQL. Ejecuta primero '02 - Instalar dependencias'.") from None
    try:
        conn = pymysql.connect(
            host=env.get("DB_HOST", "127.0.0.1"),
            port=int(env.get("DB_PORT", "3306")),
            user=env.get("DB_USER", "root"),
            password=env.get("MYSQL_PASSWORD", ""),
            connect_timeout=3,
            read_timeout=3,
            write_timeout=3,
        )
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME IN (%s, %s)",
                            (env.get('IDENTITY_DB_NAME', 'colegio_identidad'), env.get('REQUESTS_DB_NAME', 'colegio_solicitudes')))
                found = {row[0] for row in cur.fetchall()}
            missing = {env.get('IDENTITY_DB_NAME', 'colegio_identidad'), env.get('REQUESTS_DB_NAME', 'colegio_solicitudes')} - found
            if missing:
                raise SystemExit("Falta la base MySQL: " + ", ".join(sorted(missing)) +
                                 ". Ejecuta '03 - Configurar MySQL' y '04 - Comprobar tablas'.")
        finally:
            conn.close()
    except (SystemExit, KeyboardInterrupt):
        raise
    except Exception as exc:
        raise SystemExit("No se puede conectar con MySQL de XAMPP: " + str(exc).splitlines()[0] +
                         "\nVerifica MySQL encendido y configura las credenciales con la tarea 03.") from None


def main() -> None:
    load_config()
    env = os.environ.copy()
    env.setdefault("DB_MODE", "mysql")
    if env["DB_MODE"] != "mysql":
        raise SystemExit("El arranque normal utiliza MySQL. Revisa DB_MODE en backend/.env.")

    # Puerto fijo: la configuración antigua podía guardar 80 y causar conflictos con Apache.
    env["GATEWAY_PORT"] = str(WEB_PORT)
    env["GATEWAY_HOST"] = "127.0.0.1"
    env["IDENTITY_URL"] = "http://127.0.0.1:8001"
    env["REQUESTS_URL"] = "http://127.0.0.1:8002"
    env["REPORTS_URL"] = "http://127.0.0.1:8003"
    env.setdefault("JWT_SECRET", secrets.token_urlsafe(48))
    env.setdefault("INTERNAL_SERVICE_KEY", secrets.token_urlsafe(48))
    env["PYTHONPATH"] = str(ROOT / "backend") + os.pathsep + env.get("PYTHONPATH", "")

    data_dir = Path(env.get("DATA_DIR", str(ROOT / "backend" / "data"))).resolve()
    data_dir.mkdir(parents=True, exist_ok=True)
    (data_dir / "adjuntos").mkdir(exist_ok=True)
    env.setdefault("DATA_DIR", str(data_dir))
    env.setdefault("UPLOAD_DIR", str(data_dir / "adjuntos"))

    print("Iniciando el colegio en http://127.0.0.1:8080 (Apache y MySQL pueden seguir encendidos).", flush=True)

    for _, port in SERVICES:
        if port_used(port):
            pid = port_owner(port)
            extra = f" (PID: {pid})" if pid else ""
            if port == WEB_PORT:
                raise SystemExit(
                    f"El puerto 8080 ya está ocupado{extra}. No se modificará XAMPP.\n"
                    "Cierra la ejecución anterior del colegio si quedó abierta. Si Apache de XAMPP usa 8080, "
                    "debes liberar ese puerto antes de usarlo para FastAPI.\n"
                    "Para identificarlo en Windows: netstat -ano | findstr :8080"
                )
            raise SystemExit(f"El servicio interno necesita el puerto {port}, pero ya está ocupado{extra}.\n"
                             "Cierra primero la ejecución anterior del colegio; no detengas MySQL ni Apache.")

    check_mysql(env)
    # Los expedientes existentes permanecen intactos. La carga de ejemplos
    # es voluntaria desde la tarea 07; no se realiza al arrancar el servidor.
    processes = []

    def exit_signal(signum, frame):
        raise KeyboardInterrupt

    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, exit_signal)
    try:
        for target, port in SERVICES:
            proc = subprocess.Popen(
                [sys.executable, "-m", "uvicorn", target, "--host", "127.0.0.1",
                 "--port", str(port), "--log-level", "warning"],
                cwd=ROOT, env=env,
            )
            processes.append(proc)
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            failed = [(SERVICES[i][0], proc.returncode) for i, proc in enumerate(processes)
                      if proc.poll() is not None]
            if failed:
                raise SystemExit("Un microservicio no pudo iniciarse: " + repr(failed) +
                                 "\nRevisa el error inmediatamente anterior en esta terminal y verifica las tablas (tarea 04).")
            try:
                with urlopen(f"http://127.0.0.1:{WEB_PORT}/health/ready", timeout=1.3) as response:
                    if response.status == 200:
                        break
            except (HTTPError, URLError, OSError):
                pass
            time.sleep(0.35)
        else:
            raise SystemExit("Los servicios no respondieron en 30 segundos. Comprueba las tablas MySQL (tarea 04) "
                             "y los mensajes de error de esta terminal.")

        print("\nSISTEMA LISTO: http://127.0.0.1:8080", flush=True)
        print("XAMPP: Apache sin cambios; MySQL conectado en " +
              env.get("DB_HOST", "127.0.0.1") + ":" + env.get("DB_PORT", "3306"), flush=True)
        print("Visual Studio Code > Ports > Forward a Port > 8080", flush=True)
        print("Mantén esta terminal abierta. Detener: Ctrl + C.\n", flush=True)
        while True:
            failed = [(SERVICES[i][0], proc.returncode) for i, proc in enumerate(processes)
                      if proc.poll() is not None]
            if failed:
                raise SystemExit("Se detuvo un servicio: " + repr(failed) + ". Revisa la terminal.")
            time.sleep(0.35)
    except KeyboardInterrupt:
        print("Deteniendo solo los procesos de esta aplicación...", flush=True)
    finally:
        for proc in processes:
            if proc.poll() is None:
                proc.terminate()
        for proc in processes:
            try:
                proc.wait(timeout=4)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=2)


if __name__ == "__main__":
    main()
