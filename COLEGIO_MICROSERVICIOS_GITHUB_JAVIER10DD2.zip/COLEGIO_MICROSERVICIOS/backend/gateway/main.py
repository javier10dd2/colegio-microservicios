"""Puerta de entrada y frontend: una sola dirección pública, APIs internas privadas."""
import os
import time
import asyncio
from collections import defaultdict,deque
from contextlib import asynccontextmanager
import httpx
from fastapi import FastAPI,Request,HTTPException
from fastapi.responses import FileResponse,Response,JSONResponse,RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.gzip import GZipMiddleware
from pathlib import Path
from starlette.middleware.sessions import SessionMiddleware
try:
    from authlib.integrations.starlette_client import OAuth, OAuthError
except ImportError:
    OAuth = None
    class OAuthError(Exception):
        pass
from common.security import INTERNAL_KEY
# Un túnel de VS Code no convierte el equipo local en un servidor productivo.
if os.getenv('ENVIRONMENT') == 'production':
    if os.getenv('COOKIE_SECURE') != '1':
        raise RuntimeError('Producción requiere cookies seguras; configura COOKIE_SECURE=1 y HTTPS.')
    if len(os.getenv('SSO_SESSION_SECRET', '')) < 32:
        raise RuntimeError('Producción requiere SSO_SESSION_SECRET privada de 32+ caracteres.')
@asynccontextmanager
async def lifespan(app):
    yield
    await shared_client.aclose()

app=FastAPI(title='Colegio · Plataforma de gestión',docs_url=None,redoc_url=None,openapi_url=None,lifespan=lifespan)
app.add_middleware(SessionMiddleware,secret_key=os.getenv('SSO_SESSION_SECRET',INTERNAL_KEY),same_site='lax',https_only=os.getenv('COOKIE_SECURE')=='1',session_cookie='colegio_oauth_state')
# Comprime JS, CSS y respuestas grandes, especialmente útil al compartir por VS Code Ports.
app.add_middleware(GZipMiddleware, minimum_size=1200)
oauth=OAuth() if OAuth else None
if os.getenv('GOOGLE_CLIENT_ID') and os.getenv('GOOGLE_CLIENT_SECRET'):
    if oauth is None:raise RuntimeError('Instala las dependencias de backend/requirements.txt para habilitar Google.')
    oauth.register(name='google',client_id=os.getenv('GOOGLE_CLIENT_ID'),client_secret=os.getenv('GOOGLE_CLIENT_SECRET'),
                   server_metadata_url='https://accounts.google.com/.well-known/openid-configuration',
                   client_kwargs={'scope':'openid email profile'})
# Microsoft OAuth requires the institution's specific tenant, not a generic account issuer.
if os.getenv('MICROSOFT_CLIENT_ID') and os.getenv('MICROSOFT_CLIENT_SECRET') and os.getenv('MICROSOFT_TENANT_ID'):
    if oauth is None:raise RuntimeError('Instala las dependencias de backend/requirements.txt para habilitar Microsoft.')
    tenant=os.getenv('MICROSOFT_TENANT_ID')
    if tenant in ('common','organizations','consumers') or not all(c in '0123456789abcdefABCDEF-' for c in tenant):
        raise RuntimeError('MICROSOFT_TENANT_ID debe ser el ID del tenant institucional.')
    oauth.register(name='microsoft',client_id=os.getenv('MICROSOFT_CLIENT_ID'),client_secret=os.getenv('MICROSOFT_CLIENT_SECRET'),
                   server_metadata_url=f'https://login.microsoftonline.com/{tenant}/v2.0/.well-known/openid-configuration',
                   client_kwargs={'scope':'openid email profile'})
BASE=Path(__file__).resolve().parents[2]/'frontend'
SERVICES={'identity':os.getenv('IDENTITY_URL','http://127.0.0.1:8001'),
          'requests':os.getenv('REQUESTS_URL','http://127.0.0.1:8002'),
          'reports':os.getenv('REPORTS_URL','http://127.0.0.1:8003')}
app.mount('/static',StaticFiles(directory=BASE/'static'),name='static')
shared_client=httpx.AsyncClient(timeout=httpx.Timeout(12,connect=3),limits=httpx.Limits(max_keepalive_connections=20,max_connections=40))
_register_hits=defaultdict(deque)
_login_hits=defaultdict(deque)

def _limited(hits_by_ip, ip, limit, seconds):
    now=time.monotonic()
    hits=hits_by_ip[ip]
    while hits and hits[0]<now-seconds:hits.popleft()
    if len(hits)>=limit:return True
    hits.append(now)
    if len(hits_by_ip)>2000:
        for key in list(hits_by_ip)[:1000]:
            if not hits_by_ip[key] or hits_by_ip[key][-1]<now-seconds:hits_by_ip.pop(key,None)
    return False

def registration_rate_limited(ip:str)->bool:
    return _limited(_register_hits,ip,limit=5,seconds=900)

def login_rate_limited(ip:str)->bool:
    # Protección adicional para demostraciones; en producción preferir Redis distribuido.
    return _limited(_login_hits,ip,limit=25,seconds=300)
@app.get('/')
async def index():return FileResponse(BASE/'index.html')
@app.get('/health')
async def health():return {'service':'gateway','ok':True}
@app.get('/health/ready')
async def ready():
    """Check that all three internal services are responding."""
    try:
        results=await asyncio.gather(*[shared_client.get(url+'/health',timeout=2) for url in SERVICES.values()])
    except httpx.RequestError:
        return JSONResponse({'ok':False,'detail':'Un servicio no responde.'},status_code=503)
    ok=all(r.status_code==200 for r in results)
    return JSONResponse({'ok':ok,'services':list(SERVICES)},status_code=200 if ok else 503)
@app.get('/auth/providers')
async def enabled_providers():
    return {'google':oauth is not None and oauth.create_client('google') is not None,'microsoft':oauth is not None and oauth.create_client('microsoft') is not None}

@app.get('/auth/sso/{provider}')
async def begin_sso(provider:str,request:Request):
    client=oauth.create_client(provider) if oauth is not None and provider in ('google','microsoft') else None
    if not client:raise HTTPException(404,'Proveedor de acceso no configurado.')
    # OAUTH_BASE_URL must be the public HTTPS URL and registered redirect authority.
    base=os.getenv('OAUTH_BASE_URL','').rstrip('/')
    if not base.startswith('https://'):
        raise HTTPException(503,'Configura la URL HTTPS pública del sitio para este tipo de inicio de sesión.')
    return await client.authorize_redirect(request,base+'/auth/callback/'+provider)

@app.get('/auth/callback/{provider}')
async def finish_sso(provider:str,request:Request):
    client=oauth.create_client(provider) if oauth is not None and provider in ('google','microsoft') else None
    if not client:raise HTTPException(404,'Proveedor no disponible.')
    try:
        token=await client.authorize_access_token(request)
        claims=token.get('userinfo')
        if not claims:raise ValueError('No se recibió identidad verificada.')
        email=(claims.get('email') or (claims.get('preferred_username') if provider=='microsoft' else '') or '').strip().lower()
        if provider=='google' and claims.get('email_verified') is not True:
            raise ValueError('Cuenta Google sin correo verificado.')
        if not email:raise ValueError('El proveedor no proporcionó un correo institucional.')
        res=await shared_client.post(SERVICES['identity']+'/internal/sso',json={'email':email},headers={'X-Internal-Key':INTERNAL_KEY},timeout=5)
        if res.status_code!=200:raise ValueError('Este correo no tiene acceso autorizado al sistema.')
        resp=RedirectResponse(url='/',status_code=303)
        resp.set_cookie('colegio_session',res.json()['token'],httponly=True,samesite='lax',secure=os.getenv('COOKIE_SECURE')=='1',max_age=8*3600,path='/')
        return resp
    except (OAuthError,KeyError,ValueError,httpx.RequestError) as ex:
        return RedirectResponse(url='/?sso_error=1',status_code=303)

@app.post('/api/logout')
async def logout():
    r=JSONResponse({'ok':True});r.delete_cookie('colegio_session',path='/');return r
@app.api_route('/api/{service}/{path:path}',methods=['GET','POST','PATCH','DELETE'])
async def proxy(service:str,path:str,request:Request):
    if service not in SERVICES or '..' in path.split('/') or 'internal' in path.split('/'):
        raise HTTPException(404,'Ruta inexistente.')
    if service=='identity' and path in ('auth/login','auth/register') and request.method=='POST':
        if path=='auth/register' and registration_rate_limited(request.client.host if request.client else 'unknown'):
            return JSONResponse({'detail':'Demasiados intentos. Intenta registrar la cuenta más tarde.'},status_code=429)
        if path=='auth/login' and login_rate_limited(request.client.host if request.client else 'unknown'):
            return JSONResponse({'detail':'Demasiados intentos de acceso. Vuelve a intentar en unos minutos.'},status_code=429)
    else:
        token=request.cookies.get('colegio_session')
        if not token:return JSONResponse({'detail':'Inicia sesión.'},status_code=401)
    headers={'Accept':'application/json'}
    if not (service=='identity' and path in ('auth/login','auth/register')):
        headers['Authorization']='Bearer '+token
    if request.headers.get('content-type'):headers['Content-Type']=request.headers['content-type']
    body=await request.body()
    started=time.perf_counter()
    try:
        upstream=await shared_client.request(request.method,SERVICES[service]+'/'+path,
                     params=request.query_params,content=body,headers=headers)
    except httpx.RequestError:
        return JSONResponse({'detail':'Servicio temporalmente no disponible.'},status_code=503)
    if service=='identity' and path=='auth/login' and upstream.status_code==200:
        data=upstream.json();resp=JSONResponse({'user':data['user']});
        resp.set_cookie('colegio_session',data['token'],httponly=True,samesite='lax',secure=os.getenv('COOKIE_SECURE')=='1',max_age=8*3600,path='/')
        return resp
    output_headers={}
    if upstream.headers.get('content-disposition'):output_headers['Content-Disposition']=upstream.headers['content-disposition']
    if upstream.headers.get('cache-control'):output_headers['Cache-Control']=upstream.headers['cache-control']
    output_headers['Server-Timing']=f'upstream;dur={(time.perf_counter()-started)*1000:.1f}'
    return Response(content=upstream.content,status_code=upstream.status_code,
         media_type=upstream.headers.get('content-type','application/json'),headers=output_headers)

@app.middleware("http")
async def response_security_headers(request, call_next):
    # Rechazar modificaciones cross-site; soporta VS Code Ports porque la página y API
    # se consumen desde el mismo origen. Los clientes de consola sin Fetch Metadata
    # conservan acceso a sus endpoints normales.
    if request.method in ('POST','PUT','PATCH','DELETE') and request.headers.get('sec-fetch-site','').lower() == 'cross-site':
        return JSONResponse({'detail':'Solicitud desde otro origen no permitida.'},status_code=403)
    response = await call_next(request)
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
        "connect-src 'self'; form-action 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'none'")
    response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    if request.url.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store"
    elif request.url.path.startswith("/static/"):
        response.headers["Cache-Control"] = "public, max-age=3600, immutable"
    elif request.url.path == "/":
        response.headers["Cache-Control"] = "no-cache"
    return response
