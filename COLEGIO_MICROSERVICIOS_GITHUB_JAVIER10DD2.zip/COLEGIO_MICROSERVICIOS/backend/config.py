"""Read environment settings without external dependencies or secrets in source."""
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parents[1]

def load_config():
    env_path = ROOT / 'backend' / '.env'
    if not env_path.is_file():
        normalize_database_names()
        return
    for line in env_path.read_text(encoding='utf-8-sig').splitlines():
        line=line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        key, value = line.split('=',1)
        key=key.strip();value=value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value
    normalize_database_names()


def normalize_database_names():
    """Usar nombres institucionales estables, aunque se copie un .env anterior."""
    os.environ['IDENTITY_DB_NAME'] = 'colegio_identidad'
    os.environ['REQUESTS_DB_NAME'] = 'colegio_solicitudes'
