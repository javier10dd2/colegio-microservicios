"""Transporte HTTP privado en proceso para ejecutar los servicios ASGI en Vercel.

En Docker los servicios siguen separados mediante HTTP. En Vercel no podemos
abrir servidores persistentes en 8001-8003: reenviamos entre aplicaciones ASGI
sin publicar sus endpoints `internal` y sin peticiones de red externas.
"""
from __future__ import annotations

import asyncio
from functools import partial

import anyio
import httpx


class ServiceTransport(httpx.AsyncBaseTransport):
    def __init__(self, apps: dict[str, object]):
        self.apps = apps

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        host = request.url.host
        app = self.apps.get(host)
        if app is None:
            raise httpx.ConnectError('El servicio interno no existe.', request=request)
        return await httpx.ASGITransport(app=app).handle_async_request(request)


class InternalHTTPClient:
    """Adaptador para código de servicios con dependencias HTTP síncronas."""

    def __init__(self, apps: dict[str, object]):
        self.transport = ServiceTransport(apps)

    async def _request(self, method: str, url: str, **kwargs) -> httpx.Response:
        async with httpx.AsyncClient(transport=self.transport, timeout=12) as client:
            return await client.request(method, url, **kwargs)

    def get(self, url: str, **kwargs) -> httpx.Response:
        # Las rutas def de FastAPI se ejecutan en el threadpool de AnyIO.
        try:
            return anyio.from_thread.run(partial(self._request, 'GET', url, **kwargs))
        except RuntimeError as exc:
            if 'AnyIO worker thread' not in str(exc):
                raise
            return asyncio.run(self._request('GET', url, **kwargs))
