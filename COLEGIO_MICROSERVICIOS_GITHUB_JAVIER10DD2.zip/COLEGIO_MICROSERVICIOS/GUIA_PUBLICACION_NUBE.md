# Publicar COLEGIO_MICROSERVICIOS en la nube (VPS + Docker + HTTPS)

## Por qué esta opción

El sistema dispone de Gateway (incluye frontend HTML/CSS/JS), Identidad, Solicitudes,
Reportes, MySQL y adjuntos PDF persistentes. `compose.yaml` ya proporciona cinco
contenedores. `compose.cloud.yaml` agrega Caddy para HTTPS automático, sin cambiar la
arquitectura de tu proyecto. La ejecución en una VPS no ha sido comprobada aquí:
solo se verificaron pruebas unitarias y configuración de archivos.

## Requisitos

- Una **VPS Ubuntu 24.04** (por ejemplo con 2 GB de RAM como punto de partida, a comprobar según carga),
  acceso SSH y dirección IP pública. Normalmente tiene costo mensual.
- Docker Engine y **docker compose** instalados siguiendo la documentación oficial:
  https://docs.docker.com/engine/install/ubuntu/
- Un dominio o subdominio cuyo registro DNS **A** apunte a la IP de tu VPS.
- Puertos **80/TCP, 443/TCP, 443/UDP** abiertos en la VPS y firewall del proveedor,
  además de SSH limitado a tu equipo cuando sea posible.

## Paso 1. Subir el proyecto

En Windows, desde PowerShell, en la carpeta donde descomprimiste el ZIP (sustituye
usuario e IP de tu servidor):

```powershell
scp -r . usuario@IP_DE_TU_VPS:~/colegio-microservicios/
```

No incluyas archivos con datos reales en una prueba de acceso público. Nunca subas
credenciales ni `backend/.env` a un repositorio Git.

## Paso 2. Configurar las credenciales en el servidor

```bash
cd ~/colegio-microservicios
cp .env.example .env
nano .env
```

Sustituye **todos** los textos `CAMBIAR_...` por **cinco secretos diferentes**.
Para generar cada uno (ejecutar 5 veces):

```bash
python3 -c 'import secrets; print(secrets.token_urlsafe(48))'
```

Establece `SITE_DOMAIN=colegio.midominio.com`, con DNS apuntando al servidor.
`PRIMARY_RRHH_EMAIL` puede quedar vacío hasta identificar la primera cuenta RR. HH.
No edites la variable `UPDATE_EVIDENCE_VALIDATED` sin acreditación documental.

```bash
python3 deploy/preflight_nube.py
```

## Paso 3. Iniciar todos los contenedores

```bash
docker compose -f compose.yaml -f compose.cloud.yaml up -d --build
docker compose -f compose.yaml -f compose.cloud.yaml ps
```

Espera a que MySQL finalice su inicialización: la primera ejecución puede tardar más.
Asegúrate de que todos los servicios estén activos. **Caddy** solicitará y renovará
un certificado TLS cuando el DNS y los puertos estén correctos.

## Paso 4. Crear la primera cuenta autorizada de RR. HH.

Solo en una instalación nueva y únicamente con datos de una persona autorizada:

```bash
docker compose -f compose.yaml -f compose.cloud.yaml exec identity python -m tools.usuarios_iniciales
```

Introducirás nombre, correo institucional y contraseña fuerte. No compartas contraseñas.

## Paso 5. Probar desde otra computadora

- Abre `https://colegio.midominio.com` reemplazando por el subdominio real.
- Comprueba `https://colegio.midominio.com/health/ready` (debe mostrar `"ok":true`).
- Prueba el inicio de sesión, la creación de expedientes, carga/descarga de PDF y reportes.
- Revisa los registros si falla algo:

```bash
docker compose -f compose.yaml -f compose.cloud.yaml logs --tail=100 caddy gateway identity requests reports mysql
```

## Actualizaciones y respaldos

Para publicar una nueva versión luego de subir los cambios:

```bash
docker compose -f compose.yaml -f compose.cloud.yaml up -d --build
```

**No** ejecutes `docker compose down -v`: destruiría los volúmenes.
La base MySQL, los PDF y certificados se guardan en volúmenes Docker. Esto **no equivale
 a tener respaldos**. Configura copias cifradas externas, pruebas periódicas de restauración,
monitoreo y actualizaciones de seguridad. Antes de permitir datos personales reales,
verifica permisos, política institucional de protección de datos y auditoría.

## Si quieres Railway en vez de VPS

Railway también puede ejecutar los 4 microservicios + MySQL, pero cada uno debe
configurarse como servicio independiente y deben adaptarse las variables de red interna,
la conexión MySQL, y un volumen persistente para `requests` en `/app/var`.
El `Dockerfile` ejecuta como usuario `colegio` (no root): verifica los permisos del
volumen montado por Railway o usa una imagen/entrypoint adecuado. No uses el ZIP como si
fuera un proyecto estático de Netlify. La opción Railway no está automatizada aquí.

## Diferencia con Vercel y Netlify

- Vercel soporta backends y contenedores, pero **no despliega directamente Compose**;
  para este proyecto necesitarías reconfigurar sus componentes y trasladar MySQL y PDFs
  a servicios persistentes externos.
- Netlify no es un servidor MySQL ni un host directo para los cuatro microservicios
  persistentes; solo subir el `frontend/` no hace funcionar el sistema.

Fuentes de plataformas:
- https://vercel.com/i/can-you-run-docker-compose-on-vercel
- https://docs.railway.com/networking/private-networking
- https://docs.railway.com/volumes/reference
- https://caddyserver.com/docs/automatic-https
