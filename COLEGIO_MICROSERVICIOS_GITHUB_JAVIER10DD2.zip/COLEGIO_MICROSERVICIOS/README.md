# Colegio Microservicios

Sistema web de gestión de solicitudes y trámites administrativos institucionales.

**Sitio de producción:** https://colegio-microservicios.vercel.app/

## Arquitectura

- **Frontend:** HTML, CSS y JavaScript nativos (`frontend/`).
- **Gateway:** FastAPI (`backend/gateway/`).
- **Microservicios:** Identidad, Solicitudes y Reportes (`backend/services/`).
- **Base de datos:** MySQL 8 alojado externamente; dos bases lógicas, `colegio_identidad` y `colegio_solicitudes`.
- **Hospedaje:** Vercel para la aplicación; Railway para MySQL y almacenamiento persistente.
- **Desarrollo local:** Python 3.12+, MySQL, o Docker Compose.

## Funcionalidades

Acceso de Recursos Humanos y trabajadores mediante cuentas independientes, gestión de usuarios y roles, solicitudes con estados e historial, adjuntos privados PDF, notificaciones, reportes e indicadores. Este repositorio contiene **solo código fuente y estructura de base de datos**, nunca información real de usuarios ni copias de producción.

## Ejecutar localmente

1. Crea `backend/.env` copiando `backend/.env.example`; configura un MySQL propio y claves aleatorias únicas.
2. Instala Python 3.12 o superior y las dependencias: `python -m pip install -r backend/requirements.txt`.
3. Inicializa las bases locales siguiendo `GUIA_MYSQL_RAILWAY.md` o `database/esquema_colegio.sql` (en una instalación limpia).
4. Ejecuta con `backend/start.py` o usa `docker compose up -d --build` configurando previamente `.env`.
5. Comprueba `/health` y `/health/ready` antes de cargar información.

Para producción consulta `GUIA_VERCEL.md` y `GUIA_MYSQL_RAILWAY.md`.

## Pruebas

```bash
python -m pip install -r backend/requirements.txt pytest
PYTHONPATH=backend python -m pytest -q tests
python -m compileall -q app.py backend
node --check frontend/static/app.js
```

## Seguridad y publicación

- El repositorio es **público**, pero la aplicación debe conservar autenticación y control de acceso.
- No incluye ni debe recibir `.env`, contraseñas iniciales, tokens, certificados, documentos reales, tablas exportadas con usuarios ni respaldos de MySQL.
- Los datos viven en MySQL de Railway, no en GitHub ni en el sistema de archivos efímero de Vercel.
- Publicar código no hace públicos los datos de la base de datos.
- Para documentos institucionales reales, verifica TLS de MySQL, copias de seguridad y permisos.

**Historial de despliegue:** la URL de producción se probó previamente con sus microservicios conectados. Los usuarios deben validar el funcionamiento después de cada actualización. El código público no instala automáticamente las credenciales de producción.

El proyecto es de uso académico/institucional. El hecho de publicar el código no concede por sí solo una licencia de redistribución; añade una licencia si deseas habilitar expresamente usos y modificaciones de terceros.
