// Interfaz de gestión administrativa.
const state={user:null,tab:'requests',requests:[],types:[],statuses:{},active:null,notifications:[]};
const $=id=>document.getElementById(id);
let visibleRows=50;
let filterTimeout=null;
let navSequence=0;
let requestsFetchedAt=0;
let reportsCache=null;
let reportsFetchedAt=0;
let lastInboxSignature='';
let notificationsInitialized=false;
let latestNotificationId=0;
let unreadNotifications=0;
let syncing=false;
const inboxSignature=rows=>rows.map(x=>`${x.id}:${x.status}:${x.updated_at}`).sort().join('|');
const readCache=new Map();
const readPending=new Map();
let loadingTimer=null;
function cacheLifetime(path){
  if(path==='requests/types'||path==='requests/statuses')return 30000;
  if(path==='identity/users')return 5000;
  if(path==='requests/notifications')return 4000;
  return 0;
}
const invalidateData=()=>{requestsFetchedAt=0;reportsFetchedAt=0;reportsCache=null;readCache.clear()};
function updateNotificationBadge(){
 const count=$('alert-count');if(count){count.textContent=unreadNotifications>99?'99+':String(unreadNotifications);count.classList.toggle('hidden',unreadNotifications===0)}
 const bell=$('topbar-notifications');if(bell)bell.setAttribute('aria-label',unreadNotifications?`${unreadNotifications} avisos pendientes. Abrir notificaciones`:'Abrir notificaciones');
 if($('navigation')&&state.user){const nav=$('navigation').querySelector('[data-tab=alerts]');if(nav){let counter=nav.querySelector('.nav-count');if(unreadNotifications&&!counter){counter=document.createElement('span');counter.className='nav-count';nav.append(counter)}if(counter){counter.textContent=String(unreadNotifications);counter.hidden=!unreadNotifications;}}}
}
function applyNotifications(items,{announce=true}={}){
 if(!state.user)return;const rows=(items||[]).filter(x=>x&&Number.isInteger(Number(x.id))).filter(n=>!staff()||(!n.read&&state.requests.some(r=>String(r.id)===String(n.request_id)&&!finished(r))));const unread=rows.filter(x=>!x.read);const high=rows.reduce((v,x)=>Math.max(v,Number(x.id)),latestNotificationId);const isInitial=!notificationsInitialized;
 const fresh=isInitial?[]:unread.filter(x=>Number(x.id)>latestNotificationId);
 notificationsInitialized=true;latestNotificationId=high;state.notifications=rows;unreadNotifications=unread.length;updateNotificationBadge();
 if(isInitial&&unread.length&&announce)notice(unread.length===1?'Nuevo aviso':'Nuevos avisos');
 else if(announce&&fresh.length){notice(staff()?'Nueva solicitud recibida':'Nueva respuesta recibida');}
}
function loadingAfterDelay(seq){
  clearTimeout(loadingTimer);
  loadingTimer=setTimeout(()=>{if(navSequence===seq)showLoading()},240);
}

const showLoading=()=>{$('main-content').innerHTML='<div class="panel" role="status">Cargando información...</div>'};

const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const date=v=>v?new Date(v.endsWith('Z')||v.includes('+')?v:v+'Z').toLocaleString('es-PE',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',hour12:true,timeZone:'America/Lima'}):'—';
const badge=v=>`<span class="chip ${esc(v)}">${esc(state.statuses[v]||v)}</span>`;
const staff=()=>state.user?.role==='RRHH';
const finished=r=>['ATENDIDA','ACEPTADA','CERRADA','RECHAZADA'].includes(r.status);
const canFinish=r=>!finished(r)&&staff();
let lastToast={message:'',at:0};
function notice(message,error=false){
 const now=Date.now();if(lastToast.message===message&&now-lastToast.at<2500)return;
 lastToast={message,at:now};
 const box=$('notice');box.replaceChildren();
 const x=document.createElement('div');x.className='toast'+(error?' error':'');
 x.textContent=message;box.append(x);setTimeout(()=>{if(x.isConnected)x.remove()},4600);
}
async function api(path,opts={}){
 const method=(opts.method||'GET').toUpperCase();
 const ttl=method==='GET'?cacheLifetime(path):0;
 const now=Date.now();const cached=readCache.get(path);
 if(ttl&&cached&&now<cached.until)return cached.value;
 if(method==='GET'&&readPending.has(path))return readPending.get(path);
 const task=(async()=>{
   const started=performance.now();
   const controller=new AbortController();
   const maxWait=method==='GET'?10000:30000;
   const timeoutId=setTimeout(()=>controller.abort(),maxWait);
   let res;
   try{res=await fetch('/api/'+path,{credentials:'same-origin',...opts,signal:controller.signal});}
   catch(err){if(err.name==='AbortError')throw Error('El servidor no respondió en '+(maxWait/1000)+' segundos. Comprueba la conexión de Vercel y la base de datos en Railway.');throw Error('No se pudo conectar con el servicio: '+path)}
   finally{clearTimeout(timeoutId)}
   const typ=res.headers.get('content-type')||'';
   const data=typ.includes('json')?await res.json():await res.blob();
   if(!res.ok)throw Error(data?.detail||'Operación no realizada.');
   if(ttl)readCache.set(path,{value:data,until:Date.now()+ttl});
   if(method!=='GET')invalidateData();
   if(performance.now()-started>800)console.info('Respuesta lenta:',path,Math.round(performance.now()-started)+' ms');
   return data;
 })();
 if(method==='GET')readPending.set(path,task);
 try{return await task}finally{if(method==='GET')readPending.delete(path)}
}
const json=d=>({method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});
const patch=d=>({method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});
function logged(yes){
  $('login-view').classList.toggle('hidden',yes);
  $('app-view').classList.toggle('hidden',!yes);
  if(!yes){$('login-form').classList.remove('hidden');$('register-form').classList.add('hidden')}
}
async function renderWorkspace(user,initialBootstrap=null){
  state.user=user;navSequence++;notificationsInitialized=false;latestNotificationId=0;unreadNotifications=0;
  readCache.clear();readPending.clear();invalidateData();
  logged(true);
  $('profile-name').textContent=user.name;
  $('profile-avatar').textContent=user.name.charAt(0).toUpperCase();
  $('profile-mini').textContent=staff()?'Recursos Humanos':'Trabajador';
  state.tab='requests';navButtons();updateNotificationBadge();
  $('page-title').textContent=staff()?'Bandeja de Recursos Humanos':'Mis solicitudes';
  // Un solo acceso al backend obtiene bandeja, catálogo y estados.
  const seq=navSequence;
  loadingAfterDelay(seq);
  try{
    const data=initialBootstrap??await api('requests/bootstrap');
    if(navSequence!==seq)return;
    state.types=data.types;state.statuses=data.statuses;
    readCache.set('requests/types',{value:data.types,until:Date.now()+30000});
    readCache.set('requests/statuses',{value:data.statuses,until:Date.now()+30000});
    await showRequests(data.requests);
    try{applyNotifications(await api('requests/notifications'));}catch(err){console.warn('Avisos no disponibles:',err.message)}
  }catch(err){
    if(seq===navSequence){$('main-content').innerHTML='<section class="panel"><b>No se pudieron cargar las solicitudes.</b><p>'+esc(err.message)+'</p><button type="button" class="outline" id="retry-inbox">Reintentar</button></section>';$('retry-inbox').onclick=()=>navigation('requests');notice(err.message,true)}
  }finally{if(seq===navSequence)clearTimeout(loadingTimer)}
}
async function init(){
  // Dos lecturas independientes en paralelo: menos espera a través de Ports.
  // El backend comprueba los permisos en ambas; no se omite la validación.
  try{
    const [sessionResult, bootstrapResult] = await Promise.allSettled([
      fetch('/api/identity/auth/me',{credentials:'same-origin'}),
      api('requests/bootstrap')
    ]);
    if(sessionResult.status==='rejected')throw sessionResult.reason;
    const response=sessionResult.value;
    if(response.status===401){logged(false);return}
    if(!response.ok){logged(false);notice('No se pudo conectar con la cuenta. Revisa el servidor y MySQL.',true);return}
    const user=await response.json();
    await renderWorkspace(user,bootstrapResult.status==='fulfilled'?bootstrapResult.value:null);
  }catch(err){logged(false);notice('No se pudo conectar con el servidor.',true)}
}
function navButtons(){
 const items=staff()?[['requests','Bandeja RR. HH.'],['reports','Indicadores'],['users','Usuarios'],['catalog','Trámites'],['alerts','Avisos'],['profile','Mi contraseña']]:[['requests','Mis solicitudes'],['alerts','Avisos'],['profile','Mi contraseña']];
 const icons={history:'📚',requests:staff()?'📥':'📁',reports:'📊',users:'👥',catalog:'📋',alerts:'🔔',profile:'🔒'};
 $('navigation').innerHTML=items.map(([id,label])=>`<button class="nav-btn ${state.tab===id?'active':''}" data-tab="${id}"><span class="nav-icon" aria-hidden="true">${icons[id]}</span><span>${esc(label)}</span>${id==='alerts'&&unreadNotifications?`<span class="nav-count">${unreadNotifications}</span>`:''}</button>`).join('');
}
async function navigation(tab){
 const seq=++navSequence;state.tab=tab;navButtons();
 $('page-title').textContent=({'requests':staff()?'Bandeja de Recursos Humanos':'Mis solicitudes',history:'Historial de solicitudes',reports:'Indicadores',users:'Gestión de trabajadores',catalog:'Catálogo de trámites',alerts:'Notificaciones',profile:'Mi contraseña'})[tab];
 // Evitar el parpadeo de la pantalla en blanco al cambiar de pestaña.
 if(tab!=='profile'&&!(tab==='requests'&&requestsFetchedAt&&Date.now()-requestsFetchedAt<20000))loadingAfterDelay(seq);
 try{
  if(tab==='requests')await showRequests();
  if(tab==='history')await showWorkerHistory();
  if(tab==='reports')await showReports();
  if(tab==='users')await showUsers();
  if(tab==='catalog')await showCatalog();
  if(tab==='alerts')await showAlerts();
  if(tab==='profile')await showProfile();
 }catch(e){if(seq===navSequence){$('main-content').innerHTML='<div class="panel"><b>No se pudo cargar esta sección.</b><p>'+esc(e.message)+'</p><button class="outline" id="retry-section">Reintentar</button></div>';$('retry-section').onclick=()=>navigation(tab);notice(e.message,true)}}
 finally{if(seq===navSequence)clearTimeout(loadingTimer)}
}
function optionTypes(all=false){return (all?'<option value="">Todos los trámites</option>':'<option value="">Selecciona un trámite</option>')+state.types.filter(t=>all||t.active).map(t=>`<option value="${esc(t.key)}">${esc(t.label)}</option>`).join('')}
function optionStates(){
 const usual=['REGISTRADA','EN_REVISION','OBSERVADA','ATENDIDA'];
 const actual=new Set((state.requests||[]).map(r=>r.status));
 const choices=[...usual,...['ACEPTADA','RECHAZADA','EN_PROCESO','CERRADA'].filter(k=>actual.has(k))];
 return '<option value="">Todos los estados</option>'+choices.filter(k=>state.statuses[k]).map(k=>`<option value="${esc(k)}">${esc(state.statuses[k])}</option>`).join('');
}
function dateLimits(typ){return typ==='date'?'min="1900-01-01" max="2100-12-31"':typ==='month'?'min="1900-01" max="2100-12"':''}
function validateFormDates(form){
  for(const field of form.querySelectorAll('input[type="date"],input[type="month"]')){
    const val=field.value;
    const valid=field.validity.valid && !field.validity.badInput && (!val || (field.type==='date'?/^\d{4}-\d{2}-\d{2}$/.test(val):/^\d{4}-\d{2}$/.test(val)));
    if(!valid){field.setCustomValidity('Ingresa una fecha válida con año de cuatro dígitos (1900 a 2100).');field.reportValidity();return false;}
    field.setCustomValidity('');
  }
  return true;
}
document.addEventListener('input',event=>{const el=event.target;if(el.matches?.('input[type="date"],input[type="month"]'))el.setCustomValidity('')});
// Al salir del campo, descarta fechas con un año de más de cuatro dígitos o fuera del rango permitido.
document.addEventListener('focusout',event=>{const el=event.target;if(!el.matches?.('input[type="date"],input[type="month"]'))return;if(el.validity.badInput||el.validity.rangeOverflow||el.validity.rangeUnderflow){el.value='';el.setCustomValidity('');notice('Escribe una fecha válida con año de cuatro dígitos.',true)}});
function timeField(f,raw=''){
 const m=String(raw||'').match(/^(\d{1,2}):(\d{2})/);
 const h=m?Number(m[1]):null;
 const value=h===null?'':String(h%12||12)+':'+m[2]+' '+(h>=12?'PM':'AM');
 return `<label>${esc(f.label)}<div class="clock-field" data-clock data-required="${f.required?'1':'0'}"><input class="time-single-input" data-time-input type="text" placeholder="8:30 AM" maxlength="10" value="${esc(value)}" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" ${f.required?'required':''} aria-label="${esc(f.label)}: escribir hora y AM o PM"><input type="hidden" name="${esc(f.key)}" value="${esc(raw)}"></div></label>`;
}
function syncTimeFields(form){
 for(const wrap of form.querySelectorAll('[data-clock]')){
  const field=wrap.querySelector('[data-time-input]');
  const value=field.value.trim().toUpperCase().replace(/\s+/g,' ');
  const hidden=wrap.querySelector('input[type=hidden]');
  if(!value){if(wrap.dataset.required==='1'){field.setCustomValidity('Escribe la hora, por ejemplo 8:30 AM');field.reportValidity();field.focus();return false}field.setCustomValidity('');hidden.value='';continue}
  const match=value.match(/^(\d{1,2})(?::([0-5]\d))?\s*(AM|PM)$/);
  const h=match?Number(match[1]):0;
  if(!match||h<1||h>12){field.setCustomValidity('Indica una hora del 1 al 12 y AM o PM. Ejemplo: 8:30 AM');field.reportValidity();field.focus();return false}
  field.setCustomValidity('');
  const min=match[2]||'00';
  hidden.value=String(h%12+(match[3]==='PM'?12:0)).padStart(2,'0')+':'+min;
  field.value=h+':'+min+' '+match[3];
 }
 return true;
}
document.addEventListener('input',e=>{if(e.target.matches?.('[data-time-input]'))e.target.setCustomValidity('')});
function fieldMarkup(t){if(!t)return '';return t.fields.map(f=>{let typ=['date','time','month'].includes(f.type)?f.type:'text';if(typ==='time')return timeField(f);return `<label>${esc(f.label)}<input type="${typ}" name="${esc(f.key)}" ${f.required?'required':''} ${dateLimits(typ)} maxlength="300" /></label>`}).join('')}
async function showWorkerHistory(){
 if(staff())return navigation('requests');
 const seq=navSequence;
 const records=await api('requests/requests');
 if(seq!==navSequence||state.tab!=='history')return;
 state.requests=records;
 const rows=[...records].sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
 $('main-content').innerHTML='<div class="content-title"><div><h3>Historial de mis solicitudes</h3><p>Consulta los trámites enviados, las respuestas de RR. HH. y el historial de cada expediente.</p></div><button class="outline" id="history-refresh">Actualizar</button></div>'
   +'<div class="panel"><div class="table-scroll"><table class="data-table"><thead><tr><th>Código</th><th>Trámite</th><th>Fecha de envío</th><th>Estado actual</th><th>Acción</th></tr></thead><tbody>'
   +(rows.length?rows.map(r=>'<tr><td><b>'+esc(r.code)+'</b></td><td>'+esc(r.type_name)+'</td><td>'+date(r.created_at)+'</td><td>'+badge(r.status)+'</td><td><button class="outline" data-history-open="'+r.id+'">Ver historial</button></td></tr>').join(''):'<tr><td colspan="5">Aún no has enviado solicitudes.</td></tr>')
   +'</tbody></table></div></div>';
 $('history-refresh').onclick=showWorkerHistory;
 document.querySelectorAll('[data-history-open]').forEach(b=>b.onclick=()=>openDetail(Number(b.dataset.historyOpen)));
}
function showFields(){
 let t=state.types.find(t=>t.key===$('new-type')?.value);
 $('dynamic-fields').innerHTML=t?`<h4>Datos específicos: ${esc(t.label)}</h4><div class="field-grid">${fieldMarkup(t)}</div>`:'';
 const medical=t?.key==='DESCANSO_MEDICO',file=document.querySelector('#create-form [name="support_file"]');
 if(file){file.required=medical;file.closest('label').firstChild.textContent=medical?'Sustento médico del trabajador (PDF obligatorio, máximo 4 MB)':'Documento de sustento (opcional, PDF hasta 4 MB)';}
 const memo=$('request-notes'),memoLabel=$('request-notes-label');
 if(memo&&memoLabel){
  const hasSpecific=!!t?.fields?.length;
  memo.required=!hasSpecific;
  memo.minLength=hasSpecific?0:10;
  memoLabel.firstChild.textContent=hasSpecific?'Observaciones adicionales (opcional)':'Motivo o detalle de la solicitud';
  memo.placeholder=hasSpecific?'Solo si necesitas aclarar información':'Explica el motivo del trámite (mínimo 10 caracteres)';
 }
}
function correctionFields(r){const t=state.types.find(t=>t.key===r.type);return (t?.fields||[]).map(f=>{const typ=['date','time','month'].includes(f.type)?f.type:'text';if(typ==='time')return timeField(f,r.details?.[f.key]||'');return `<label>${esc(f.label)}<input type="${typ}" name="${esc(f.key)}" value="${esc(r.details?.[f.key]||'')}" ${f.required?'required':''} ${dateLimits(typ)} maxlength="300"></label>`}).join('')}

function filtered(){let query=$('f-query')?.value.toLowerCase().trim()||'',s=$('f-status')?.value||'',t=$('f-type')?.value||'',from=$('f-from')?.value||'',to=$('f-to')?.value||'';return state.requests.filter(x=>(!query||[x.code,x.subject,x.requester_name].some(a=>String(a).toLowerCase().includes(query)))&&(!s||x.status===s)&&(!t||x.type===t)&&(!from||x.created_at.slice(0,10)>=from)&&(!to||x.created_at.slice(0,10)<=to))}
function openNewRequestPage(){
 if(staff())return;
 const main=$('main-content'),panel=$('new-form-panel');
 if(!panel)return;
 main.classList.add('request-create-mode');
 panel.classList.remove('hidden');
 $('page-title').textContent='Nueva solicitud';
 window.scrollTo({top:0,behavior:'instant'});
 $('new-type')?.focus();
}
function closeNewRequestPage(){
 $('main-content').classList.remove('request-create-mode');
 $('page-title').textContent='Mis solicitudes';
 showRequests(state.requests);
}
async function showRequests(prefetched=null,force=false){const navAtStart=navSequence;const data=prefetched??(!force&&requestsFetchedAt&&Date.now()-requestsFetchedAt<20000?state.requests:await api('requests/requests'));if(navAtStart!==navSequence||state.tab!=='requests')return;state.requests=data;lastInboxSignature=inboxSignature(data);requestsFetchedAt=Date.now();visibleRows=50;
 $('main-content').classList.remove('request-create-mode');
 const keys=['REGISTRADA','EN_REVISION','OBSERVADA','ATENDIDA',
 ...['ACEPTADA','RECHAZADA','EN_PROCESO','CERRADA'].filter(k=>state.requests.some(r=>r.status===k))];
 const counters=[['Total',state.requests.length],...keys.map(k=>[state.statuses[k]||k,state.requests.filter(r=>r.status===k).length])];
 $('main-content').innerHTML=`
<div class="content-title"><div><h3>${staff()?'Todas las solicitudes':'Solicitudes del personal'}</h3><p>${staff()?'Consulta las solicitudes pendientes y respondidas. Las respuestas permanecen aquí y solo se retiran de Avisos.':'Registra un trámite y consulta su estado, responsable y respuestas.'}</p></div>${staff()?'<button class="outline" id="export-csv">Exportar reporte CSV</button>':'<button class="primary" id="new-request">+ Nueva solicitud</button>'} <button class="outline" type="button" id="refresh-requests">Actualizar</button></div>
<div class="stats" aria-label="Solicitudes por estado">${counters.map(([name,count])=>`<div class="stat"><span>${esc(name)}</span><strong>${count}</strong></div>`).join('')}</div>

<div class="panel"><div class="filters"><input id="f-query" placeholder="Código, asunto o persona" aria-label="Buscar"><select id="f-status" aria-label="Estado">${optionStates()}</select><select id="f-type" aria-label="Tipo">${optionTypes(true)}</select><details class="advanced-filters"><summary>Filtrar por fecha</summary><div class="date-fields"><label>Desde<input type="date" id="f-from"></label><label>Hasta<input type="date" id="f-to"></label></div></details></div><div class="table-scroll" id="requests-table"></div></div>
${staff()?'':`<section class="panel request-sheet hidden" id="new-form-panel"><div class="request-sheet-top"><button type="button" class="outline" id="cancel-new-request">← Volver a mis solicitudes</button><span class="request-sheet-step">Formulario de solicitud</span></div><h3>Registrar solicitud</h3><p class="muted small">Selecciona el tipo de trámite. Los campos obligatorios dependen de tu elección.</p><form id="create-form"><label>Tipo de trámite<select name="type" id="new-type" required>${optionTypes()}</select></label><div id="dynamic-fields"></div><label id="request-notes-label">Información adicional (opcional)<textarea name="description" id="request-notes" maxlength="4000" placeholder="Agrega información necesaria que no figure en los campos anteriores"></textarea></label><label>Documento de sustento (opcional, PDF hasta 4 MB)<input type="file" name="support_file" accept="application/pdf,.pdf"></label><button class="primary">Registrar expediente</button></form></section>`}`;
for(const k of ['f-query','f-status','f-type','f-from','f-to'])$(k).addEventListener('input',()=>{
  clearTimeout(filterTimeout);
  filterTimeout=setTimeout(()=>{visibleRows=50;paintRows()},k==='f-query'?180:0);
});
$('refresh-requests').onclick=()=>{invalidateData();showRequests(null,true)};
if(staff()){$('export-csv').onclick=exportCSV;}
else{$('new-request').onclick=openNewRequestPage;$('cancel-new-request').onclick=closeNewRequestPage;$('new-type').onchange=showFields;$('create-form').onsubmit=async e=>{e.preventDefault();if(!validateFormDates(e.target)||!syncTimeFields(e.target))return;const submit=e.target.querySelector('button[type=submit],button.primary');if(submit.disabled)return;submit.disabled=true;let form=new FormData(e.target);let t=state.types.find(x=>x.key===form.get('type'));let details={};(t?.fields||[]).forEach(f=>details[f.key]=String(form.get(f.key)||''));try{const f=form.get('support_file');if(t?.key==='DESCANSO_MEDICO'&&!(f&&f.size))throw Error('Adjunta tu sustento médico en PDF para registrar el descanso.');if(f&&f.size){if(f.size>4*1024*1024||!f.name.toLowerCase().endsWith('.pdf'))throw Error('El documento debe ser un PDF de hasta 4 MB.')}const formatted=(t?.fields||[]).filter(f=>details[f.key]?.trim()).map(f=>f.label+': '+details[f.key].trim());
const observations=String(form.get('description')||'').trim();
const description=(formatted.length?'Datos del trámite: '+formatted.join('; '):'')
   +(observations?(formatted.length?' | Observaciones: ':'')+observations:'');
const subject=t?.label||'Solicitud administrativa';
let r=await api('requests/requests',json({type:form.get('type'),subject,description,details}));if(f&&f.size){const upload=new FormData();upload.append('file',f);try{await api(`requests/requests/${r.id}/attachments`,{method:'POST',body:upload})}catch(fileError){notice('Solicitud registrada, pero no se pudo subir el PDF: '+fileError.message,true)}}notice('Solicitud enviada: '+r.code);invalidateData();await showRequests(null,true);await openDetail(r.id)}catch(err){notice(err.message,true)}finally{if(submit?.isConnected)submit.disabled=false}}}
paintRows()}
function paintRows(){
 const rows=filtered();const page=rows.slice(0,visibleRows);
 $('requests-table').innerHTML=rows.length?`<table><thead><tr><th>Código / Asunto</th><th>Trámite</th>${staff()?'<th>Trabajador</th>':''}<th>Estado</th><th>Responsable</th><th>Fecha</th><th></th></tr></thead><tbody>${page.map(r=>`<tr><td><b>${esc(r.code)}</b>${r.is_demo?'<small>Dato de prueba</small>':''}<small>${esc(r.subject)}</small></td><td>${esc(r.type_name)}</td>${staff()?`<td>${esc(r.requester_name)}</td>`:''}<td>${badge(r.status)}</td><td>${esc(r.assignee_name||'Recursos Humanos')}</td><td>${date(r.created_at)}</td><td><button data-detail="${r.id}" class="outline">Abrir</button></td></tr>`).join('')}</tbody></table><div class="table-pagination"><span>Mostrando ${page.length} de ${rows.length} solicitudes</span>${page.length<rows.length?'<button type="button" class="outline" id="load-more-rows">Mostrar más</button>':''}</div>`:'<div class="empty"><strong>Sin solicitudes para estos filtros.</strong></div>';
 if($('load-more-rows'))$('load-more-rows').onclick=()=>{visibleRows+=50;paintRows()};
}
function exportCSV(){let h=['Código','Trámite','Trabajador','Estado','Responsable','Fecha'];let safe=x=>{let s=String(x??'');if(/^[=+@-]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"'};let lines=[h,...filtered().map(r=>[r.code,r.type_name,r.requester_name,r.status_name,r.assignee_name,r.created_at])].map(a=>a.map(safe).join(';')).join('\r\n');let blob=new Blob(['\ufeff'+lines],{type:'text/csv;charset=utf-8'});let url=URL.createObjectURL(blob);let a=document.createElement('a');a.href=url;a.download='reporte_solicitudes_'+new Date().toISOString().slice(0,10)+'.csv';a.click();URL.revokeObjectURL(url)}
async function openDetail(id){try{let r=await api('requests/requests/'+id);
if(staff()&&r.status==='REGISTRADA'){
 try{
  const refreshed=await api('requests/requests/'+id+'?track=false');
  r=refreshed;
  if(r.status==='REGISTRADA'){
   await api('requests/requests/'+id+'/status',json({status:'EN_REVISION',detail:'Recibida por Recursos Humanos.'}));
   r=await api('requests/requests/'+id+'?track=false');
  }
  if(r.status==='REGISTRADA')notice('No se pudo iniciar la revisión de esta solicitud.',true);
 }catch(error){
  console.warn('No se pudo iniciar revisión:',error.message);
  notice('La solicitud sigue registrada. No se pudo cambiar a En revisión: '+error.message,true);
 }
}
state.active=r;$('detail-code').textContent=r.code+(r.is_demo?' · DEMOSTRACIÓN':'')+' · '+r.type_name;$('detail-title').textContent=r.subject;renderDetail(r);if(!$('detail-dialog').open)$('detail-dialog').showModal();if(staff()&&state.tab==='requests'&&$('requests-table')){try{state.requests=await api('requests/requests');requestsFetchedAt=Date.now();lastInboxSignature=inboxSignature(state.requests);paintRows()}catch(err){console.info('La bandeja se actualizará en la siguiente lectura:',err.message)}}return true}catch(e){notice(e.message,true);return false}}
function detailsHtml(r){const t=state.types.find(t=>t.key===r.type);const entries=(t?.fields||[]).map(f=>`<div><small>${esc(f.label)}</small><b>${esc(r.details?.[f.key]||'—')}</b></div>`).join('');return entries?`<h4>Datos del trámite</h4><div class="field-grid detail-fields">${entries}</div>`:''}
function visibleHistory(history){
 // Los duplicados generados por versiones antiguas se agrupan solo en pantalla.
 // Los eventos reales permanecen intactos en MySQL; las nuevas correcciones detallan qué cambió.
 const result=[];
 for(const entry of history||[]){
  const prev=result[result.length-1];
  const sameLegacyCorrection=prev&&entry.kind==='CORRECCION'&&prev.kind==='CORRECCION'
    &&['Corrección de información','Corrección de datos'].includes((entry.detail||'').trim())
    &&prev.detail===entry.detail&&prev.actor_id===entry.actor_id
    &&prev.from_status===entry.from_status&&prev.to_status===entry.to_status
    &&Math.abs(new Date(entry.recorded_at)-new Date(prev.recorded_at))<=120000;
  if(!sameLegacyCorrection)result.push(entry);
 }
 return result;
}
function historyTitle(e){
 if(e.kind==='CREACION')return 'Solicitud recibida';
 if(e.kind==='CORRECCION')return 'Datos corregidos';
 if(e.kind==='SUBSANACION')return 'Solicitud subsanada';
 if(e.kind==='CAMBIO_ESTADO')return e.to_status==='EN_REVISION'?'Revisión iniciada':'Respuesta de Recursos Humanos';
 if(e.kind==='ADJUNTO')return 'Documento adjuntado';
 if(e.kind==='COMENTARIO')return 'Comentario anterior';
 if(e.kind==='TIEMPO_ATENCION')return 'Tiempo de atención de Recursos Humanos';
 return 'Actividad registrada';
}
function statusAdvice(r){
 if(staff())return '';
 const events=[...(r.history||[])].filter(e=>e.kind==='CAMBIO_ESTADO');
 // Conservar la respuesta real de RR. HH. aunque el expediente se cierre después.
 const last=[...events].reverse().find(e=>['OBSERVADA','ATENDIDA','ACEPTADA','RECHAZADA'].includes(e.to_status)&&String(e.detail||'').trim());
 const answer=last?String(last.detail).split(' | Resultado: ')[0]:'';
 const response=answer?`<p><b>Respuesta de Recursos Humanos:</b> ${esc(answer)}</p>`:'';
 if(r.status==='OBSERVADA')return `<div class="note"><b>Se necesita una subsanación.</b> ${response}<p>Corrige los datos o adjunta el documento solicitado en este mismo expediente.</p></div>`;
 if(r.status==='REGISTRADA')return '<p class="muted small">Tu solicitud se envió a Recursos Humanos. Verás «En revisión» cuando abran el expediente.</p>';
 if(r.status==='EN_REVISION'||r.status==='EN_PROCESO')return `<div class="note"><b>En revisión por Recursos Humanos.</b>${response}</div>`;
 if(r.status==='ACEPTADA')return `<div class="note"><b>Solicitud aceptada.</b>${response}</div>`;
 if(r.status==='ATENDIDA'||r.status==='CERRADA')return `<div class="note"><b>Solicitud atendida.</b>${response}<p>Consulta el historial y los documentos disponibles.</p></div>`;
 if(r.status==='RECHAZADA')return `<div class="note"><b>Solicitud rechazada.</b>${response}</div>`;
 return '';
}

const ISSUED_CATEGORIES=new Set(['CONSTANCIA_TRABAJO','CERTIFICADO_LABORAL','CERTIFICADO_PRACTICAS','BOLETA_PAGO']);
async function showIssuedDocuments(r){
 if(!ISSUED_CATEGORIES.has(r.type))return;
 const body=$('detail-body');if(!body)return;
 try{
  const docs=await api('requests/requests/'+r.id+'/issued-documents');
  if(state.active?.id!==r.id||!body.isConnected||!docs.length)return;
  const region=document.createElement('section');
  region.className='panel issued-delivery';region.id='issued-documents';
  const heading=document.createElement('h4');heading.textContent='Documento laboral entregado';region.append(heading);
  const group=document.createElement('div');group.className='issued-file-list';
  docs.forEach(d=>{
   const line=document.createElement('div');line.className='issued-file';
   const a=document.createElement('a');a.href='/api/requests/issued-documents/'+encodeURIComponent(d.id);
   a.textContent='Descargar PDF · '+d.filename;a.className='outline';line.append(a);group.append(line);
  });
  region.append(group);
  const responsePanel=body.querySelector('.response-panel');
  if(responsePanel)body.insertBefore(region,responsePanel);else body.append(region);
 }catch(err){if(staff())notice('No se pudo consultar el documento: '+err.message,true)}
}

function renderDetail(r){let h=`<div class="detail-meta"><div><small>Estado actual</small>${badge(r.status)}</div><div><small>Responsable</small><b>${esc(r.assignee_name||'Recursos Humanos')}</b></div><div><small>Solicitante</small><b>${esc(r.requester_name)}</b></div></div><p class="muted small">Fecha y hora de envío: ${date(r.created_at)} · Última actualización: ${date(r.updated_at)}</p>${r.description.startsWith('Datos del trámite: ')?'':`<p>${esc(r.description)}</p>`}${statusAdvice(r)}${detailsHtml(r)}<div class="rule"></div><h4>Historial de la solicitud</h4><div class="timeline">${visibleHistory(r.history).map(e=>`<div class="timeline-item"><strong>${esc(historyTitle(e))} ${e.kind==='CAMBIO_ESTADO'?badge(e.to_status):''}</strong><p>${esc(e.kind==='CORRECCION'&&e.detail==='Corrección de información'?'Se actualizaron los datos de la solicitud.':e.detail)}</p><small>${date(e.recorded_at)} · ${esc(e.actor_name)}</small></div>`).join('')}</div>${r.attachments.length?`<div class="rule"></div><h4>Documentos adjuntos</h4><div class="files">${r.attachments.map(a=>`<a class="file-link" data-file="${a.id}" href="#">${esc(a.name)} · ${(a.size/1024).toFixed(0)} KB</a>`).join('')}</div>`:''}`;
if(!finished(r)&&!staff())h+=`<form id="attachment-form"><label>Adjuntar PDF (hasta 4 MB por documento)<input name="file" type="file" accept="application/pdf,.pdf" multiple required></label><button class="outline">Subir documento</button></form>`;
if(!staff()&&['REGISTRADA','OBSERVADA'].includes(r.status))h+=`<div class="rule"></div><h4>${r.status==='OBSERVADA'?'Corregir solicitud observada':'Corregir datos de la solicitud'}</h4><p class="small muted">Se actualiza este mismo expediente y se conserva su historial. No es necesario crear otro trámite.</p><form id="correct-form"><label>Observaciones adicionales (opcional)<textarea name="description" maxlength="4000" placeholder="Escribe solo si necesitas aclarar los datos">${esc(r.description.startsWith('Datos del trámite: ')?'':r.description)}</textarea></label><div class="field-grid">${correctionFields(r)}</div><button class="primary">Guardar corrección</button></form>${r.status==='OBSERVADA'?`<p class="small muted">Si solo faltaba un documento, adjúntalo arriba y después pulsa este botón.</p><button type="button" class="outline" id="submit-subsanation">Enviar documento para revisión</button>`:''}`;
if(staff()&&canFinish(r))h+=`<section class="response-panel"><div class="rule"></div><h4>Responder al trabajador</h4><form id="state-form"><label>Actualizar estado<select id="next-status" name="status" required><option value="" selected disabled>Selecciona el estado</option>${['ATENDIDA','OBSERVADA','RECHAZADA'].map(v=>`<option value="${v}">${esc(state.statuses[v]||v.charAt(0)+v.slice(1).toLowerCase())}</option>`).join('')}</select></label><div id="resolution-area"></div><label id="reason-label">Respuesta al trabajador<textarea id="status-reason" name="detail" maxlength="2000" placeholder="Escribe una explicación clara para el trabajador"></textarea></label><p id="reason-hint" class="muted small"></p><button class="primary">Guardar respuesta</button></form></section>`;

$('detail-body').innerHTML=h;
if(staff()){
 const panel=$('detail-body').querySelector('.response-panel');
 const anchor=$('detail-body').querySelector('.detail-fields')||$('detail-body').querySelector('.detail-meta');
 if(panel&&anchor)anchor.insertAdjacentElement('afterend',panel);
}
showIssuedDocuments(r);
if($('next-status')){
 const select=$('next-status'),form=$('state-form'),area=$('resolution-area');
 select.onchange=()=>{
  const next=select.value;
  const issued=ISSUED_CATEGORIES.has(r.type);
  const needsPDF=issued&&next==='ATENDIDA';
  const reason=$('status-reason'),label=$('reason-label');
  label.hidden=needsPDF;
  reason.required=!needsPDF&&['OBSERVADA','RECHAZADA','ATENDIDA','ACEPTADA','CERRADA'].includes(next);
  reason.minLength=reason.required?5:0;
  $('reason-hint').textContent=needsPDF?'':reason.required?'Escribe la respuesta que verá el trabajador.':'';
  if(needsPDF){
   area.innerHTML='<label>PDF oficial para el trabajador (máximo 4 MB)<input type="file" name="file" accept=".pdf,application/pdf" required></label>';
  }else if(next==='ATENDIDA'){
   area.innerHTML=`<label>Resultado del trámite<select name="result_kind" required>${(r.outcomes||[]).map(k=>`<option value="${esc(k)}" ${['AUTORIZADA','DENEGADA'].includes(k)&&!r.authorized_to_decide?'disabled':''}>${esc(k.replace(/_/g,' '))}</option>`).join('')}</select></label>`;
  }else area.replaceChildren();
  const submit=form.querySelector('button[type=submit],button.primary');
  if(submit)submit.textContent=needsPDF?'Entregar PDF':'Guardar respuesta';
 };
 select.onchange();
 form.onsubmit=async e=>{
  e.preventDefault();
  const selected=select.value;
  if(ISSUED_CATEGORIES.has(r.type)&&selected==='ATENDIDA'){
   const file=area.querySelector('input[type=file]')?.files?.[0];
   if(!file)return notice('Selecciona el PDF oficial.',true);
   if(file.size>4*1024*1024||!file.name.toLowerCase().endsWith('.pdf'))return notice('El PDF debe tener un tamaño máximo de 4 MB.',true);
   const btn=form.querySelector('button.primary');if(btn.disabled)return;btn.disabled=true;
   const payload=new FormData();payload.append('file',file);
   try{
    await api('requests/requests/'+r.id+'/issued-documents',{method:'POST',body:payload});
    invalidateData();
    await refreshDetail(r.id);
    await dismissStaffNotices(r.id);
    notice('PDF entregado. Solicitud atendida.');
   }catch(err){notice(err.message,true)}
   finally{if(btn.isConnected)btn.disabled=false}
   return;
  }
  if(!Array.isArray(r.transitions)||!r.transitions.includes(selected)){notice('Este estado todavía no está habilitado por el servidor para esta solicitud.',true);return}
  const data=Object.fromEntries(new FormData(form));
  if(r.consultation_id)data.consultation_id=r.consultation_id;
  await send(e,`requests/requests/${r.id}/status`,data,r.id,'Respuesta registrada');
 };
}
if($('correct-form'))$('correct-form').onsubmit=async e=>{e.preventDefault();if(!validateFormDates(e.target)||!syncTimeFields(e.target))return;const form=new FormData(e.target);const cfg=state.types.find(x=>x.key===r.type);const details={};for(const f of cfg?.fields||[])details[f.key]=String(form.get(f.key)||'');const button=e.target.querySelector('button[type="submit"],button:not([type])');if(button.disabled)return;button.disabled=true;try{const outcome=await api(`requests/requests/${r.id}`,patch({subject:r.subject,
 description:(cfg?.fields||[]).filter(f=>details[f.key]?.trim())
  .map(f=>f.label+': '+details[f.key].trim()).join('; ').padStart(0)
  .replace(/^/,'Datos del trámite: ')
  +(String(form.get('description')||'').trim()?' | Observaciones: '+String(form.get('description')).trim():''),
 details}));invalidateData();notice(outcome.unchanged?'No hay cambios para guardar.':'Solicitud corregida');await refreshDetail(r.id)}catch(err){notice(err.message,true)}finally{button.disabled=false}};
if($('submit-subsanation'))$('submit-subsanation').onclick=async e=>{
 const button=e.currentTarget;if(button.disabled)return;button.disabled=true;
 try{await api(`requests/requests/${r.id}/subsanar`,json({}));notice('Documento enviado');await refreshDetail(r.id)}
 catch(err){notice(err.message,true)}finally{if(button.isConnected)button.disabled=false}
};
if($('attachment-form'))$('attachment-form').onsubmit=async e=>{e.preventDefault();try{const files=[...e.target.querySelector('input[type=file]').files];if(!files.length)return;for(const f of files){if(f.size>4*1024*1024||!f.name.toLowerCase().endsWith('.pdf'))throw Error('Cada archivo debe ser PDF y no superar 4 MB.')}let uploaded=0;for(const f of files){const form=new FormData();form.append('file',f);await api(`requests/requests/${r.id}/attachments`,{method:'POST',body:form});uploaded++}invalidateData();notice('Documento adjuntado');await refreshDetail(r.id)}catch(err){notice(err.message,true)}};

}
async function refreshDetail(id){let r=await api('requests/requests/'+id+'?track=false');state.active=r;renderDetail(r);invalidateData();if(state.tab==='requests'&&$('requests-table')){state.requests=await api('requests/requests');requestsFetchedAt=Date.now();paintRows()}}
async function dismissStaffNotices(id){
 if(!staff())return;
 try{
  const notices=await api('requests/notifications');
  const mine=notices.filter(n=>String(n.request_id)===String(id)&&!n.read);
  await Promise.allSettled(mine.map(n=>api('requests/notifications/'+n.id+'/read',json({}))));
  applyNotifications(await api('requests/notifications'),{announce:false});
 }catch(err){console.warn('No se pudo actualizar la bandeja de avisos:',err.message)}
}
async function send(e,path,data,id,message='Expediente actualizado'){
 e.preventDefault();const button=e.target.querySelector('button[type=submit],button.primary');
 if(button?.disabled)return;
 if(button)button.disabled=true;
 try{
  await api(path,json(data));
  invalidateData();
  await refreshDetail(id);
  await dismissStaffNotices(id);
  notice(message);
 }catch(err){notice(err.message,true)}
 finally{if(button?.isConnected)button.disabled=false}
}
function reportPercent(value){
  const n=Number(value);
  return value===null||value===undefined||value===''||!Number.isFinite(n)?'Pendiente':n.toLocaleString('es-PE',{maximumFractionDigits:1})+' %';
}
function reportResponseTime(data){
  const raw=data?.mean_seconds;
  if(raw===null||raw===undefined||raw==='')return 'Pendiente';
  const seconds=Number(raw);
  if(!Number.isFinite(seconds)||seconds<0)return 'Pendiente';
  const whole=Math.max(0,Math.round(seconds));
  if(whole<60)return whole+' s';
  const minutes=Math.floor(whole/60),remainder=whole%60;
  if(minutes<60)return minutes+' min'+(remainder?' '+remainder+' s':'');
  const hours=Math.floor(minutes/60),left=minutes%60;
  return hours+' h'+(left?' '+left+' min':'');
}
function reportBar(label,count,total){
  const n=Number(count)||0, den=Number(total)||0;
  const percentage=den?Math.max(0,Math.min(100,n*100/den)):0;
  return `<div class="report-bar-row"><div class="report-bar-meta"><span>${esc(label)}</span><strong>${n.toLocaleString('es-PE')} <small>(${percentage.toFixed(1)} %)</small></strong></div><div class="report-bar-track"><progress aria-label="${esc(label)}" max="100" value="${percentage.toFixed(1)}"></progress></div></div>`;
}
function reportMetric(label,value,subtitle,icon){
  return `<article class="report-metric"><div class="report-metric-head"><span>${esc(label)}</span><span class="report-metric-icon" aria-hidden="true">${icon}</span></div><strong>${esc(value)}</strong><small>${esc(subtitle)}</small></article>`;
}
async function showReports(force=false){
  const started=navSequence;
  let r=!force&&reportsCache&&Date.now()-reportsFetchedAt<20000?reportsCache:await api('reports/summary');
  reportsCache=r;reportsFetchedAt=Date.now();
  if(started!==navSequence||state.tab!=='reports')return;
  const stateEntries=Object.entries(r.by_status||{}).filter(([,count])=>count>0);
  const typeEntries=Object.entries(r.by_type||{}).filter(([,count])=>count>0)
    .map(([key,count])=>[state.types.find(t=>t.key===key)?.label||key,count]);
  const trace=r.trace||{};
  const timely=r.timely||{};
  $('main-content').innerHTML=`
  <section class="report-heading"><div><span class="report-eyebrow">ANÁLISIS OPERATIVO</span><h3>Panel de seguimiento</h3><p>Seguimiento de las solicitudes y respuestas registradas por Recursos Humanos.</p></div><div class="report-actions"><button id="download-posttest" class="primary" type="button">Exportar CSV</button><button id="refresh" class="outline" type="button">Actualizar</button></div></section>
  <section class="report-metrics" aria-label="Indicadores principales">
    ${reportMetric('Solicitudes registradas',r.total,'Expedientes reales','▣')}
    ${reportMetric('Tiempo de consulta RR. HH.',(r.total||0)===0?'—':reportResponseTime(r.consultation),(r.total||0)===0?'Sin expedientes':`${r.consultation?.valid||0} respuestas medidas · desde apertura hasta respuesta`,'◷')}
    ${reportMetric('Trazabilidad completa',(r.total||0)===0?'—':trace.percent==null?'Pendiente':reportPercent(trace.percent),(r.total||0)===0?'Sin expedientes':`${trace.complete||0} de ${trace.evaluable||0} expedientes con historial completo`,'✓')}
    ${reportMetric('Actualización oportuna',(r.total||0)===0?'—':timely.percent==null?'Pendiente':reportPercent(timely.percent),(r.total||0)===0?'Sin expedientes':`${timely.complete||0} de ${timely.evaluable||0} evaluables · SLA operativo ${timely.deadline_hours||48} h desde registro · ${timely.pending||0} pendientes`,'↻')}
  </section>
  <div class="report-columns"><section class="panel report-chart"><div class="report-title"><h3>Solicitudes por estado</h3><span>${r.total||0} expedientes</span></div><div class="report-bars">${stateEntries.length?stateEntries.map(([key,count])=>reportBar(state.statuses[key]||key,count,r.total)).join(''):'<p class="muted">Aún no hay expedientes registrados.</p>'}</div></section>
  <section class="panel report-chart"><div class="report-title"><h3>Trámites más utilizados</h3><span>Distribución por tipo</span></div><div class="report-bars">${typeEntries.length?typeEntries.sort((a,b)=>b[1]-a[1]).map(([name,count])=>reportBar(name,count,r.total)).join(''):'<p class="muted">Todavía no hay trámites para comparar.</p>'}</div></section></div>
  `
  const refreshButton=$('refresh');
  const downloadButton=$('download-posttest');
  if(refreshButton)refreshButton.addEventListener('click',()=>showReports(true));
  if(downloadButton)downloadButton.addEventListener('click',async()=>{try{
    const blob=await api('reports/mediciones.csv');const url=URL.createObjectURL(blob);
    const a=document.createElement('a');a.href=url;a.download='indicadores_colegio_'+new Date().toISOString().slice(0,10)+'.csv';a.click();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
  }catch(e){notice(e.message,true)}});
}
async function showUsers(){
 if(!staff())return navigation('requests');
 const started=navSequence,us=await api('identity/users');if(started!==navSequence)return;
 $('main-content').innerHTML=`<div class="content-title"><div><h3>Usuarios</h3><p>Crea cuentas y administra accesos. El rol Recursos Humanos incluye revisión, aprobación y denegación de los trámites correspondientes.</p></div><button type="button" class="primary" id="add-user-toggle">+ Nuevo usuario</button></div>
 <section class="panel hidden" id="add-user-panel"><h3>Crear usuario</h3><p class="muted small">La cuenta queda activa inmediatamente. Entrega la contraseña inicial de forma privada; la persona puede cambiarla desde «Mi contraseña».</p>
   <form id="add-user-form"><div class="user-form-grid"><label>Nombre completo<input name="name" required minlength="3" maxlength="120" autocomplete="off" placeholder="Nombre y apellidos"></label>
   <label>Correo electrónico<input name="email" type="email" required maxlength="190" autocomplete="off" placeholder="persona@institucion.edu.pe"></label>
   <label>Rol<select name="role"><option value="TRABAJADOR">Trabajador</option><option value="RRHH">Recursos Humanos</option></select></label>
   <label>Contraseña inicial<input type="text" name="password" id="initial-user-password" minlength="10" maxlength="100" required autocomplete="off" spellcheck="false" placeholder="Mínimo 10 caracteres"></label></div>
   <div class="form-actions"><button type="button" class="outline" id="generate-user-password">Generar contraseña segura</button><button type="submit" class="primary">Crear cuenta</button></div>
   <p class="muted small">Por seguridad, el sistema no vuelve a mostrar contraseñas ya guardadas.</p></form></section>
 <section class="panel"><div class="table-scroll"><table><thead><tr><th>Usuario</th><th>Rol</th><th>Estado</th><th>Acción</th></tr></thead>
 <tbody>${us.map(u=>`<tr><td><b>${esc(u.name)}</b><small>${esc(u.email)}</small></td><td><select aria-label="Rol de ${esc(u.name)}" data-role-user="${u.id}" ${u.id===state.user.id?'disabled':''}><option value="TRABAJADOR" ${u.role==='TRABAJADOR'?'selected':''}>Trabajador</option><option value="RRHH" ${u.role==='RRHH'?'selected':''}>Recursos Humanos</option></select></td><td>${u.active?'Activo':'Inactivo'}</td><td class="user-actions-cell"><div class="user-actions"><div class="user-actions-row"><button type="button" class="outline" data-save-user="${u.id}" ${u.id===state.user.id?'disabled':''}>Guardar rol</button> <button type="button" class="outline" data-user-toggle="${u.id}" data-now="${u.active?'1':'0'}" ${u.id===state.user.id?'disabled':''}>${u.active?'Desactivar':'Activar'}</button> <button type="button" class="outline" data-user-reset="${u.id}">Restablecer clave</button></div></div></td></tr>`).join('')}</tbody></table></div></section>`;
 $('add-user-toggle').onclick=()=>{$('add-user-panel').classList.toggle('hidden');if(!$('add-user-panel').classList.contains('hidden'))$('add-user-panel').scrollIntoView({behavior:'smooth',block:'nearest'})};
 const makePassword=()=>{const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';const nums=new Uint32Array(20);crypto.getRandomValues(nums);return Array.from(nums,n=>alphabet[n%alphabet.length]).join('')};
 $('generate-user-password').onclick=()=>{$('initial-user-password').value=makePassword()};
 $('add-user-form').onsubmit=async e=>{e.preventDefault();const button=e.target.querySelector('[type="submit"]');button.disabled=true;
   const form=new FormData(e.target);const data=Object.fromEntries(['name','email','role','password'].map(k=>[k,String(form.get(k)||'')]));
   if(!window.confirm('¿Crear y activar una cuenta de '+(data.role==='RRHH'?'Recursos Humanos':'Trabajador')+'?')){button.disabled=false;return}
   try{const u=await api('identity/users',json(data));notice('Usuario '+u.email+' creado. Entrega su clave inicial de forma privada.');await showUsers()}
   catch(err){notice(err.message,true);button.disabled=false}
 };
 document.querySelectorAll('[data-save-user]').forEach(b=>b.onclick=async()=>{
   const select=document.querySelector(`[data-role-user="${b.dataset.saveUser}"]`);const original=us.find(u=>u.id===Number(b.dataset.saveUser));
   if(!select||!original||original.role===select.value)return notice('El usuario conserva su rol actual.');
   if(!window.confirm('¿Cambiar el rol de '+original.name+' a '+(select.value==='RRHH'?'Recursos Humanos':'Trabajador')+'? La sesión actual perderá los permisos anteriores.'))return;
   try{await api('identity/users/'+original.id,patch({role:select.value}));notice('Rol actualizado; el usuario debe iniciar sesión otra vez.');await showUsers()}
   catch(e){notice(e.message,true);await showUsers()}
 });
 document.querySelectorAll('[data-user-toggle]').forEach(b=>b.onclick=async()=>{
   const action=b.dataset.now==='1'?'desactivar':'activar';const original=us.find(u=>u.id===Number(b.dataset.userToggle));
   if(!window.confirm('¿'+action+' el acceso de '+(original?.name||'esta persona')+'?'))return;
   try{await api('identity/users/'+b.dataset.userToggle,patch({active:b.dataset.now!=='1'}));notice('Acceso actualizado');await showUsers()}
   catch(err){notice(err.message,true)}
 });
 document.querySelectorAll('[data-user-reset]').forEach(b=>b.onclick=async()=>{
   const original=us.find(u=>u.id===Number(b.dataset.userReset));
   const password=window.prompt('Nueva contraseña para '+original.name+' (mínimo 10 caracteres):');
   if(password===null)return;if(password.length<10)return notice('La contraseña requiere al menos 10 caracteres.',true);
   if(!window.confirm('¿Restablecer la contraseña de '+original.name+'? Se invalidará su contraseña anterior.'))return;
   try{await api('identity/users/'+original.id+'/reset-password',json({new_password:password}));notice('Contraseña restablecida. Entrégala de forma privada.')}
   catch(err){notice(err.message,true)}
 });

}
function generateKey(label){
  let key=label.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().replace(/[^A-Z0-9]+/g,'_').replace(/^_+|_+$/g,'');
  return key.slice(0,40);
}
function addFieldRow(){
  const root=$('new-fields');
  if(root.children.length>=12)return notice('Puedes agregar hasta 12 campos adicionales.',true);
  const item=document.createElement('div');item.className='catalog-field';
  item.innerHTML=`<label>Nombre del campo<input name="field_label" maxlength="100" required placeholder="Ej. Fecha de entrega"></label><label>Tipo<select name="field_type"><option value="text">Texto</option><option value="date">Fecha</option><option value="month">Mes</option><option value="time">Hora</option></select></label><label class="catalog-required"><input type="checkbox" name="field_required"> Obligatorio</label><button type="button" class="outline" data-remove-field>Quitar</button>`;
  root.append(item);
  item.querySelector('[data-remove-field]').onclick=()=>item.remove();
}

async function openFieldEditor(key){
 const t=state.types.find(x=>x.key===key);if(!t)return;
 document.getElementById('edit-fields-panel')?.remove();
 const section=document.createElement('section');section.className='panel';section.id='edit-fields-panel';
 const title=document.createElement('h3');title.textContent='Editar campos: '+t.label;section.append(title);
 const note=document.createElement('p');note.className='muted small';
 note.textContent='Conserva los identificadores de campos ya usados en expedientes.';section.append(note);
 const rows=document.createElement('div');section.append(rows);
 function row(field){
  const item=document.createElement('div');item.className='catalog-field';
  const labels=[['Identificador',field.key||''],['Nombre',field.label||'']];
  const ins=labels.map(pair=>{let lab=document.createElement('label');lab.textContent=pair[0];let input=document.createElement('input');input.value=pair[1];input.required=true;lab.append(input);item.append(lab);return input});
  const kind=document.createElement('select');
  ['text','date','time','month'].forEach(v=>{let o=document.createElement('option');o.value=v;o.textContent=v;kind.append(o)});
  kind.value=field.type||'text';item.append(kind);
  const required=document.createElement('input');required.type='checkbox';required.checked=!!field.required;
  let rlab=document.createElement('label');rlab.textContent='Obligatorio ';rlab.append(required);item.append(rlab);
  const rem=document.createElement('button');rem.type='button';rem.textContent='Eliminar';rem.className='outline';rem.onclick=()=>item.remove();item.append(rem);rows.append(item);
  item.data=()=>({key:ins[0].value.trim().toLowerCase(),label:ins[1].value.trim(),type:kind.value,required:required.checked});
 }
 (t.fields||[]).forEach(row);
 const add=document.createElement('button');add.textContent='+ Añadir campo';add.className='outline';add.onclick=()=>{if(rows.children.length<12)row({key:'campo_nuevo_'+(rows.children.length+1),label:'',type:'text'});else notice('Máximo 12 campos.',true)};section.append(add);
 const save=document.createElement('button');save.textContent='Guardar cambios';save.className='primary';save.onclick=async()=>{
  const fields=[...rows.children].map(x=>x.data());
  if(fields.some(f=>!f.label||!f.key)||new Set(fields.map(f=>f.key)).size!==fields.length){notice('Revisa nombres e identificadores.',true);return}
  try{await api('requests/types/'+encodeURIComponent(key),patch({fields}));notice('Campos actualizados');invalidateData();await showCatalog()}catch(e){notice(e.message,true)}
 };section.append(save);
 const cancel=document.createElement('button');cancel.textContent='Cancelar';cancel.className='outline';cancel.onclick=()=>section.remove();section.append(cancel);
 $('main-content').prepend(section);section.scrollIntoView({behavior:'smooth'});
}

async function showCatalog(){
 const started=navSequence, types=await api('requests/types');if(started!==navSequence)return;
 state.types=types;
 $('main-content').innerHTML=`<div class="content-title"><div><h3>Trámites institucionales</h3><p>Administra los formularios disponibles. Puedes agregar trámites sin modificar los expedientes existentes.</p></div><button type="button" class="primary" id="add-type-toggle">+ Agregar trámite</button></div>
 <section class="panel hidden" id="add-type-panel"><h3>Nuevo trámite</h3><p class="muted small">El nombre identifica al trámite. Asunto y detalle ya forman parte de todas las solicitudes.</p><form id="add-type-form"><label>Nombre del trámite<input name="label" required minlength="3" maxlength="120" placeholder="Ej. Constancia de capacitación"></label><h4>Campos adicionales (opcionales)</h4><div id="new-fields"></div><button class="outline" type="button" id="add-field">+ Añadir campo</button><div class="form-actions"><button class="primary" type="submit">Guardar trámite</button></div></form></section>
 <section class="panel"><div class="table-scroll"><table><thead><tr><th>Trámite</th><th>Campos específicos</th><th>Activo</th></tr></thead><tbody>${state.types.map(t=>`<tr><td><b>${esc(t.label)}</b><small>${esc(t.key)}</small><button class="outline mini-edit" data-rename="${esc(t.key)}" type="button">Cambiar nombre</button><button class="outline mini-edit" data-editfields="${esc(t.key)}" type="button">Editar campos</button></td><td>${t.fields.map(f=>esc(f.label)).join(', ')||'Sin campos adicionales'}</td><td><button class="outline" data-catalog="${esc(t.key)}" data-active="${t.active?'1':'0'}">${t.active?'Disponible':'Deshabilitado'}</button></td></tr>`).join('')}</tbody></table></div></section>`;
 $('add-type-toggle').onclick=()=>{$('add-type-panel').classList.toggle('hidden');if(!$('add-type-panel').classList.contains('hidden'))$('add-type-panel').scrollIntoView({behavior:'smooth',block:'start'})};
 $('add-field').onclick=addFieldRow;
 $('add-type-form').onsubmit=async e=>{e.preventDefault();let form=new FormData(e.target),label=String(form.get('label')||'').trim(),key=generateKey(label);
 if(key.length<3)return notice('El nombre debe contener al menos tres letras o números.',true);
 const fields=[...$('new-fields').children].map((item,index)=>{const label=item.querySelector('[name="field_label"]').value.trim();return {key:'campo_'+(index+1),label,type:item.querySelector('[name="field_type"]').value,required:item.querySelector('[name="field_required"]').checked}});
 try{await api('requests/types',json({key,label,fields}));notice('Trámite agregado');invalidateData();await showCatalog()}catch(err){notice(err.message,true)}
 };
 document.querySelectorAll('[data-catalog]').forEach(b=>b.onclick=async()=>{try{await api('requests/types/'+b.dataset.catalog,patch({active:b.dataset.active!=='1'}));notice('Catálogo actualizado');invalidateData();await showCatalog()}catch(e){notice(e.message,true)}});
 document.querySelectorAll('[data-editfields]').forEach(b=>b.onclick=()=>openFieldEditor(b.dataset.editfields));
 document.querySelectorAll('[data-rename]').forEach(b=>b.onclick=async()=>{let t=state.types.find(x=>x.key===b.dataset.rename);let label=window.prompt('Nombre del trámite:',t.label);if(!label||!label.trim()||label.trim()===t.label)return;try{await api('requests/types/'+b.dataset.rename,patch({label:label.trim()}));notice('Nombre actualizado');invalidateData();await showCatalog()}catch(e){notice(e.message,true)}});
}
async function showProfile(){
  $('main-content').innerHTML=`<section class="panel profile-password-panel"><h3>Cambiar contraseña</h3><form id="password-form"><label>Contraseña actual<input type="password" name="current_password" required autocomplete="current-password"></label><label>Nueva contraseña<input type="password" name="new_password" minlength="10" maxlength="100" required autocomplete="new-password"></label><button class="primary" type="submit">Guardar nueva contraseña</button></form></section>`;
  $('password-form').onsubmit=async e=>{e.preventDefault();try{await api('identity/auth/change-password',json(Object.fromEntries(new FormData(e.target))));e.target.reset();notice('Contraseña actualizada correctamente.')}catch(err){notice(err.message,true)}};
}
async function showAlerts(){const started=navSequence;const notifications=await api('requests/notifications');if(started!==navSequence)return;applyNotifications(notifications,{announce:false});$('main-content').innerHTML=`<section class="panel"><h3>Seguimiento de solicitudes</h3><p class="muted">${staff()?'Recibirás un aviso por cada solicitud nueva o corrección del trabajador.':'Cada solicitud tiene un solo aviso vigente. Los cambios anteriores permanecen en el historial del expediente.'}</p>${state.notifications.length?state.notifications.map(n=>`<div class="alert-line ${n.read?'':'unread'}"><div><b><span class="alert-icon" aria-hidden="true">${/corregid|subsanad/i.test(n.detail)?'✏️':/nueva solicitud/i.test(n.detail)?'📥':'🔔'}</span>${esc(n.detail)}</b><small>${date(n.created_at)} ${n.read?'':'· Nuevo'}</small></div><div><button class="outline" data-alert="${n.id}" data-request="${n.request_id}">Ver expediente</button></div></div>`).join(''):'<p class="muted">Todavía no tienes avisos.</p>'}</section>`;document.querySelectorAll('[data-alert]').forEach(b=>b.onclick=async()=>{try{if(await openDetail(Number(b.dataset.request))){await api('requests/notifications/'+b.dataset.alert+'/read',json({}));const line=b.closest('.alert-line');if(staff())line?.remove();else line?.classList.remove('unread');const small=line?.querySelector('small');if(small)small.textContent=small.textContent.replace(' · Nuevo','');const one=state.notifications.find(x=>String(x.id)===b.dataset.alert);if(one)one.read=true;unreadNotifications=state.notifications.filter(x=>!x.read).length;updateNotificationBadge()}}catch(err){notice(err.message,true)}})}
document.addEventListener('click',e=>{const b=e.target.closest('[data-toggle-password]');if(!b)return;const f=$(b.dataset.togglePassword);if(!f)return;const show=f.type==='password';f.type=show?'text':'password';b.setAttribute('aria-pressed',String(show));b.setAttribute('aria-label',show?'Ocultar contraseña':'Mostrar contraseña');b.setAttribute('title',show?'Ocultar contraseña':'Mostrar contraseña');b.classList.toggle('is-visible',show)});
$('login-form').onsubmit=async e=>{e.preventDefault();
  const button=e.target.querySelector('button[type="submit"]');button.disabled=true;
  try{const result=await api('identity/auth/login',json(Object.fromEntries(new FormData(e.target))));await renderWorkspace(result.user)}
  catch(err){notice(err.message,true)}finally{button.disabled=false}
};
$('open-register').onclick=()=>{$('login-form').classList.add('hidden');$('register-form').classList.remove('hidden')};
$('back-to-login').onclick=()=>{$('register-form').classList.add('hidden');$('login-form').classList.remove('hidden')};
$('register-form').onsubmit=async e=>{e.preventDefault();
  const form=Object.fromEntries(new FormData(e.target));
  if(form.password!==form.confirm_password)return notice('Las contraseñas no coinciden.',true);
  const button=e.target.querySelector('button[type="submit"]');button.disabled=true;
  try{
    const response=await api('identity/auth/register',json({name:form.name,email:form.email,password:form.password}));
    e.target.reset();$('register-form').classList.add('hidden');$('login-form').classList.remove('hidden');
    $('login-form input[name="email"]').value=form.email;
    notice(response.detail||'Solicitud de registro enviada a Recursos Humanos.');
  }catch(err){notice(err.message,true)}finally{button.disabled=false}
};
$('logout').onclick=async()=>{try{await fetch('/api/logout',{method:'POST'});}finally{state.user=null;state.requests=[];state.notifications=[];unreadNotifications=0;notificationsInitialized=false;latestNotificationId=0;readPending.clear();invalidateData();updateNotificationBadge();logged(false)}};
$('topbar-notifications').onclick=()=>navigation('alerts');
$('navigation').addEventListener('click',e=>{let b=e.target.closest('[data-tab]');if(b)navigation(b.dataset.tab)});
document.addEventListener('click',async e=>{let b=e.target.closest('[data-detail]');if(b)await openDetail(Number(b.dataset.detail));if(e.target.closest('[data-close]'))$('detail-dialog').close();let a=e.target.closest('[data-file]');if(a){e.preventDefault();try{let blob=await api('requests/attachments/'+a.dataset.file);let url=URL.createObjectURL(blob);let x=document.createElement('a');x.href=url;x.download=a.textContent.split(' · ')[0];x.click();setTimeout(()=>URL.revokeObjectURL(url),2000)}catch(err){notice(err.message,true)}}});
(async()=>{try{const r=await fetch('/auth/providers');if(!r.ok)return;const p=await r.json();$('google-login').classList.toggle('hidden',!p.google);$('microsoft-login').classList.toggle('hidden',!p.microsoft);$('sso-options').classList.toggle('hidden',!p.google&&!p.microsoft)}catch{}})();
if(new URLSearchParams(location.search).has('sso_error')){history.replaceState(null,'',location.pathname);setTimeout(()=>notice('No se pudo iniciar sesión con el proveedor o el correo no está autorizado.',true),100)}

// Refresco ligero: la bandeja y los estados cambian al recibir una respuesta de RR. HH.
async function checkUpdates(){
 if(!state.user||document.hidden||syncing)return;
 syncing=true;
 try{
  const data=await api('requests/sync');
  if(Array.isArray(data.notifications))applyNotifications(data.notifications);
  const signature=inboxSignature(data.requests);
  if(signature===lastInboxSignature)return;
  const changeMap=new Map(data.requests.map(x=>[x.id,x]));
  lastInboxSignature=signature;
  invalidateData();
  if(state.tab==='requests'){
    const formOpen=$('new-form-panel')&&!$('new-form-panel').classList.contains('hidden');
    if(!formOpen)await showRequests(null,true);
  } else if(state.tab==='alerts') await showAlerts();
  else if(state.tab==='reports') await showReports(true);
  const active=state.active;
  if(active&&$('detail-dialog').open&&changeMap.has(active.id)
    &&changeMap.get(active.id).updated_at!==active.updated_at){
    const editing=$('detail-dialog').contains(document.activeElement)
      &&['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName);
    if(!editing)await refreshDetail(active.id);
    else notice('La solicitud se actualizó. Cierra el formulario y vuelve a abrirla para ver los cambios.');
  }
 }catch(error){console.warn('No se pudo comprobar actualizaciones:',error.message)}
 finally{syncing=false}
}
setInterval(checkUpdates,7500);
window.addEventListener('focus',checkUpdates);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)checkUpdates()});
init();

// Estilos del selector de hora: hora 1-12, minutos independientes y AM/PM.
(function(){const s=document.createElement('style');s.textContent='.clock-field{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;max-width:440px}.clock-field select{min-width:0;width:100%}@media(max-width:450px){.clock-field{gap:5px}}';document.head.appendChild(s)})();

/* Separación visual de decisiones y cierre del expediente. */
(function(){const st=document.createElement('style');st.textContent='#detail-body .issued-delivery{margin:24px 0;padding:22px 24px;border:1px solid #dce5f2;border-radius:14px}#detail-body .issued-delivery h4{margin:0 0 12px}#detail-body .issued-delivery form{display:grid;gap:14px;margin-top:14px}#detail-body .issued-delivery .primary{width:max-content;max-width:100%;min-height:44px}#detail-body .response-panel{margin-top:28px;padding-top:8px}#detail-body .response-panel h4{margin:12px 0 10px}#detail-body .response-panel form{display:grid;gap:16px;margin-top:16px}#detail-body .response-panel label{display:grid;gap:9px}#detail-body .response-panel select,#detail-body .response-panel textarea{margin-top:5px}#detail-body .response-panel .primary{width:max-content;min-height:42px}@media(max-width:550px){#detail-body .issued-delivery{padding:16px}#detail-body .issued-delivery .primary,#detail-body .response-panel .primary{width:100%}}';document.head.appendChild(st)})();

(function(){const st=document.createElement('style');st.textContent='#detail-body .response-panel{margin-top:24px}#detail-body .response-panel [hidden]{display:none!important}#detail-body .response-panel #resolution-area label{display:grid;gap:10px}#detail-body .response-panel .primary{margin-top:5px}';document.head.append(st)})();

(function(){const st=document.createElement('style');st.textContent='#detail-body .response-panel{margin:20px 0 26px;padding:18px 0;border-bottom:1px solid #e4e9f0}#detail-body .response-panel h4{margin-top:0}#detail-body .detail-fields+.response-panel{margin-top:24px}';document.head.appendChild(st)})();

(function(){const st=document.createElement('style');st.textContent='.clock-field{display:block!important;max-width:none!important}.clock-field .time-single-input{width:100%;min-width:0;box-sizing:border-box}.clock-field datalist{display:none}';document.head.appendChild(st)})();
