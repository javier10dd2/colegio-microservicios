# Colegio Pestalozzi - Sistema de solicitudes

Código recuperado del último despliegue FastAPI funcional del proyecto de Vercel `taller-de-software/colegio-microservicios`, con la interfaz JavaScript y CSS actualmente servidos en producción.

## Estructura
- `app.py`: entrada de FastAPI para Vercel
- `backend/`: microservicios de identidad, solicitudes, reportes y gateway
- `frontend/`: interfaz web, estilos y escudo institucional
- `requirements.txt`: dependencias de Python
- `.env.example`: nombres de variables requeridas sin credenciales

## Subir a GitHub
Extraer este ZIP y subir **los archivos y carpetas de su interior** a la raíz del repositorio `javier10dd2/colegio-microservicios`. No subir el ZIP como único archivo.

## Seguridad
No se incluyen exportaciones de MySQL, claves, tokens ni variables de entorno de Vercel o Railway. Mantener secretos en el apartado Environment Variables de Vercel y no incluirlos en commits.

## Despliegue
El proyecto de Vercel ya está vinculado a GitHub. **No activar despliegues automáticos ni sustituir producción** hasta hacer un despliegue de prueba y comprobar los servicios, las variables, la conexión con MySQL y los formularios desde las cuentas de trabajador y RR. HH. La interfaz se había actualizado por una regla de ruta; GitHub contiene ahora la versión visible de la interfaz, pero una compilación desde GitHub requiere pruebas independientes.
