"""Agregados calculados a partir del API de solicitudes, sin acceso directo a su BD."""
import os,statistics,csv,io
from datetime import datetime,timezone
import httpx
http_client=httpx.Client(timeout=5,limits=httpx.Limits(max_keepalive_connections=10,max_connections=20))
from fastapi import FastAPI,HTTPException,Depends
from fastapi.responses import Response
from common.catalog import STATUS,TYPES
from common.security import require_user,require_staff,INTERNAL_KEY
IDENTITY_URL=os.getenv('IDENTITY_URL','http://127.0.0.1:8001')
app=FastAPI(title='Colegio · Reportes')
REQUESTS_URL=os.getenv('REQUESTS_URL','http://127.0.0.1:8002')

def parsed(dt):
    if not dt:return None
    x=datetime.fromisoformat(dt.replace('Z','+00:00'))
    return x.replace(tzinfo=timezone.utc) if not x.tzinfo else x

def verified_user(token:dict=Depends(require_user)):
    try:
        res=http_client.get(f"{IDENTITY_URL}/internal/users/{token['id']}",headers={'X-Internal-Key':INTERNAL_KEY},timeout=5)
    except httpx.RequestError:raise HTTPException(503,'Identidad no disponible.')
    if res.status_code!=200:raise HTTPException(401,'Cuenta no habilitada.')
    return res.json()

@app.get('/health')
def health():return {'service':'reportes','ok':True}

def export_data():
    try:
        resp=http_client.get(REQUESTS_URL+'/internal/export',
            headers={'X-Internal-Key':INTERNAL_KEY},timeout=20)
        resp.raise_for_status()
        return resp.json()
    except (httpx.RequestError,httpx.HTTPStatusError,ValueError):
        raise HTTPException(503,'No fue posible obtener los expedientes.')

def deadline_hours():
    try:
        value=float(os.getenv('RESPONSE_SLA_HOURS','48'))
        return value if 0<value<=720 else 48.0
    except (ValueError,TypeError):
        return 48.0

def history_complete(req):
    events=req.get('history') or []
    if not events or events[0].get('kind')!='CREACION' or events[0].get('to_status')!='REGISTRADA':
        return False
    if not all(e.get('actor_id') and e.get('recorded_at') and e.get('to_status') for e in events):
        return False
    if events[-1].get('to_status')!=req.get('status'):
        return False
    return req.get('status')=='REGISTRADA' or any(
       e.get('kind')=='CAMBIO_ESTADO' and e.get('to_status')==req.get('status')
       for e in events)

def sla_classification(req,deadline,now):
    submitted=parsed(req.get('created_at'))
    first=parsed(req.get('first_response_at'))
    if not submitted:return ('sin_evidencia',None)
    if first:
        hours=(first-submitted).total_seconds()/3600
        if hours<0:return ('sin_evidencia',None)
        return ('en_plazo' if hours<=deadline else 'fuera_plazo',hours)
    hours=max(0,(now-submitted).total_seconds()/3600)
    return ('vencida' if hours>deadline else 'pendiente',hours)

def build_summary(dataset):
    requests=dataset.get('requests',[])
    durations=[float(x['response_seconds']) for x in requests
               if x.get('response_seconds') is not None and float(x['response_seconds'])>=0]
    trace=sum(history_complete(x) for x in requests)
    deadline=deadline_hours()
    now=datetime.now(timezone.utc)
    flags=[sla_classification(x,deadline,now)[0] for x in requests]
    ontime=flags.count('en_plazo')
    late=flags.count('fuera_plazo')+flags.count('vencida')
    pending=flags.count('pendiente')
    denom=ontime+late
    return {
      'total':len(requests),'demo_count':dataset.get('demo_count',0),
      'consultation_reads':dataset.get('consultation_reads',0),
      'state_updates':dataset.get('state_updates',0),
      'by_status':{s:sum(x['status']==s for x in requests) for s in STATUS},
      'by_type':{k:sum(x['type']==k for x in requests)
                 for k in set(TYPES)|{x['type'] for x in requests}},
      'consultation':{'valid':len(durations),
          'mean_seconds':round(statistics.mean(durations),2) if durations else None,
          'median_seconds':round(statistics.median(durations),2) if durations else None,
          'in_progress':sum(bool(x.get('review_started_at')) and not bool(x.get('first_response_at')) for x in requests),
          'basis':'primera_apertura_rrhh_a_primera_respuesta'},
      'trace':{'complete':trace,'evaluable':len(requests),
               'percent':round(100*trace/len(requests),1) if requests else None},
      'timely':{'deadline_hours':deadline,'evidence_validated':True,'complete':ontime,
                'evaluable':denom,'late':late,'pending':pending,
                'missing_evidence':flags.count('sin_evidencia'),
                'percent':round(100*ontime/denom,1) if denom else None,
                'basis':'registro_a_primera_respuesta'},
      'note':'El tiempo de consulta de RR. HH. se mide desde la apertura hasta la primera respuesta. '
             'Actualización oportuna compara el registro con la primera respuesta según un plazo '
             'operativo configurable, no una autorización institucional.'
    }

@app.get('/summary')
def summary(user:dict=Depends(verified_user)):
    require_staff(user)
    return build_summary(export_data())

@app.get('/mediciones.csv')
@app.get('/posttest.csv',include_in_schema=False)
def export_posttest(user:dict=Depends(verified_user)):
    require_staff(user)
    dataset=export_data()
    deadline=deadline_hours()
    now=datetime.now(timezone.utc)
    columns=['codigo','id_solicitud','tipo_tramite','fecha_registro','estado',
             'apertura_rrhh','primera_respuesta_rrhh','tiempo_consulta_segundos',
             'tiempo_consulta_minutos','horas_desde_registro_hasta_respuesta_o_ahora',
             'plazo_operativo_horas','actualizacion_oportuna','trazabilidad_completa',
             'cantidad_eventos','cambios_de_estado','respuesta_enviada']
    stream=io.StringIO(newline='')
    writer=csv.writer(stream,delimiter=';',quoting=csv.QUOTE_MINIMAL)
    writer.writerow(columns)
    for req in dataset.get('requests',[]):
        flag,hours=sla_classification(req,deadline,now)
        seconds=req.get('response_seconds')
        history=req.get('history') or []
        row=[req['code'],req['id'],req['type'],req['created_at'],req['status'],
             req.get('review_started_at') or '',req.get('first_response_at') or '',
             seconds if seconds is not None else '',
             round(float(seconds)/60,2) if seconds is not None else '',
             round(hours,3) if hours is not None else '',deadline,
             {'en_plazo':'SI','fuera_plazo':'NO','vencida':'NO',
              'pendiente':'PENDIENTE','sin_evidencia':'SIN_EVIDENCIA'}[flag],
             'SI' if history_complete(req) else 'NO',
             len(history),sum(e.get('kind')=='CAMBIO_ESTADO' for e in history),
             'SI' if req.get('first_response_at') else 'NO']
        writer.writerow([("'"+v if isinstance(v,str) and v.startswith(('=','+','-','@')) else v) for v in row])
    return Response('\ufeff'+stream.getvalue(),media_type='text/csv; charset=utf-8',
        headers={'Content-Disposition':'attachment; filename="matriz_seguimiento_rrhh.csv"',
                 'Cache-Control':'no-store'})
