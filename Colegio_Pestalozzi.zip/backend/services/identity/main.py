"""Gestión de identidad y perfiles institucionales."""
from contextlib import asynccontextmanager
import os
from datetime import datetime,timezone
from fastapi import FastAPI, HTTPException, Depends, Header
from pydantic import BaseModel, Field, EmailStr
from sqlalchemy import Integer,String,Boolean,DateTime,select,text,inspect
from sqlalchemy.orm import Mapped,mapped_column,Session
from common.database import Base,get_database
from common.security import password_hash,password_verify,make_token,require_user,check_internal

engine,SessionLocal=get_database('identidad','IDENTITY_DATABASE_URL')
class User(Base):
    __tablename__='usuarios'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    name:Mapped[str]=mapped_column(String(120))
    email:Mapped[str]=mapped_column(String(190),unique=True,index=True)
    password_hash:Mapped[str]=mapped_column(String(256))
    role:Mapped[str]=mapped_column(String(15))
    active:Mapped[bool]=mapped_column(Boolean,default=True)
    can_authorize:Mapped[bool]=mapped_column(Boolean,default=False)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))

class AuditUser(Base):
    __tablename__='auditoria_usuarios'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    actor_id:Mapped[int]=mapped_column(Integer)
    target_id:Mapped[int]=mapped_column(Integer)
    action:Mapped[str]=mapped_column(String(70))
    detail:Mapped[str]=mapped_column(String(250))
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))

def audit(db,actor_id,target_id,action,detail):
    db.add(AuditUser(actor_id=actor_id,target_id=target_id,action=action,detail=detail))

def public(u:User)->dict:
    # El rol RRHH activo confiere las decisiones administrativas correspondientes.
    return {'id':u.id,'name':u.name,'email':u.email,'role':u.role,
            'active':u.active,'can_authorize':bool(u.active and u.role=='RRHH'),
            'can_manage_authorizations':False}

def getdb():
    with SessionLocal() as db:yield db

def migrate_schema():
    Base.metadata.create_all(engine, tables=[User.__table__, AuditUser.__table__])
    cols={c['name'] for c in inspect(engine).get_columns('usuarios')}
    with engine.begin() as conn:
        if 'can_authorize' not in cols:
            conn.execute(text('ALTER TABLE usuarios ADD COLUMN can_authorize BOOLEAN NOT NULL DEFAULT 0'))
        # Compatible con instalaciones V1 existentes. No se borran cuentas ni contraseñas.
        conn.execute(text("UPDATE usuarios SET role='RRHH' WHERE role='ADMIN'"))

def receiver(db:Session):
    # RR.HH. es el único receptor de todos los trámites (sin reasignación).
    # Cuando hay cuentas legadas o de prueba, preferir a la persona real designada.
    preferred=os.getenv('PRIMARY_RRHH_EMAIL','').strip().lower()
    if preferred:
        u=db.scalar(select(User).where(User.role=='RRHH',User.active==True,User.email==preferred))
        if u:return u
    u=db.scalar(select(User).where(User.role=='RRHH',User.active==True,
        User.email!='rrhh@colegio.example.com').order_by(User.id))
    if u:return u
    return db.scalar(select(User).where(User.role=='RRHH',User.active==True).order_by(User.id))

@asynccontextmanager
async def lifespan(app:FastAPI):
    migrate_schema()
    yield
app=FastAPI(title='Colegio · Identidad (2 roles)',lifespan=lifespan)
class Login(BaseModel):
    email:EmailStr
    password:str

class RegisterWorker(BaseModel):
    name:str=Field(min_length=3,max_length=120)
    email:EmailStr
    password:str=Field(min_length=10,max_length=100)

@app.post('/auth/register',status_code=201)
def register_worker(d:RegisterWorker,db:Session=Depends(getdb)):
    """Self-registration is worker-only, pending activation by RR.HH."""
    email=d.email.strip().lower()
    name=' '.join(d.name.strip().split())
    if len(name)<3:raise HTTPException(422,'Escribe tu nombre completo.')
    if db.scalar(select(User.id).where(User.email==email)):
        raise HTTPException(409,'Ya existe una cuenta con ese correo electrónico.')
    item=User(name=name,email=email,password_hash=password_hash(d.password),role='TRABAJADOR',active=False)
    db.add(item)
    try:
        db.commit()
    except Exception:
        db.rollback()
        # Prevent parallel requests from creating duplicate email accounts.
        raise HTTPException(409,'Ese correo ya está registrado.')
    return {'ok':True,'detail':'Cuenta creada. Recursos Humanos debe habilitarla para iniciar sesión.'}

class CreateUser(BaseModel):
    name:str=Field(min_length=3,max_length=120)
    email:EmailStr
    password:str=Field(min_length=10,max_length=100)
    role:str='TRABAJADOR'

class AdminResetPassword(BaseModel):
    new_password:str=Field(min_length=10,max_length=100)

class UserUpdate(BaseModel):
    active:bool|None=None
    name:str|None=Field(default=None,min_length=3,max_length=120)
    role:str|None=None
class PasswordChange(BaseModel):
    current_password:str
    new_password:str=Field(min_length=10,max_length=100)

def verified_account(user:dict=Depends(require_user), db:Session=Depends(getdb)):
    account=db.get(User,user['id'])
    if not account or not account.active or account.role != user['role']:
        raise HTTPException(401,'Tu sesión cambió. Vuelve a iniciar sesión.')
    return account

def staff_account(account:User=Depends(verified_account)):
    if account.role!='RRHH':
        raise HTTPException(403,'Solo Recursos Humanos administra cuentas.')
    return account

@app.get('/health')
def health():
    try:
        with engine.connect() as conn:conn.execute(text('SELECT 1'))
    except Exception:raise HTTPException(503,'Base de identidad no disponible.')
    return {'service':'identidad','ok':True,'roles':['TRABAJADOR','RRHH'],'database':os.getenv('DB_MODE','sqlite')}
@app.post('/auth/login')
def login(d:Login, db:Session=Depends(getdb)):
    u=db.scalar(select(User).where(User.email==d.email.lower()))
    if not u or not password_verify(d.password,u.password_hash):raise HTTPException(401,'Credenciales inválidas.')
    if not u.active:raise HTTPException(403,'Cuenta pendiente de autorización o desactivada. Comunícate con Recursos Humanos.')
    if u.role not in ('TRABAJADOR','RRHH'):raise HTTPException(403,'Cuenta sin rol permitido.')
    return {'token':make_token(public(u)),'user':public(u)}
@app.get('/auth/me')
def me(account:User=Depends(verified_account)):
    return public(account)

@app.post('/auth/change-password')
def change_password(d:PasswordChange,account:User=Depends(verified_account),db:Session=Depends(getdb)):
    if not password_verify(d.current_password,account.password_hash):
        raise HTTPException(400,'La contraseña actual no coincide.')
    if d.current_password==d.new_password:
        raise HTTPException(400,'La contraseña nueva debe ser diferente.')
    account.password_hash=password_hash(d.new_password)
    audit(db,account.id,account.id,'CLAVE_CAMBIADA','Cambio de contraseña')
    db.commit()
    return {'ok':True}

@app.get('/users')
def users(account:User=Depends(staff_account),db:Session=Depends(getdb)):
    return [public(x) for x in db.scalars(select(User).order_by(User.active.asc(),User.name))]

@app.post('/users',status_code=201)
def create_user(d:CreateUser,account:User=Depends(staff_account),db:Session=Depends(getdb)):
    """Solo RR.HH. puede crear trabajadores o personal de RR.HH. con clave inicial."""
    role=d.role.strip().upper()
    if role not in ('TRABAJADOR','RRHH'):
        raise HTTPException(422,'Selecciona Trabajador o Recursos Humanos.')
    name=' '.join(d.name.strip().split())
    email=d.email.strip().lower()
    if len(name)<3:
        raise HTTPException(422,'Escribe el nombre completo.')
    if db.scalar(select(User.id).where(User.email==email)):
        raise HTTPException(409,'Ya existe una cuenta con ese correo electrónico.')
    u=User(name=name,email=email,password_hash=password_hash(d.password),role=role,
           active=True,can_authorize=False)
    db.add(u)
    try:
        db.flush()
        audit(db,account.id,u.id,'CUENTA_CREADA',f'Rol: {role}; activa: True')
        db.commit()
        db.refresh(u)
    except Exception:
        db.rollback()
        raise HTTPException(409,'No se pudo crear la cuenta. Revisa que el correo sea único.')
    return public(u)

@app.post('/users/{uid}/reset-password')
def reset_password(uid:int,d:AdminResetPassword,account:User=Depends(staff_account),db:Session=Depends(getdb)):
    """Nueva clave definida por RR.HH., nunca se devuelve ni se registra en el historial."""
    u=db.get(User,uid)
    if not u:raise HTTPException(404,'Cuenta no encontrada.')
    u.password_hash=password_hash(d.new_password)
    audit(db,account.id,uid,'CLAVE_RESTABLECIDA','Contraseña restablecida por Recursos Humanos')
    db.commit()
    return {'ok':True,'detail':'Contraseña restablecida.'}

@app.patch('/users/{uid}')
def update(uid:int,d:UserUpdate,account:User=Depends(staff_account),db:Session=Depends(getdb)):
    x=db.get(User,uid)
    if not x:raise HTTPException(404,'Cuenta no encontrada.')
    if d.role is not None and d.role not in ('TRABAJADOR','RRHH'):
        raise HTTPException(400,'Solo existen los roles RRHH y TRABAJADOR.')
    if x.id==account.id and (d.role is not None and d.role!='RRHH' or d.active is False):
        raise HTTPException(400,'No puedes quitar tu propio acceso como RR. HH.')
    remaining_staff=db.scalar(select(User.id).where(User.role=='RRHH',User.active==True,User.id!=x.id).limit(1))
    if x.role=='RRHH' and not remaining_staff and (d.role=='TRABAJADOR' or d.active is False):
        raise HTTPException(400,'Debe permanecer al menos una cuenta de Recursos Humanos activa.')
    if d.name is not None:x.name=d.name.strip()
    if d.active is not None:x.active=d.active
    if d.role is not None:x.role=d.role
    # El campo legado permanece en BD, pero el permiso efectivo depende del rol.
    x.can_authorize=(x.role=='RRHH' and bool(x.active))
    audit(db,account.id,x.id,'USUARIO_EDITADO',
          f'Rol: {x.role}; activo: {x.active}')
    db.commit()
    return public(x)

class SSOAccount(BaseModel):
    email:EmailStr

@app.post('/internal/sso')
def internal_sso(d:SSOAccount,x_internal_key:str|None=Header(default=None),db:Session=Depends(getdb)):
    check_internal(x_internal_key)
    u=db.scalar(select(User).where(User.email==d.email.lower(),User.active==True))
    if not u or u.role not in ('TRABAJADOR','RRHH'):
        raise HTTPException(403,'Cuenta no autorizada.')
    return {'token':make_token(public(u))}

@app.get('/internal/users/{user_id}')
def internal_user(user_id:int,x_internal_key:str|None=Header(default=None),db:Session=Depends(getdb)):
    check_internal(x_internal_key)
    u=db.get(User,user_id)
    if not u or not u.active:raise HTTPException(404,'Usuario no encontrado.')
    return public(u)
@app.get('/internal/receiver')
def internal_receiver(x_internal_key:str|None=Header(default=None),db:Session=Depends(getdb)):
    check_internal(x_internal_key)
    u=receiver(db)
    if not u:raise HTTPException(503,'No existe responsable de Recursos Humanos activo.')
    return public(u)
